//#region \0rolldown/runtime.js
var __defProp = Object.defineProperty;
var __esmMin = (fn, res) => () => (fn && (res = fn(fn = 0)), res);
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) {
		__defProp(target, name, {
			get: all[name],
			enumerable: true
		});
	}
	if (!no_symbols) {
		__defProp(target, Symbol.toStringTag, { value: "Module" });
	}
	return target;
};

//#endregion
//#region addons/internal/host-compat/src/runtime.js
function setSdk(sdk) {
	current = sdk;
}
function getSdk() {
	if (!current) throw new Error("The host SDK is not set yet");
	return current;
}
function requireHost(sdk, names) {
	const missing = names.filter((n) => {
		const [group, key] = n.split(".");
		return !sdk[group] || typeof sdk[group][key] === "undefined";
	});
	if (missing.length > 0) throw new Error(`This add-on needs a newer LocalAI: the host has no ${missing.join(", ")}`);
}
var current;
var init_runtime = __esmMin((() => {
	current = null;
}));

//#endregion
//#region addons/internal/host-compat/src/route.js
var MOVED;
var init_route = __esmMin((() => {
	MOVED = Object.freeze([
		{
			prefix: "/app/studio",
			addon: "studio",
			page: "studio"
		},
		{
			prefix: "/app/talk",
			addon: "talk",
			page: "talk"
		},
		{
			prefix: "/app/voice",
			addon: "voice",
			page: "voice"
		}
	]);
}));

//#endregion
//#region addons/internal/host-compat/src/utils/basePath.js
function getBasePath() {
	if (typeof document === "undefined") return "";
	const el = document.querySelector("base[href]");
	if (!el) return "";
	try {
		return new URL(el.getAttribute("href"), globalThis.location?.href).pathname.replace(/\/+$/, "");
	} catch {
		return "";
	}
}
var basePath;
var init_basePath = __esmMin((() => {
	basePath = getBasePath();
}));

//#endregion
//#region addons/internal/host-compat/src/modules/react-router-dom.js
var createContext$1, createElement$1, useCallback$1, useContext$1, useMemo$2, RouteContext, RouteProvider;
var init_react_router_dom = __esmMin((() => {
	init_runtime();
	init_route();
	init_basePath();
	({createContext: createContext$1, createElement: createElement$1, useCallback: useCallback$1, useContext: useContext$1, useMemo: useMemo$2} = getSdk().React);
	RouteContext = createContext$1({
		page: "",
		path: "",
		search: ""
	});
	RouteProvider = RouteContext.Provider;
}));

//#endregion
//#region addons/internal/host-compat/src/modules/react.js
var React$1, Children, Fragment$1, Suspense, cloneElement, createContext, createElement, forwardRef, isValidElement, lazy, memo, startTransition, useCallback, useContext, useDeferredValue, useEffect$1, useId, useImperativeHandle, useLayoutEffect, useMemo$1, useReducer, useRef, useState$1, useSyncExternalStore, useTransition;
var init_react = __esmMin((() => {
	init_runtime();
	React$1 = getSdk().React;
	({Children, Fragment: Fragment$1, Suspense, cloneElement, createContext, createElement, forwardRef, isValidElement, lazy, memo, startTransition, useCallback, useContext, useDeferredValue, useEffect: useEffect$1, useId, useImperativeHandle, useLayoutEffect, useMemo: useMemo$1, useReducer, useRef, useState: useState$1, useSyncExternalStore, useTransition} = React$1);
}));

//#endregion
//#region addons/internal/host-compat/src/i18n.js
function registerLocales(byNamespace) {
	for (const [ns, languages] of Object.entries(byNamespace)) for (const [lng, data] of Object.entries(languages)) {
		if (!resources.has(lng)) resources.set(lng, /* @__PURE__ */ new Map());
		resources.get(lng).set(ns, data);
	}
}
function candidates(language) {
	const lang = String(language || "en");
	const out = [lang];
	const base = lang.split("-")[0];
	if (base !== lang) out.push(base);
	if (!out.includes("en")) out.push("en");
	return out;
}
function walk(data, key) {
	if (!data || typeof data !== "object") return void 0;
	if (Object.prototype.hasOwnProperty.call(data, key)) return data[key];
	let node = data;
	for (const part of key.split(".")) {
		if (node === null || typeof node !== "object" || !Object.prototype.hasOwnProperty.call(node, part)) return void 0;
		node = node[part];
	}
	return node;
}
function pluralSuffix(language, count) {
	try {
		return new Intl.PluralRules(language).select(count);
	} catch {
		return count === 1 ? "one" : "other";
	}
}
function lookup(language, namespaces, key, count) {
	for (const lng of candidates(language)) {
		const byNs = resources.get(lng);
		if (!byNs) continue;
		for (const ns of namespaces) {
			const data = byNs.get(ns);
			if (!data) continue;
			if (typeof count === "number") for (const suffix of [pluralSuffix(lng, count), "other"]) {
				const hit = walk(data, `${key}_${suffix}`);
				if (hit !== void 0) return hit;
			}
			const hit = walk(data, key);
			if (hit !== void 0) return hit;
		}
	}
}
function interpolate(text, vars) {
	return text.replace(/\{\{\s*-?\s*([A-Za-z0-9_.]+)\s*\}\}/g, (match, name) => vars && Object.prototype.hasOwnProperty.call(vars, name) && vars[name] !== void 0 ? String(vars[name]) : match);
}
function translator(language, namespaces) {
	const list = (Array.isArray(namespaces) ? namespaces : [namespaces || "common"]).filter(Boolean);
	return function t(key, second, third) {
		const options = typeof second === "object" && second !== null ? second : third || {};
		const fallback = typeof second === "string" ? second : options.defaultValue;
		let name = String(key);
		let spaces = list;
		const colon = name.indexOf(":");
		if (colon > 0) {
			spaces = [name.slice(0, colon)];
			name = name.slice(colon + 1);
		}
		const count = typeof options.count === "number" ? options.count : void 0;
		const found = lookup(language, spaces, name, count);
		if (found !== void 0 && typeof found === "object") return options.returnObjects ? found : fallback ?? name;
		return interpolate(typeof found === "string" ? found : typeof fallback === "string" ? fallback : name, options);
	};
}
var resources;
var init_i18n$1 = __esmMin((() => {
	resources = /* @__PURE__ */ new Map();
}));

//#endregion
//#region addons/internal/host-compat/src/modules/react-i18next.js
function useTranslation(namespaces) {
	const sdk = getSdk();
	const [language, setLanguage] = useState(() => sdk.locale.language());
	useEffect(() => {
		setLanguage(sdk.locale.language());
		return sdk.locale.subscribe((lng) => setLanguage(String(lng || "en")));
	}, [sdk]);
	return {
		t: useMemo(() => translator(language, Array.isArray(namespaces) ? namespaces : [namespaces]), [language, Array.isArray(namespaces) ? namespaces.join("|") : String(namespaces || "")]),
		i18n: {
			language,
			changeLanguage: async () => {}
		},
		ready: true
	};
}
var useEffect, useMemo, useState;
var init_react_i18next = __esmMin((() => {
	init_runtime();
	init_i18n$1();
	({useEffect, useMemo, useState} = getSdk().React);
}));

//#endregion
//#region addons/internal/host-compat/src/ui.js
function fromSdk(name) {
	const { React } = getSdk();
	const Component = React.forwardRef((props, ref) => {
		const Host = getSdk().ui[name];
		return React.createElement(Host, ref ? {
			...props,
			ref
		} : props);
	});
	Component.displayName = `Host(${name})`;
	return Component;
}
var init_ui = __esmMin((() => {
	init_runtime();
}));

//#endregion
//#region addons/internal/host-compat/src/components/ConfirmDialog.jsx
var ConfirmDialog_default;
var init_ConfirmDialog = __esmMin((() => {
	init_ui();
	ConfirmDialog_default = fromSdk("ConfirmDialog");
}));

//#endregion
//#region addons/internal/host-compat/src/modules/jsx-runtime.js
function jsx(type, props, key) {
	return key === void 0 ? React.createElement(type, props) : React.createElement(type, {
		...props,
		key
	});
}
var React, Fragment, jsxs;
var init_jsx_runtime = __esmMin((() => {
	init_runtime();
	React = getSdk().React;
	Fragment = React.Fragment;
	jsxs = jsx;
}));

//#endregion
//#region addons/internal/host-compat/src/components/Icon.jsx
function Icon(props) {
	const Host = getSdk().Icon;
	return /* @__PURE__ */ jsx(Host, { ...props });
}
var init_Icon = __esmMin((() => {
	init_runtime();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/controls.jsx
function Field({ label, hint, error, optional, className = "", children }) {
	const id = useId();
	const labels = useContext(HintLabels);
	const hintId = hint ? `${id}-hint` : void 0;
	const errorId = error ? `${id}-error` : void 0;
	const describedBy = [hintId, errorId].filter(Boolean).join(" ") || void 0;
	return /* @__PURE__ */ jsxs("div", {
		className: `dk-field ${className}`.trim(),
		children: [
			/* @__PURE__ */ jsx("label", {
				className: "dk-label",
				htmlFor: id,
				"data-optional": optional ? labels.optional : void 0,
				children: label
			}),
			children({
				id,
				"aria-describedby": describedBy,
				"aria-invalid": error ? "true" : void 0
			}),
			hint && /* @__PURE__ */ jsx(Hint, {
				id: hintId,
				children: hint
			}),
			error && /* @__PURE__ */ jsx(FieldError, {
				id: errorId,
				children: error
			})
		]
	});
}
function FieldError({ id, children, ...rest }) {
	return /* @__PURE__ */ jsxs("p", {
		id,
		className: "dk-field-error",
		...rest,
		children: [/* @__PURE__ */ jsx(Icon, { name: "alert-circle" }), /* @__PURE__ */ jsx("span", { children })]
	});
}
function Hint({ id, children, more, less }) {
	const labels = useContext(HintLabels);
	more = more ?? labels.more;
	less = less ?? labels.less;
	const ref = useRef(null);
	const [open, setOpen] = useState$1(false);
	const [clipped, setClipped] = useState$1(false);
	useLayoutEffect(() => {
		const el = ref.current;
		if (el && !open) setClipped(el.scrollHeight > el.clientHeight + 1);
	}, [children, open]);
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-hint",
		children: [/* @__PURE__ */ jsx("p", {
			id,
			ref,
			className: `dk-hint cn-hint__text${open ? " is-open" : ""}`,
			children
		}), (clipped || open) && /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "cn-hint__more",
			"aria-expanded": open,
			onClick: () => setOpen(!open),
			children: open ? less : more
		})]
	});
}
function TextInput({ mono, className = "", ...rest }) {
	return /* @__PURE__ */ jsx("input", {
		className: `dk-input${mono ? " dk-input--mono" : ""} ${className}`.trim(),
		...rest
	});
}
function Select({ children, className = "", ...rest }) {
	return /* @__PURE__ */ jsx("span", {
		className: "dk-select-wrap",
		children: /* @__PURE__ */ jsx("select", {
			className: `dk-select ${className}`.trim(),
			...rest,
			children
		})
	});
}
function Switch({ checked, onChange, label, children, testId, disabled, describedBy }) {
	const id = useId();
	const button = /* @__PURE__ */ jsx("button", {
		type: "button",
		role: "switch",
		className: "dk-switch",
		"aria-checked": checked ? "true" : "false",
		"aria-label": children ? void 0 : label,
		"aria-labelledby": children ? id : void 0,
		"aria-describedby": describedBy,
		"data-testid": testId,
		disabled,
		onClick: () => onChange(!checked)
	});
	if (!children) return button;
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-switchrow",
		children: [/* @__PURE__ */ jsx("span", {
			id,
			children
		}), button]
	});
}
function RadioCards({ name, legend, value, options, onChange, testId, columns }) {
	return /* @__PURE__ */ jsx("div", {
		className: `cn-cards${columns === 3 ? " cn-cards--three" : ""}`,
		role: "radiogroup",
		"aria-label": legend,
		"data-testid": testId,
		children: options.map((o) => /* @__PURE__ */ jsxs("label", {
			className: `cn-card${value === o.value ? " is-on" : ""}`,
			children: [/* @__PURE__ */ jsx("input", {
				type: "radio",
				className: "dk-radio",
				name,
				"data-testid": testId ? `${testId}-${o.value}` : void 0,
				checked: value === o.value,
				onChange: () => onChange(o.value)
			}), /* @__PURE__ */ jsxs("span", {
				className: "cn-card__words",
				children: [/* @__PURE__ */ jsx("span", { children: o.label }), o.description && /* @__PURE__ */ jsx("span", {
					className: "cn-card__desc",
					children: o.description
				})]
			})]
		}, String(o.value)))
	});
}
function Check({ checked, onChange, children, testId }) {
	return /* @__PURE__ */ jsxs("label", {
		className: "dk-choice",
		children: [/* @__PURE__ */ jsx("input", {
			type: "checkbox",
			className: "dk-check",
			"data-testid": testId,
			checked,
			onChange: (e) => onChange(e.target.checked)
		}), /* @__PURE__ */ jsx("span", { children })]
	});
}
function Notice({ tone = "info", role, testId, children, className = "" }) {
	const icon = {
		info: "info",
		ok: "check-circle",
		warn: "warning",
		error: "alert-circle"
	}[tone] || "info";
	return /* @__PURE__ */ jsxs("div", {
		className: `ui-callout ui-callout--${tone} ${className}`.trim(),
		role,
		"data-testid": testId,
		children: [/* @__PURE__ */ jsx(Icon, {
			name: icon,
			className: "ui-callout__icon"
		}), /* @__PURE__ */ jsx("div", {
			className: "ui-callout__text",
			children
		})]
	});
}
function FixNotice({ severity = "info", title, reason, who, fix, secondary, testId, className = "", children }) {
	const level = NOTICE_ROLE[severity] ? severity : "info";
	const draw = (a, variant) => {
		if (!a || !a.label) return null;
		const cls = `dk-btn dk-btn--${variant} dk-btn--sm`;
		if (a.href) return /* @__PURE__ */ jsx("a", {
			className: cls,
			href: a.href,
			"data-testid": a.testId,
			children: a.label
		});
		if (typeof a.onClick !== "function") return null;
		return /* @__PURE__ */ jsx("button", {
			type: "button",
			className: cls,
			onClick: a.onClick,
			disabled: a.disabled,
			"data-testid": a.testId,
			children: a.label
		});
	};
	const primary = draw(fix, "primary");
	const second = draw(secondary, "ghost");
	return /* @__PURE__ */ jsxs("div", {
		className: `ui-callout ui-callout--${level} ui-notice ${className}`.trim(),
		role: NOTICE_ROLE[level],
		"data-severity": level,
		"data-testid": testId,
		children: [
			/* @__PURE__ */ jsx(Icon, {
				name: NOTICE_ICON[level],
				className: "ui-callout__icon"
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "ui-callout__text",
				children: [
					title && /* @__PURE__ */ jsx("strong", {
						className: "ui-callout__title",
						children: title
					}),
					reason && /* @__PURE__ */ jsx("span", {
						className: "ui-notice__reason",
						children: reason
					}),
					who && /* @__PURE__ */ jsx("span", {
						className: "ui-notice__who",
						children: who
					}),
					children
				]
			}),
			(primary || second) && /* @__PURE__ */ jsxs("div", {
				className: "ui-callout__actions",
				children: [primary, second]
			})
		]
	});
}
var HintLabels, NOTICE_ROLE, NOTICE_ICON;
var init_controls = __esmMin((() => {
	init_react();
	init_Icon();
	init_jsx_runtime();
	HintLabels = createContext({
		more: "More",
		less: "Less",
		optional: "optional"
	});
	NOTICE_ROLE = {
		error: "alert",
		warn: "status",
		info: "note"
	};
	NOTICE_ICON = {
		info: "info",
		warn: "warning",
		error: "alert-circle"
	};
}));

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.en.json
var connector_en_default = {
	"answer.title": "Where it posts and how it replies",
	"answer.replyLabel": "While the agent works",
	"answer.reply.off": "Typing, then the answer",
	"answer.reply.progress": "Progress: the tools it uses",
	"answer.reply.stream": "Live: the answer as it is written",
	"answer.reply.reasoning": "Thinking: the model's thinking, then the answer",
	"answer.replyHelp": "Progress and Live show one working message, and the answer replaces it. On a platform with drafts, Live shows a private chat a draft instead, and the answer follows it. A long answer goes on in new messages.",
	"answer.replyReasoningHelp": "Thinking shows the model's thinking, as it writes it, to every sender of this binding. Use it only where that is fine.",
	"answer.conversationLabel": "Conversations",
	"answer.conversationHelp": "Send /new (or !new) in the app to start a new chat.",
	"answer.conversation.sender": "One chat per person",
	"answer.conversation.chat": "One chat per group or channel",
	"answer.conversation.window": "Per person, new after a quiet time",
	"answer.conversation.thread": "New chat per message; replies go on",
	"answer.window": "Quiet time, in minutes",
	"answer.windowRange": "Use a whole number from 1 to {{max}}.",
	"answer.languageLabel": "Reply language",
	"answer.languageHelp": "The notes the bot writes itself, like confirmations and refusals. The answers of the model follow the language of the conversation.",
	"answer.language.auto": "Automatic (your interface language, else the language of the sender)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Send the files the agent makes",
	add: "Add",
	more: "More",
	less: "Less",
	"answer.filesHelp": "After the answer, up to 5 files. Programs and scripts are not sent. The size limit is under File sizes and reply language.",
	"answer.summary": "Answers: {{reply}} · {{conversation}}",
	"answer.short.off": "typing",
	"answer.short.progress": "progress",
	"answer.short.stream": "live answer",
	"answer.short.reasoning": "thinking shown",
	"answer.short.sender": "a chat per person",
	"answer.short.chat": "a chat per group",
	"answer.short.window": "new chat after {{count}} min",
	"answer.short.thread": "a chat per message",
	"approval.title": "Timers and triggers from the chat",
	"approval.help": "When the agent sets up something that runs later (\"in 10 minutes\", \"every day\"), every run is one model run.",
	"approval.mode.ask": "Asks first: the bot proposes it in the chat and the person answers yes or no",
	"approval.mode.auto": "Runs at once: it is set up and the person is told how to cancel it",
	"approval.mode.auto_readonly": "Runs at once when the runs only read and report; otherwise asks first",
	"approval.limitsHelp": "These limits bound what is set up without asking. Leave a field empty for its default. Anything over a limit is asked instead.",
	"approval.max_pending": "Most timers and triggers at once",
	"approval.min_gap_minutes": "Fewest minutes between runs of a recurring trigger",
	"approval.max_runs_per_day": "Most runs a day, all together",
	"approval.max_lifetime_days": "Longest lifetime, in days",
	"approval.invalid": "Use a whole number from 1 to {{max}}, or leave it empty.",
	"approval.default": "Default: {{value}}.",
	"approval.summary": "Triggers: {{mode}}",
	"approval.effect": "Proposals: {{mode}}",
	"approval.effectChange": "Changes and deletes: {{mode}}",
	"approval.limits": "Limits",
	"approval.acts.title": "Runs may act",
	"approval.acts.help": "Off: the runs of a trigger made from this chat only read and report. On: they may also do what you tick below, and only what the agent has.",
	"approval.acts.modes": "Asks first: you always decide. Runs at once: only when you are a verified person and every act is ticked here.",
	"approval.acts.act.files": "Write files in the agent's folders",
	"approval.acts.act.files.effect": "A run can create and change files the agent keeps.",
	"approval.acts.act.addons": "Use the actions of the agent's add-ons",
	"approval.acts.act.addons.effect": "A run can use what the add-ons of the agent do, including commands.",
	"approval.acts.act.send": "Send messages beyond where it reports",
	"approval.acts.act.send.effect": "A run can write to other chats and channels on its own.",
	"approval.acts.act.spend": "Use paid or external tools and the network",
	"approval.acts.act.spend.effect": "A run can call services outside LocalAI, which may cost money.",
	"approval.acts.lacks": "The agent does not have this.",
	"approval.acts.sensitive": "Sensitive",
	"approval.effectActs": ", runs may: {{acts}}",
	"approval.actShort.act.files": "write files",
	"approval.actShort.act.addons": "use add-ons",
	"approval.actShort.act.send": "send messages",
	"approval.actShort.act.spend": "use paid or external tools",
	"approval.short.ask": "asks first",
	"approval.short.auto": "runs at once",
	"approval.short.auto_readonly": "runs at once if read-only",
	"files.title": "Files",
	"files.help": "Leave a field empty to use the limit of the add-on. Your limit can only be lower than that.",
	"files.receiveLabel": "Largest file it reads, in MiB",
	"files.sendLabel": "Largest file it sends, in MiB",
	"files.invalid": "Use a number greater than 0.",
	"files.tooHigh": "The add-on allows at most {{max}} here.",
	"files.now": "Now: {{limit}} ({{layer}}).",
	"files.receiveHelp": "Files that people send to the bot. A bigger file is refused, and the bot says which limit it hit.",
	"files.sendHelp": "Files that the agent makes and the bot sends back. A bigger file is not sent, and the bot says which limit it hit.",
	"files.addon.off": "This add-on does not move files in this direction, so there is nothing to set.",
	"files.addon.declared": "The add-on declares up to {{max}}.",
	"files.addon.open": "The add-on declares no limit, so the limit of the platform applies.",
	"files.host": "No bot can move a file above {{max}}. An administrator sets this in the settings.",
	"files.layer.owner": "limit set for this bot",
	"files.layer.addon": "limit of the add-on",
	"files.layer.host": "limit of the platform",
	"perm.agentLacks": "The agent does not have this.",
	"perm.rule": "Listed people can use the ticked permissions. Sensitive ones also need a verified person.",
	"perm.sensitive": "Verified people only",
	"perm.sensitiveHelp": "Sensitive. Never given to a role. Only a verified person can use it, and every use is recorded.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Place the bot may post",
	"perm.channelsHelp": "Places the agent may post to when a listed person asks, besides the chat where it replies. This does not decide who the bot listens to: see Channels where the bot listens. At most {{max}}.",
	"perm.channelsOff": "Switch on \"Post to other channels\" above to choose the places the bot may post.",
	"perm.channelId": "Channel ID",
	"perm.channelLabel": "Name",
	"perm.channelAdd": "Add a place",
	"perm.channelRemove": "Remove place {{id}}",
	"perm.remove": "Remove",
	"perm.channelFull": "The list is full.",
	"perm.channelProblem.id": "Each place needs an ID of 1 to {{max}} bytes, with no space.",
	"perm.channelProblem.label": "A name has at most {{max}} characters.",
	"perm.channelProblem.repeat": "A place is listed twice.",
	"perm.channelProblem.count": "At most {{max}} places.",
	"perm.triggersNeed": "Turn on Propose triggers to use this.",
	"pair.start": "Verify a person",
	"pair.startHelp": "Makes a code. Send it to the bot as a direct message from the account to verify, within ten minutes. The code works once.",
	"pair.needSave": "Save this bot first, then verify a person.",
	"pair.codeTitle": "Your verification code",
	"pair.codeHelp": "Send this code to the bot as a direct message from the account to verify. It is shown only now, works once and expires at {{time}}.",
	"pair.codeGone": "The code expired. Make a new one if the person is not verified yet.",
	"pair.done": "Verified: {{sender}}.",
	"pair.dismiss": "Hide the code",
	"pair.none": "Nobody is verified.",
	"pair.expires": "ends {{time}}",
	"pair.full": "Three people are verified. Remove one to verify another.",
	"access.title": "Check it",
	"access.needSave": "Save this bot first to see who it refused recently.",
	"access.refresh": "Refresh",
	"access.who": "sender {{senders}}",
	"can.sender.role": "Role: {{title}}",
	"can.fromForm": "Computed from the form as it is now. Save to keep these settings.",
	"can.fromFormNew": "Not saved yet. Computed from the form as it is now.",
	"can.loading": "Checking what this bot can do",
	"can.stale": "Updating",
	"can.errorTitle": "Could not check what this bot can do",
	"can.retry": "Try again",
	"can.allowed": "Allowed",
	"can.via.paired": "because this person is verified",
	"can.via.allowlist": "because this person is listed",
	"can.via.agentConnection": "because this person is verified and the agent is connected to the add-on",
	"can.via.role": "through the role {{role}}",
	"can.then": "Not checked yet: {{list}}.",
	"can.then.server": "the server settings",
	"can.then.tools": "the Tools switch of the agent",
	"can.then.agent": "the permissions of the agent",
	"can.then.connection": "the permissions of this connection",
	"can.then.sender": "who is sending",
	"can.then.approval": "how proposals are confirmed",
	"can.noMessage": "Not allowed.",
	"fix.open_connection": "Show the setting",
	"fix.open_agent": "Open the agent",
	"fix.open_server_setting": "Open Settings",
	"fix.pair_sender": "Verify a person",
	"fix.add_person": "Add a person",
	"fix.save": "Keep these changes",
	"fix.token": "Paste the token",
	"fix.tokenNew": "Paste a new token",
	"fix.agent": "Choose an agent",
	"fix.usual": "Choose permissions",
	"fix.turnOn": "Turn on",
	"fix.newTab": "(opens in a new tab)",
	"fix.askAdmin": "Ask an administrator",
	"ready.title": "Status",
	"ready.checkingSummary": "Checking what the form will do.",
	"ready.allGood": "Everything needed is in place.",
	"ready.showAll": "Show all {{count}}",
	"ready.showProblems": "Show only what needs attention",
	"ready.checking": "Checking.",
	"ready.unchecked": "Could not check this. See \"What this bot can do\" below.",
	"ready.row.token": "Token",
	"ready.row.agent": "Agent",
	"ready.row.who": "Who may use it",
	"ready.row.permissions": "Permissions",
	"ready.row.addons": "Add-on tools",
	"ready.row.triggers": "Triggers",
	"ready.row.files": "Files",
	"ready.row.notify": "Notifications",
	"ready.state.ok": "OK",
	"ready.state.attention": "Needs attention",
	"ready.state.off": "Off",
	"ready.state.after_save": "After you save",
	"ready.state.broken": "Not working",
	"ready.state.checking": "Checking",
	"ready.state.unknown": "Unknown",
	"ready.token.missing": "Paste the token of the bot. Without it nothing is received.",
	"ready.token.newTyped": "The token is checked with the platform when you save.",
	"ready.token.typed": "The new token is checked with the platform when you save.",
	"ready.token.failed": "The platform refused the token: {{reason}}",
	"ready.token.checked": "The platform accepted the token. {{bot}}",
	"ready.token.saved": "A token is saved. The platform accepted it when it was saved.",
	"ready.agent.none": "Choose the agent that answers.",
	"ready.agent.credentialsOnly": "No agent. This connection only holds the credentials and answers no message.",
	"ready.agent.gone": "The chosen agent is not in your list any more. Choose another.",
	"ready.agent.noModel": "{{name}} has no model, so it cannot answer. Give it one.",
	"ready.agent.ok": "{{name}} answers, with the model {{model}}.",
	"ready.agent.okUnknown": "An agent is chosen.",
	"ready.who.anyone": "Anyone who can message the bot may use it.",
	"ready.who.nobody": "Nobody is listed yet, so the bot ignores every message. Add a person.",
	"ready.who.channelsOnly": "Only channels are on the list. People in a channel can chat, but they can use the ticked permissions only where the channel is set to Let everyone here ask for actions.",
	"ready.who.listed_one": "{{count}} person or chat is listed.",
	"ready.who.listed_other": "{{count}} people or chats are listed.",
	"ready.who.mixed": "{{count}} entries are listed, people and channels.",
	"ready.perm.none": "No permission is on. Senders can chat, and nothing else.",
	"ready.perm.noneSaved": "No permission is on, so files, memory, triggers and posts are off.",
	"ready.perm.onlyOwnRows": "The other permissions are off. Triggers and files are below.",
	"ready.perm.ok_one": "{{count}} permission is on and a sender can use it.",
	"ready.perm.ok_other": "{{count}} permissions are on and a sender can use them.",
	"ready.perm.dead_one": "Nobody can use {{names}}. {{message}}",
	"ready.perm.dead_other": "Nobody can use {{count}} of the permissions that are on: {{names}}. First: {{message}}",
	"ready.addons.off": "The agent has the {{addon}} tools {{tools}}, and it cannot use them in this chat until you turn on \"{{permission}}\".",
	"ready.addons.blocked": "The agent has the {{addon}} tools {{tools}}, and they are held back. {{message}}",
	"ready.addons.ok": "The agent can use the {{addon}} tools {{tools}} in this chat.",
	"ready.addons.paired": "Verified people can use the {{addon}} write tools {{tools}} in this chat, because this agent is connected to {{connection}} (write mode: {{mode}}). Listed people who are not verified need \"{{permission}}\".",
	"ready.addons.removed": "You turned off \"{{permission}}\", so nobody can use the {{addon}} write tools {{tools}} in this chat, not even verified people. Turn it on to bring them back; listed people who are not verified get them too.",
	"ready.addons.modeOff": "The agent has the {{addon}} write tools {{tools}}, and they are held back because the write mode of {{connection}} is off. Change the write mode on that connection.",
	"ready.addons.mode.auto": "runs at once",
	"ready.addons.mode.propose": "asks first",
	"ready.triggers.off": "The agent cannot set reminders or scheduled tasks here.",
	"ready.triggers.blocked": "Triggers are on, and they cannot be used. {{message}}",
	"ready.triggers.ok.ask": "The agent can propose triggers. You confirm each one before it starts.",
	"ready.triggers.ok.auto": "The agent can propose triggers. They start at once, without asking you.",
	"ready.triggers.ok.auto_readonly": "The agent can propose triggers. A trigger that only reads starts at once; you confirm any other.",
	"ready.files.offReceive": "Senders cannot send files to the agent.",
	"ready.files.offBoth": "Senders cannot send files to the agent, and the bot sends none back.",
	"ready.files.blocked": "Receiving files is on, and it cannot be used. {{message}}",
	"ready.files.ok": "Senders can send files to the agent, and the bot can send files back.",
	"ready.files.okReceive": "Senders can send files to the agent. The bot sends none back.",
	"ready.notify.off": "No chat gets notices from this bot.",
	"ready.notify.ok": "Notices go to the chat {{chat}}.",
	dismiss: "Dismiss",
	credentialsOnly: "Credentials only",
	agentCredentialsOnly: "No agent (credentials only)",
	agentOptionalHint: "Optional. Without an agent this connection only holds the token, the repository list and the write mode for your chats. It answers no messages. Choose an agent to let it listen.",
	"sender.line_one": "{{name}} · {{count}} message · {{id}}",
	"sender.line_other": "{{name}} · {{count}} messages · {{id}}",
	"ready.blocker.nobodyLetIn": "Nobody is let in yet.",
	"ready.blocker.nobodyPaired": "This needs a verified person, and nobody is verified yet.",
	optional: "optional",
	"approvals.title": "Tools that run at once",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "Asks first",
	"approvals.state.runs": "Runs at once",
	"approvals.state.idle": "Set to run at once, does nothing now",
	"approvals.state.other": "Still asks this sender first",
	"approvals.line.asks": "A card is waiting for your OK.",
	"approvals.line.runs": "For the owner's own chats and for verified people. Everyone else is still asked.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "Only the owner and a verified person skip the card. This kind of sender is asked.",
	"dup.text": "This bot is also connected as {{name}}. Both connections will answer the same message.",
	"dup.turnOff": "Turn this one off",
	"dup.openOther": "Open {{name}}",
	"dup.saveAnyway": "Save anyway",
	"dup.goBack": "Go back",
	"dup.confirmHelp": "Save it anyway only if you want to get two answers to each message.",
	"access.noteSave.title": "Notes",
	"access.noteSave.now": "Saves notes at once and tells you, with an Undo",
	"access.noteSave.ask": "Notes from this kind of sender wait for the owner",
	"trust.answer": "Answer only",
	"trust.act": "Let everyone here ask for actions",
	"ready.row.channelTrust": "Channels where the bot listens",
	"ready.row.postTo": "Place the bot may post",
	"ready.channelTrust.act": "People in {{channels}} can ask for everyday actions. Sensitive ones still need a verified person.",
	"ready.channelTrust.answer": "People in {{channels}} cannot use actions: set it to Let everyone here ask for actions.",
	"ready.channelTrust.noCaps": "Nothing is ticked under permissions, so files and other actions are refused even where everyone may ask.",
	"fix.trust": "Set the channel",
	"can.via.channel": "Everyone in this channel can ask for this because the channel is set to Let everyone here ask for actions",
	"ready.postTo_one": "The bot may post to 1 other place when a listed person asks. That does not trust the people in it.",
	"ready.postTo_other": "The bot may post to {{count}} other places when a listed person asks. That does not trust the people in them.",
	"access.toolsTitle": "Add-on tool calls",
	"access.toolsHelp": "The latest calls of add-on tools that used this connection or came in through this bot, newest first, at most 20. They hold tool names and reasons, never what was asked or answered. They reset when the server restarts.",
	"access.toolsNone": "No tool call yet.",
	"access.outcome.ok": "ok",
	"access.outcome.held": "held",
	"access.outcome.denied": "denied",
	"access.outcome.error": "failed",
	"ready.addons.confirmChat": "A verified person can confirm the {{addon}} writes in the chat: the bot writes each one there and they answer yes or no.",
	"access.outcome.confirmed": "confirmed",
	"access.outcome.cancelled": "cancelled",
	"access.outcome.expired": "expired",
	"access.askedBy": "asked by {{sender}}",
	"access.chat": "in {{chat}}",
	"sender.chat": "in {{chat}}",
	"sender.reason.not_listed": "not a listed person",
	"sender.reason.not_addressed": "the message did not name the bot",
	"ready.notReady": "Not ready yet.",
	"ready.fixCount_one": "{{count}} thing to fix",
	"ready.fixCount_other": "{{count}} things to fix",
	"ready.quiet_one": "{{count}} thing to set",
	"ready.quiet_other": "{{count}} things to set",
	"ready.quietDone": "Nothing left to set",
	"matrix.title": "Who can do what",
	"loops.title": "Waits and timers",
	"loops.help": "What the agent may do later in this chat by itself. These belong to the bot: a role never gets them.",
	"matrix.note": "The switches and the role boxes are yours to set. Every other cell is worked out from your settings as they are now, by the same check the host runs for each message.",
	"matrix.capability": "Permission",
	"matrix.pick": "Kind of sender",
	"matrix.col.on": "On for this bot",
	"matrix.col.paired": "Verified person",
	"matrix.col.listed": "Listed person",
	"matrix.col.channel_acts": "Channel: everyone acts",
	"matrix.col.channel_member": "Channel: answer only",
	"matrix.col.anyone": "Anyone",
	"matrix.state.yes": "Yes",
	"matrix.state.asks": "Asks first",
	"matrix.state.no": "No",
	"matrix.state.waiting": "Waiting for a person",
	"matrix.state.off": "Off",
	"matrix.state.unknown": "Not known",
	"matrix.row.tools": "Change things in connected services",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Why a cell says No or Off",
	"matrix.detail.none": "Choose a cell to read why.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Reset to the usual set",
	"matrix.more": "Details",
	"matrix.less": "Hide details",
	"matrix.nobodyVerified": "Nobody is verified yet.",
	"who.title": "Who can talk to the bot",
	"who.onlyChosen": "Only people I choose",
	"who.anyone": "Anyone who can message it",
	"who.people": "People",
	"who.peopleAndChannels": "People and channels",
	"who.peopleNone": "Nobody is listed yet. Add a person below.",
	"who.channels": "Channels",
	"who.channelsNote": "People in a channel can act only inside that channel, never in a direct message.",
	"who.add": "Add a person or channel",
	"who.recent": "Recent people who wrote to the bot. Click one to add them.",
	"who.addPerson": "Add {{name}}",
	"who.verified": "Verified",
	"who.listed": "Listed",
	"who.verify": "Verify",
	"who.verifyPerson": "Verify {{name}}",
	"who.remove": "Remove",
	"who.removePerson": "Remove {{name}}",
	"who.removeChannel": "Remove {{name}}",
	"who.levelFor": "What people in {{channel}} can do",
	"answer.more": "File sizes and reply language",
	"perm.channelsSwitch": "Go to the switch",
	"perm.channelWho": "Who can make it post",
	"perm.channelWhoFor": "Who can make the bot post in {{id}}",
	"perm.channelWho.any": "When any allowed person asks",
	"perm.channelWho.verified": "Only when a verified person asks",
	"notify.label": "Send my reminders and run results to",
	"notify.none": "Nowhere",
	"notify.people": "People",
	"notify.channels": "Channels",
	"notify.saved": "{{id}} (saved ID)",
	"notify.other": "Another ID...",
	"notify.otherLabel": "Chat ID",
	"try.title": "Try it",
	"try.help": "Choose who writes, where, and what they ask for. This runs the check the host runs for every message, on the form as it is now.",
	"try.noone": "Add a person first. Then you can try what they may do.",
	"try.whoLabel": "Who",
	"try.placeLabel": "Where",
	"try.actionLabel": "What they ask for",
	"try.someoneIn": "Someone in {{channel}}",
	"try.anyone": "Anyone",
	"try.role": "Someone with the role {{role}}",
	"try.dm": "Direct message",
	"try.where.dm": "in a direct message",
	"try.where.channel": "in {{channel}}",
	"try.is.paired": "{{who}} is a verified person, writing {{where}}.",
	"try.is.listed": "{{who}} is a listed person, writing {{where}}.",
	"try.is.channelActs": "Someone in {{channel}}, where everyone here can ask for actions.",
	"try.is.channelAnswers": "Someone in {{channel}}, where people only get answers.",
	"try.is.anyone": "Anyone who can message the bot is let in.",
	"try.is.role": "A person with the role {{role}} is let in.",
	"try.verdict.allowed": "Allowed.",
	"try.verdict.asks": "Allowed, but it asks first.",
	"try.verdict.refused": "Refused.",
	"try.loading": "Checking...",
	"try.error": "The check did not answer. Use Try again in the table above.",
	"try.unknown": "The host gave no answer for this kind of sender.",
	"try.note": "Nothing is sent to the platform and nothing is saved.",
	"refusals.title": "Recent refusals",
	"refusals.help": "What the bot refused since the server started, newest first. It holds IDs, names and chats, never message text. This log is kept in memory only: it is empty after the server restarts.",
	"refusals.none": "Nothing refused since the server started.",
	"refusals.refused": "refused",
	"refusals.action": "asked for: {{action}}",
	"refusals.talk": "wrote to the bot",
	"refusals.allow": "Allow {{name}}",
	"refusals.act": "Let {{channel}} members act",
	"perm.channelPickOther": "Other: type an ID",
	"perm.channelHint.verified": "Scheduled runs cannot post here. Choose \"When any allowed person asks\" to let them.",
	"perm.channelHint.any": "Scheduled runs can post here.",
	"perm.channelNoListen": "The bot does not listen in this channel, so it will only post there.",
	"who.post.none": "The bot cannot post here.",
	"who.post.add": "Let the bot post here too",
	"who.post.addFor": "Let the bot post in {{name}} too",
	"who.post.verified": "Posts here only when a verified person asks.",
	"who.post.any": "Posts here when any allowed person asks.",
	"who.post.show": "Show the place",
	"who.post.showFor": "Show the place for {{name}}",
	agentLink: "Open the agent {{name}}",
	"saved.created": "Connection added.",
	"saved.nothing": "Saved. Nothing changed.",
	"saved.changed": "Saved. Changed: {{what}}.",
	"saved.part.name": "name",
	"saved.part.agent": "agent",
	"saved.part.who": "who it accepts",
	"saved.part.permissions": "permissions",
	"saved.part.approval": "trigger approval and acts",
	"saved.part.files": "file settings",
	"saved.part.notify": "notifications",
	"saved.dropped.title": "This connection no longer allows these acts, so the runs of these triggers lose them:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "Running",
	"conn.state.off": "Off",
	"conn.state.attention": "Needs attention",
	"conn.state.ready": "Ready",
	"conn.row.open": "{{name}}: {{state}}. Show details",
	"conn.row.menu": "More actions for {{name}}",
	"conn.row.testNamed": "Test {{name}}",
	"conn.fix.token": "Fix token",
	"conn.reason.noToken": "No token is saved.",
	"conn.reason.duplicate": "Answers the same bot as {{name}}.",
	"conn.reason.testFailed": "The last test failed: {{reason}}",
	"conn.kv.service": "Service",
	"conn.kv.accepts": "Accepts",
	"conn.kv.replies": "Replies",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Saved",
	"conn.kv.notSaved": "Not saved",
	"conn.kv.agents": "Agents",
	"usedBy.count_one": "Used by {{count}} agent",
	"usedBy.count_other": "Used by {{count}} agents",
	"usedBy.none": "Not used by any agent",
	"conn.pane.lastTest": "Last test",
	"conn.pane.never": "Not tested in this browser yet.",
	"conn.pane.passed": "Passed {{when}}.",
	"conn.pane.failed": "Failed {{when}}.",
	"conn.pane.connection": "Connection",
	"conn.pane.remove": "Remove",
	"conn.pane.test": "Test connection",
	"conn.pane.testing": "Testing...",
	"conn.sheet.addDesc": "Name it, add its token and choose the agent that answers.",
	"conn.sheet.editDesc": "Changes apply when you save. A saved token is never shown again.",
	"conn.sheet.connection": "Connection",
	"conn.sheet.who": "Who can talk to it",
	"conn.sheet.may": "What it may do",
	"conn.sheet.replies": "Replies, files and places",
	"conn.sheet.check": "Check what it will do",
	"conn.sheet.saveAndTest": "Save and test",
	"conn.sheet.saving": "Saving...",
	"conn.sheet.testFailed": "The connection is saved, but the test failed.",
	"conn.sheet.testFailedNoReason": "No reason was given.",
	"conn.sheet.testAgain": "Test again",
	"conn.sheet.close": "Close",
	"conn.sheet.agentFixed": "Answers with agent {{name}}",
	"conn.preset.label": "Permissions",
	"conn.preset.answer": "Answer only",
	"conn.preset.answerHelp": "It replies to messages. This connection adds no permission of its own.",
	"conn.preset.standard": "Standard",
	"conn.preset.standardHelp": "The usual set that the agent holds: {{list}}.",
	"conn.preset.standardNone": "The usual set. This agent holds none of it.",
	"conn.preset.custom": "Custom",
	"conn.preset.customHelp": "Choose each permission and who may use it.",
	"conn.preset.note": "A preset never turns on a sensitive permission. Use Custom for those. The add-on connections that the agent holds have their own rules: verified people can still use their write tools. Change that on the agent, under \"What it can use\".",
	"conn.discard.title": "Discard your changes?",
	"conn.discard.message": "You changed this connection and did not save it.",
	"conn.discard.confirm": "Discard changes",
	"share.label": "Share",
	"share.button": "Share {{name}}",
	"share.intro": "People you add can use this connection in their own chats and agents. They see its name and state, never its token or its settings. Messages to the bot still reach your agent.",
	"share.roleUse": "Can use",
	"share.roleUseHelp": "Can use it in their chats and agents. Cannot see the token, change it or share it.",
	"shared.title": "Shared with you",
	"shared.text": "Other people let you use these connections in your chats and agents. Only their owner can change them.",
	"shared.on": "Listening",
	"shared.off": "Off",
	"shared.by": "Shared by {{name}}",
	loginNeedsHost: "This version of LocalAI cannot log in from this page. Update LocalAI to connect here."
};

//#endregion
//#region addons/internal/connector-ui/src/connector.js
function localizeCapabilities(list) {
	return (list || []).map((c) => ({
		...c,
		title: c.localized_title || c.title,
		description: c.localized_description || c.description
	}));
}
function localizeAccess(view) {
	if (!view || !Array.isArray(view.subjects)) return view;
	return {
		...view,
		tool_outcomes: (view.tool_outcomes || []).map((e) => e.localized_message ? {
			...e,
			message: e.localized_message
		} : e),
		subjects: view.subjects.map((subject) => ({
			...subject,
			decisions: (subject.decisions || []).map((d) => d.localized_message ? {
				...d,
				message: d.localized_message
			} : d)
		}))
	};
}
function emptyApproval() {
	return {
		mode: "ask",
		acts: [],
		max_pending: "",
		min_gap_minutes: "",
		max_runs_per_day: "",
		max_lifetime_days: ""
	};
}
function approvalForm(a) {
	const f = {
		...emptyApproval(),
		mode: a?.mode || "ask",
		acts: Array.isArray(a?.acts) ? [...a.acts] : []
	};
	for (const { key } of APPROVAL_LIMITS) f[key] = a?.[key] > 0 ? String(a[key]) : "";
	return f;
}
function approvalProblem(a) {
	if (!a) return "";
	if (!APPROVAL_MODES.includes(a.mode)) return "mode";
	if ((a.acts || []).some((n) => !APPROVAL_ACTS.includes(n))) return "acts";
	for (const { key, max } of APPROVAL_LIMITS) {
		const v = String(a[key] ?? "").trim();
		if (v === "") continue;
		const n = Number(v);
		if (!Number.isInteger(n) || n < 1 || n > max) return key;
	}
	return "";
}
function approvalPayload(a) {
	const body = {
		mode: APPROVAL_MODES.includes(a?.mode) ? a.mode : "ask",
		acts: APPROVAL_ACTS.filter((n) => (a?.acts || []).includes(n))
	};
	for (const { key } of APPROVAL_LIMITS) body[key] = Number(String(a?.[key] ?? "").trim()) || 0;
	return body;
}
function usualCaps(capabilities) {
	return (capabilities || []).filter((c) => c.usual && !c.sensitive).map((c) => c.name);
}
function loopCaps(capabilities) {
	return (capabilities || []).filter((c) => c.binding_only).sort((a, b) => (LOOP_ORDER.indexOf(a.name) + 1 || 99) - (LOOP_ORDER.indexOf(b.name) + 1 || 99));
}
function matrixCaps(capabilities) {
	return (capabilities || []).filter((c) => !c.binding_only);
}
function agentHeld(agent) {
	if (!agent || !Array.isArray(agent.builtins)) return null;
	return agent.builtins.length > 0 ? agent.builtins : DEFAULT_CONNECTOR_GRANTS;
}
function usualFor(capabilities, held) {
	const usual = usualCaps(capabilities);
	return {
		caps: usual.filter((n) => agentHas(held, n)),
		skipped: usual.filter((n) => !agentHas(held, n))
	};
}
function withUsualCaps(form, capabilities, held) {
	const caps = usualFor(capabilities, held).caps;
	const grants = (form.grants || []).map((g) => ({
		...g,
		caps: g.caps.filter((x) => caps.includes(x))
	})).filter((g) => g.caps.length > 0);
	return {
		...form,
		caps,
		grants
	};
}
function channelOnly(form, lists) {
	if (!Array.isArray(lists) || lists.length < 2 || form?.accept_any) return false;
	const allow = form?.allow || [];
	return allow.length > 0 && listEntries(allow, lists, 0).length === 0 && !allow.some((x) => trustOf(form, x) === "act");
}
function trustOf(form, entry) {
	return form?.allow_trust?.[entry] === "act" ? "act" : "answer";
}
function trustPayload(form) {
	if (form.accept_any) return {};
	const allow = new Set((form.allow || []).map((x) => x.trim()));
	return Object.fromEntries(Object.entries(form.allow_trust || {}).filter(([k, v]) => allow.has(k) && (v === "act" || v === "answer")));
}
function channelEntries(form, isChannel) {
	return (form?.allow || []).filter((x) => isChannel(x));
}
function trustAfter(form, allow, isChannel) {
	const out = {};
	for (const x of allow) if (form.allow_trust?.[x]) out[x] = form.allow_trust[x];
	else if (!(form.allow || []).includes(x) && isChannel(x)) out[x] = "act";
	return out;
}
function setCap(form, name, on) {
	const caps = (form.caps || []).filter((x) => x !== name);
	if (on) caps.push(name);
	const grants = (form.grants || []).map((g) => ({
		...g,
		caps: g.caps.filter((x) => caps.includes(x))
	})).filter((g) => g.caps.length > 0);
	return {
		...form,
		caps,
		grants
	};
}
function roleHas(form, role, cap) {
	return (form.grants || []).some((g) => g.role === role && g.caps.includes(cap));
}
function grantableFor(kind, caps) {
	return (kind?.permissions || []).filter((p) => !p.sensitive && !p.binding_only && (caps || []).includes(p.name)).map((p) => p.name);
}
function setGrant(form, role, cap, on, capabilities = []) {
	const sensitive = capabilities.some((c) => c.name === cap && (c.sensitive || c.binding_only));
	if (on && (sensitive || !(form.caps || []).includes(cap))) return form;
	const rest = (form.grants || []).filter((g) => g.role !== role);
	const mine = (form.grants || []).find((g) => g.role === role)?.caps || [];
	const caps = on ? [...mine.filter((x) => x !== cap), cap] : mine.filter((x) => x !== cap);
	return {
		...form,
		grants: caps.length ? [...rest, {
			role,
			caps
		}] : rest
	};
}
function channelsProblem(list) {
	const channels = list || [];
	if (channels.length > 10) return "count";
	for (let i = 0; i < channels.length; i++) {
		const { id = "", label = "" } = channels[i];
		if (!id || new TextEncoder().encode(id).length > 64 || /\s/u.test(id)) return "id";
		if ([...label].length > 60) return "label";
		if (channels.slice(0, i).some((o) => o.id === id)) return "repeat";
	}
	return "";
}
function emptyConnector(capabilities, held = null) {
	return {
		id: "",
		name: "",
		token: "",
		agent_id: "",
		enabled: true,
		accept_any: false,
		allow: [],
		allow_trust: {},
		notify_chat: "",
		reply_mode: "progress",
		conversation: "sender",
		window_minutes: 60,
		send_files: true,
		reply_language: "auto",
		options: {},
		file_receive_mib: "",
		file_send_mib: "",
		approval: emptyApproval(),
		caps: capabilities ? usualFor(capabilities, held).caps : [],
		grants: [],
		channels: []
	};
}
function seedCapabilities(capabilities, { toolOnly = false, agentOptional = false, agentPicked = false } = {}) {
	return toolOnly || agentOptional && !agentPicked ? null : capabilities;
}
function bytesToMib(bytes) {
	return bytes > 0 ? String(bytes / MIB) : "";
}
function mibToBytes(mib) {
	const n = Number(String(mib ?? "").trim());
	return String(mib ?? "").trim() === "" || !Number.isFinite(n) ? 0 : Math.round(n * MIB);
}
function connectorForm(c) {
	return {
		...emptyConnector(),
		...c,
		token: "",
		file_receive_mib: bytesToMib(c.file_receive_max_bytes),
		file_send_mib: bytesToMib(c.file_send_max_bytes),
		approval: approvalForm(c.approval),
		allow_trust: { ...c.allow_trust || {} },
		caps: [...c.caps || []],
		grants: (c.grants || []).map((g) => ({
			role: g.role,
			caps: [...g.caps]
		})),
		channels: (c.channels || []).map((x) => ({
			id: x.id,
			label: x.label || "",
			approved: Boolean(x.approved)
		}))
	};
}
function fileLimitProblem(mib, allowedBytes) {
	if (String(mib ?? "").trim() === "") return "";
	const n = Number(mib);
	if (!Number.isFinite(n) || n <= 0 || mibToBytes(mib) < 1) return "invalid";
	return allowedBytes > 0 && mibToBytes(mib) > allowedBytes ? "tooHigh" : "";
}
function previewLimit(base, mib) {
	const bytes = mibToBytes(mib);
	if (!base) return null;
	if (bytes > 0 && bytes <= base.effective_bytes) return {
		bytes,
		layer: "owner"
	};
	return {
		bytes: base.effective_bytes,
		layer: base.layer
	};
}
function fileDirection(base) {
	if (!base) return "unknown";
	if (!(base.effective_bytes > 0) && !(base.allowed_bytes > 0)) return "off";
	return base.declared_bytes > 0 ? "declared" : "open";
}
function formatBytes(n) {
	if (n === 1) return "1 byte";
	if (n < 1024) return `${n} bytes`;
	const units = [
		"KiB",
		"MiB",
		"GiB",
		"TiB"
	];
	let v = n / 1024;
	let i = 0;
	while (v >= 1024 && i < units.length - 1) {
		v /= 1024;
		i++;
	}
	return `${Number(v.toFixed(1))} ${units[i]}`;
}
function connectorPayload(form, kind, token = form.token, extra = {}) {
	const body = {
		kind,
		name: (form.name || "").trim(),
		agent_id: form.agent_id || "",
		enabled: Boolean(form.enabled),
		accept_any: Boolean(form.accept_any),
		allow: form.accept_any ? [] : (form.allow || []).map((x) => x.trim()).filter((x, i, a) => x && a.indexOf(x) === i),
		allow_trust: trustPayload(form),
		notify_chat: (form.notify_chat || "").trim(),
		reply_mode: form.reply_mode || "progress",
		conversation: form.conversation || "sender",
		send_files: form.send_files !== false,
		reply_language: REPLY_LANGUAGES.includes(form.reply_language) ? form.reply_language : "auto",
		options: Object.fromEntries(Object.entries(form.options || {}).filter(([, v]) => v)),
		file_receive_max_bytes: mibToBytes(form.file_receive_mib),
		file_send_max_bytes: mibToBytes(form.file_send_mib),
		approval: approvalPayload(form.approval),
		caps: form.agent_id ? [...form.caps || []] : [],
		grants: form.agent_id ? (form.grants || []).map((g) => ({
			role: g.role,
			caps: [...g.caps]
		})) : [],
		channels: (form.channels || []).map((x) => ({
			id: x.id.trim(),
			label: (x.label || "").trim(),
			approved: Boolean(x.approved)
		}))
	};
	if (body.conversation === "window") body.window_minutes = Number(form.window_minutes) || 0;
	const secret = (token || "").trim();
	if (secret) body.token = secret;
	return {
		...body,
		...extra
	};
}
function pageLocale() {
	return (typeof document !== "undefined" ? document.documentElement?.lang : "") || [];
}
function senderLine(s, t) {
	const name = s.name || s.id;
	if (typeof t === "function") return t("sender.line", {
		name,
		count: s.count,
		id: s.id
	});
	return `${name} · ${s.count} message${s.count === 1 ? "" : "s"} · ${s.id}`;
}
function canSave(form, confirmed, hasToken = Boolean((form.token || "").trim()), files = null, agentOptional = false) {
	if (!(form.name || "").trim() || !form.agent_id && !agentOptional) return false;
	if (!form.id && !hasToken) return false;
	if (form.accept_any && !confirmed) return false;
	if (approvalProblem(form.approval)) return false;
	if (channelsProblem(form.channels)) return false;
	if (fileLimitProblem(form.file_receive_mib, files?.receive?.allowed_bytes) || fileLimitProblem(form.file_send_mib, files?.send?.allowed_bytes)) return false;
	if (form.conversation === "window") {
		const m = Number(form.window_minutes);
		if (!Number.isInteger(m) || m < 1 || m > 10080) return false;
	}
	return true;
}
function listEntries(allow, lists, index) {
	const own = (x) => {
		const first = lists.findIndex((l) => l.match && l.match(x));
		return first === -1 ? index === lists.length - 1 : first === index;
	};
	return (allow || []).filter(own);
}
function listeningChannels(form, isChannel, mixed) {
	if (mixed || form.accept_any) return [];
	return (form.allow || []).filter((x) => isChannel(x));
}
function withPlace(form, id, label = "") {
	if (!id || placeFor$1(form, id)) return form;
	return {
		...form,
		channels: [...form.channels || [], {
			id,
			label,
			approved: false
		}]
	};
}
var REPLY_MODES, CONVERSATIONS, REPLY_LANGUAGES, DUPLICATE_CONFIRMATION, duplicateOther, isDuplicateRefusal, duplicateRefusalName, MAX_WINDOW_MINUTES, APPROVAL_MODES, APPROVAL_LIMITS, APPROVAL_ACTS, agentHoldsAct, MAX_CHANNELS, MAX_CHANNEL_ID, MAX_CHANNEL_LABEL, LOOP_ORDER, AGENT_GRANT_CAPS, DEFAULT_CONNECTOR_GRANTS, agentHas, MIB, placeFor$1, offeredPlaces;
var init_connector = __esmMin((() => {
	REPLY_MODES = [
		"off",
		"progress",
		"stream",
		"reasoning"
	];
	CONVERSATIONS = [
		"sender",
		"chat",
		"window",
		"thread"
	];
	REPLY_LANGUAGES = [
		"auto",
		"en",
		"it",
		"de",
		"es",
		"fr",
		"pt-BR"
	];
	DUPLICATE_CONFIRMATION = "answer twice";
	duplicateOther = (c) => c?.duplicate?.others?.[0] || null;
	isDuplicateRefusal = (err) => err?.status === 409 && err.body?.error?.type === "duplicate_connection";
	duplicateRefusalName = (err) => typeof err?.body?.error?.param === "string" ? err.body.error.param : "";
	MAX_WINDOW_MINUTES = 10080;
	APPROVAL_MODES = [
		"ask",
		"auto",
		"auto_readonly"
	];
	APPROVAL_LIMITS = [
		{
			key: "max_pending",
			max: 50,
			fallback: 5
		},
		{
			key: "min_gap_minutes",
			max: 1440,
			fallback: 60
		},
		{
			key: "max_runs_per_day",
			max: 200,
			fallback: 10
		},
		{
			key: "max_lifetime_days",
			max: 365,
			fallback: 30
		}
	];
	APPROVAL_ACTS = [
		"act.files",
		"act.addons",
		"act.send",
		"act.spend"
	];
	agentHoldsAct = (held, act) => held === null || held === void 0 || held.includes(act);
	MAX_CHANNELS = 10;
	MAX_CHANNEL_ID = 64;
	MAX_CHANNEL_LABEL = 60;
	LOOP_ORDER = ["loops.wait", "loops.start"];
	AGENT_GRANT_CAPS = [
		"memory.write",
		"profile.write",
		"skills.write",
		"pages.write",
		"dashboard.write",
		"knowledge.write",
		"files.upload",
		"triggers.propose",
		"triggers.run",
		"talkback.channels",
		"talkback.new_channel"
	];
	DEFAULT_CONNECTOR_GRANTS = [
		"triggers.propose",
		"triggers.run",
		"talkback.channels",
		"files.upload"
	];
	agentHas = (held, name) => held === null || !AGENT_GRANT_CAPS.includes(name) || held.includes(name);
	MIB = 1024 * 1024;
	placeFor$1 = (form, id) => (form.channels || []).find((c) => c.id === id) || null;
	offeredPlaces = (form, listening) => listening.filter((id) => !placeFor$1(form, id));
}));

//#endregion
//#region addons/internal/connector-ui/src/AnswerFields.jsx
function answerT(t) {
	return (key, opts = {}) => t(key, {
		defaultValue: connector_en_default[key] ?? connector_en_default[`${key}_other`],
		...opts
	});
}
function answerSummary(c, t) {
	const s = answerT(t);
	return s("answer.summary", {
		reply: s(`answer.short.${c.reply_mode || "progress"}`),
		conversation: s(`answer.short.${c.conversation || "sender"}`, { count: c.window_minutes })
	});
}
function sizesSet(form) {
	const has = (v) => v !== void 0 && v !== null && v !== "";
	return has(form.file_receive_mib) || has(form.file_send_mib) || (form.reply_language || "auto") !== "auto";
}
/**
* @param {object} props
* @param {object} props.form
* @param {Function} props.setForm
* @param {Function} props.t
* @param {object} [props.kindInfo]
* @param {object} [props.places]  the places the bot may post, above the reply fields
* @param {object} [props.notify]  where reminders and run results go
* @param {object} [props.sizes]   the file size limits, in the group of the least used
*/
function AnswerFields({ form, setForm, t, kindInfo, places, notify, sizes }) {
	const s = answerT(t);
	const [moreOpen, setMoreOpen] = useState$1(() => sizesSet(form));
	const m = Number(form.window_minutes);
	const windowBad = form.conversation === "window" && (!Number.isInteger(m) || m < 1 || m > 10080);
	return /* @__PURE__ */ jsxs("fieldset", {
		className: "cn-group",
		"data-testid": "connector-answer",
		children: [
			/* @__PURE__ */ jsx("legend", { children: s("answer.title") }),
			places,
			notify,
			/* @__PURE__ */ jsx(Field, {
				label: s("answer.replyLabel"),
				hint: form.reply_mode === "reasoning" ? `${s("answer.replyHelp")} ${s("answer.replyReasoningHelp")}` : s("answer.replyHelp"),
				children: (p) => /* @__PURE__ */ jsx(Select, {
					...p,
					"data-testid": "connector-reply",
					value: form.reply_mode || "progress",
					onChange: (e) => setForm({
						...form,
						reply_mode: e.target.value
					}),
					children: REPLY_MODES.map((x) => /* @__PURE__ */ jsx("option", {
						value: x,
						children: s(`answer.reply.${x}`)
					}, x))
				})
			}),
			/* @__PURE__ */ jsx(Field, {
				label: s("answer.conversationLabel"),
				hint: s("answer.conversationHelp"),
				children: (p) => /* @__PURE__ */ jsx(Select, {
					...p,
					"data-testid": "connector-conversation",
					value: form.conversation || "sender",
					onChange: (e) => setForm({
						...form,
						conversation: e.target.value
					}),
					children: CONVERSATIONS.map((x) => /* @__PURE__ */ jsx("option", {
						value: x,
						children: s(`answer.conversation.${x}`)
					}, x))
				})
			}),
			form.conversation === "window" && /* @__PURE__ */ jsx(Field, {
				label: s("answer.window"),
				className: "cn-answer__window",
				error: windowBad ? s("answer.windowRange", { max: 10080 }) : void 0,
				children: (p) => /* @__PURE__ */ jsx(TextInput, {
					...p,
					type: "number",
					inputMode: "numeric",
					min: 1,
					max: 10080,
					required: true,
					"data-testid": "connector-window",
					value: form.window_minutes ?? "",
					onChange: (e) => setForm({
						...form,
						window_minutes: e.target.value === "" ? "" : Number(e.target.value)
					})
				})
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "cn-switchfield",
				children: [/* @__PURE__ */ jsx(Switch, {
					testId: "connector-files",
					checked: form.send_files !== false,
					onChange: (on) => setForm({
						...form,
						send_files: on
					}),
					children: s("answer.files")
				}), /* @__PURE__ */ jsx(Hint, { children: s("answer.filesHelp") })]
			}),
			(kindInfo?.options || []).map((o) => /* @__PURE__ */ jsx(Field, {
				label: o.title,
				hint: o.description,
				children: (p) => /* @__PURE__ */ jsx(Select, {
					...p,
					"data-testid": `connector-option-${o.id}`,
					value: form.options?.[o.id] || o.default,
					onChange: (e) => setForm({
						...form,
						options: {
							...form.options,
							[o.id]: e.target.value
						}
					}),
					children: o.values.map((v) => /* @__PURE__ */ jsx("option", {
						value: v.id,
						children: v.title
					}, v.id))
				})
			}, o.id)),
			/* @__PURE__ */ jsxs("details", {
				className: "cn-more",
				"data-testid": "connector-answer-more",
				open: moreOpen,
				onToggle: (e) => setMoreOpen(e.currentTarget.open),
				children: [/* @__PURE__ */ jsx("summary", { children: s("answer.more") }), /* @__PURE__ */ jsxs("div", {
					className: "cn-more__body",
					children: [/* @__PURE__ */ jsx(Field, {
						label: s("answer.languageLabel"),
						hint: s("answer.languageHelp"),
						children: (p) => /* @__PURE__ */ jsx(Select, {
							...p,
							"data-testid": "connector-reply-language",
							value: form.reply_language || "auto",
							onChange: (e) => setForm({
								...form,
								reply_language: e.target.value
							}),
							children: REPLY_LANGUAGES.map((x) => /* @__PURE__ */ jsx("option", {
								value: x,
								children: s(`answer.language.${x}`)
							}, x))
						})
					}), sizes]
				})]
			})
		]
	});
}
var init_AnswerFields = __esmMin((() => {
	init_react();
	init_controls();
	init_connector();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/api.js
function setApiLanguage(tag) {
	uiLanguage = typeof tag === "string" ? tag : "";
	language = uiLanguage && !/^en(-|$)/i.test(uiLanguage) ? uiLanguage : "";
}
async function call(path, init = {}) {
	const response = await getSdk().core.fetch(path, {
		headers: { "Content-Type": "application/json" },
		...init
	});
	if (!response.ok) {
		let message = `HTTP ${response.status}`;
		let body = null;
		try {
			body = await response.json();
			message = body?.error?.message || message;
		} catch (_e) {}
		const err = new Error(message);
		err.status = response.status;
		err.body = body;
		throw err;
	}
	if (response.status === 204) return null;
	return response.json();
}
var enc$1, language, uiLanguage, withUILanguage, localized, send, agentsApi, triggersApi, connectorsApi;
var init_api = __esmMin((() => {
	init_runtime();
	init_connector();
	enc$1 = encodeURIComponent;
	language = "";
	uiLanguage = "";
	withUILanguage = (body) => uiLanguage && body && typeof body === "object" ? {
		...body,
		ui_language: uiLanguage
	} : body;
	localized = (path) => language ? `${path}${path.includes("?") ? "&" : "?"}lang=${enc$1(language)}` : path;
	send = (method, path, body, signal) => call(path, {
		method,
		body: body === void 0 ? void 0 : JSON.stringify(body),
		signal
	});
	agentsApi = { list: () => call("/api/chats/agents") };
	triggersApi = { list: () => call("/api/chats/triggers") };
	connectorsApi = {
		list: () => call("/api/chats/connectors"),
		kinds: () => call(localized("/api/chats/connectors/kinds")).then((r) => r ? {
			...r,
			capabilities: localizeCapabilities(r.capabilities)
		} : r),
		create: (body) => send("POST", "/api/chats/connectors", withUILanguage(body)),
		update: (id, body) => send("PUT", `/api/chats/connectors/${enc$1(id)}`, withUILanguage(body)),
		remove: (id) => send("DELETE", `/api/chats/connectors/${enc$1(id)}`),
		enable: (id) => send("POST", `/api/chats/connectors/${enc$1(id)}/enable`, {}),
		disable: (id) => send("POST", `/api/chats/connectors/${enc$1(id)}/disable`, {}),
		test: (id) => send("POST", `/api/chats/connectors/${enc$1(id)}/test`, {}),
		senders: (id) => call(`/api/chats/connectors/${enc$1(id)}/senders`),
		allow: (id, sender) => send("POST", `/api/chats/connectors/${enc$1(id)}/senders/${enc$1(sender)}/allow`, {}),
		pair: (id) => send("POST", `/api/chats/connectors/${enc$1(id)}/pairing`, {}),
		access: (id) => call(localized(`/api/chats/connectors/${enc$1(id)}/access`)).then(localizeAccess),
		preview: (id, body, signal) => send("POST", localized(`/api/chats/connectors/${enc$1(id)}/access/preview`), body, signal).then(localizeAccess),
		unpair: (id, sender) => send("DELETE", `/api/chats/connectors/${enc$1(id)}/paired/${enc$1(sender)}`)
	};
}));

//#endregion
//#region addons/internal/connector-ui/src/access.js
function previewBody(form, kind) {
	const body = {
		agent_id: form.agent_id || "",
		accept_any: Boolean(form.accept_any),
		allow: form.accept_any ? [] : (form.allow || []).map((x) => x.trim()).filter((x, i, a) => x && a.indexOf(x) === i),
		allow_trust: form.accept_any ? {} : Object.fromEntries((form.allow || []).map((x) => x.trim()).filter((x) => form.allow_trust?.[x]).map((x) => [x, form.allow_trust[x]])),
		caps: [...form.caps || []],
		grants: (form.grants || []).map((g) => ({
			role: g.role,
			caps: [...g.caps]
		})),
		channels: (form.channels || []).map((c) => ({
			id: (c.id || "").trim(),
			label: (c.label || "").trim(),
			approved: Boolean(c.approved)
		}))
	};
	if (form.approval?.mode) body.approval_mode = form.approval.mode;
	if (!form.id) body.kind = kind;
	return body;
}
function changedFields(form, saved) {
	if (!saved) return new Set(WATCHED);
	const norm = (f, k) => JSON.stringify(k === "approval" ? approvalPayload(f.approval) : k === "send_files" ? f.send_files !== false : f[k] ?? "");
	const sorted = (f, k) => k === "allow_trust" ? JSON.stringify(Object.entries(f[k] || {}).sort()) : k === "allow" || k === "caps" ? JSON.stringify([...f[k] || []].sort()) : norm(f, k);
	return new Set(WATCHED.filter((k) => sorted(form, k) !== sorted(saved, k)));
}
function changedParts(form, saved) {
	if (!saved) return [];
	const fields = changedFields(form, saved);
	if ((form.name || "").trim() !== (saved.name || "")) fields.add("name");
	const parts = new Set([...fields].map((f) => CHANGE_PART[f]).filter(Boolean));
	return Object.values(CHANGE_PART).filter((p, i, all) => all.indexOf(p) === i && parts.has(p));
}
function removedActs(saved, form) {
	const now = form?.approval?.acts || [];
	return (saved?.approval?.acts || []).filter((n) => !now.includes(n));
}
function droppedActs(triggers, bindingId, removed) {
	if (!bindingId || !removed?.length) return [];
	return (Array.isArray(triggers) ? triggers : []).filter((t) => t && t.binding === bindingId).map((t) => ({
		id: t.id,
		name: t.name || t.id,
		acts: (t.acts || []).filter((n) => removed.includes(n))
	})).filter((t) => t.acts.length > 0);
}
function connectionTargets(fix, lists = [], form = {}) {
	const field = fix.field || "";
	switch (fix.target) {
		case "caps": return field ? [sel(`connector-cap-switch-${field}`), sel(`connector-cap-${field}`)] : [sel("connector-matrix")];
		case "grants": return [sel("connector-matrix")];
		case "agent_id": return [sel("connector-agent")];
		case "allow": return allowTargets(lists, form);
		case "trust": return [
			sel("connector-trust-level"),
			sel("connector-who-channels"),
			sel("connector-who")
		];
		case "token": return ["[data-testid=\"connector-form\"] input[type=\"password\"]", sel("connector-form")];
		case "save": return [sel("connector-save")];
		case "usual": return [sel("connector-usual"), sel("connector-matrix")];
		case "notify": return [sel("connector-notify")];
		case "files": return [sel("connector-files")];
		case "approval": return [sel("connector-cap-switch-triggers.propose"), sel("connector-matrix")];
		default: return [];
	}
}
function allowTargets(lists, form) {
	if (form.accept_any) return [sel("connector-who")];
	const first = lists[0]?.testId;
	return first ? [
		`${sel(first)} input`,
		sel(first),
		sel("connector-who")
	] : [sel("connector-who")];
}
function fixAction(fix, ctx = {}) {
	if (!fix || !fix.kind) return null;
	switch (fix.kind) {
		case "open_connection": {
			const selectors = connectionTargets(fix, ctx.lists, ctx.form);
			return selectors.length ? {
				type: "jump",
				selectors
			} : null;
		}
		case "open_agent": {
			const id = fix.target || ctx.agentId;
			return id ? {
				type: "link",
				to: agentEditor(id)
			} : null;
		}
		case "open_server_setting": return ctx.isAdmin === true ? {
			type: "link",
			to: "/app/settings"
		} : {
			type: "text",
			key: "askAdmin"
		};
		case "pair_sender": return {
			type: "jump",
			selectors: pairingTargets()
		};
		case "add_person": return {
			type: "jump",
			selectors: allowTargets(ctx.lists || [], ctx.form || {})
		};
		case "test_token": return { type: "test" };
		case "save": return {
			type: "save",
			selectors: connectionTargets({ target: "save" })
		};
		default: return null;
	}
}
function fixLabelKey(fix) {
	if (!fix) return "";
	if (fix.label) return fix.label;
	return `fix.${fix.kind}`;
}
function sentenceCase(text) {
	const t = String(text || "").replace(/\blocalai\b/gi, "LocalAI");
	return t.charAt(0).toUpperCase() + t.slice(1);
}
function hasPairing(paired, now = Date.now()) {
	return (paired || []).some((p) => !p.expires_at || new Date(p.expires_at).getTime() > now);
}
function reachable(form, lists, view) {
	const roles = (view?.subjects || []).filter((s) => s.id.startsWith("role:")).map((s) => s.id);
	if (form.accept_any) return [
		"anyone",
		"paired",
		...roles
	];
	const multi = Array.isArray(lists) && lists.length > 1;
	const allow = form.allow || [];
	const people = multi ? listEntries(allow, lists, 0).length > 0 : allow.length > 0;
	const channels = multi && allow.length > listEntries(allow, lists, 0).length;
	const out = [];
	if (people) out.push("listed", "paired");
	if (channels) out.push("anyone");
	if ((form.allow || []).some((x) => trustOf(form, x) === "act")) out.push("channel_acts");
	if (people || channels) out.push(...roles);
	return out;
}
function unusable(cap, view, form, lists, paired, now) {
	const subjects = reachable(form, lists, view);
	if (subjects.length === 0) return {
		capability: cap,
		allowed: false,
		code: "nobody_let_in",
		blocked_by: "sender",
		fix: {
			kind: "add_person",
			target: "allow"
		}
	};
	const decisions = subjects.map((id) => decisionOf(view, id, cap)).filter(Boolean);
	if (decisions.length === 0) return null;
	const usable = decisions.filter((d) => d.allowed);
	if (usable.length > 0) {
		if (usable.every((d) => d.via === "paired" || d.via === "agent-connection") && !hasPairing(paired, now)) return {
			capability: cap,
			allowed: false,
			code: "nobody_paired",
			blocked_by: "sender",
			fix: {
				kind: "pair_sender",
				target: "pairing"
			}
		};
		return null;
	}
	return decisions.find((d) => d.blocked_by !== "sender") || decisions[0];
}
function readinessRows(ctx) {
	const { form, saved, kindInfo, agents = [], lists = [], tokenTyped, token, preview = {}, paired, agentOptional = false, toolOnly = false, now = Date.now(), capabilities = [], isChannel = () => false } = ctx;
	const changed = changedFields(form, saved);
	const caps = form.caps || [];
	const on = (n) => caps.includes(n);
	const view = preview.status === "ready" ? preview.view : null;
	const pending = preview.status === "loading" || preview.status === void 0 ? "checking" : preview.status === "error" ? "unknown" : "";
	const titleOf = (n) => sentenceCase(capabilities.find((c) => c.name === n)?.title || n);
	const afterSave = (row, ...fields) => row.state === "ok" && fields.some((f) => changed.has(f)) ? {
		...row,
		state: "after_save",
		fix: {
			kind: "save",
			label: "fix.save"
		}
	} : row;
	const rows = [];
	if (!form.id) rows.push(tokenTyped ? {
		id: "token",
		state: "after_save",
		key: "ready.token.newTyped",
		fix: {
			kind: "save",
			label: "fix.save"
		}
	} : {
		id: "token",
		state: "attention",
		key: "ready.token.missing",
		fix: jump("token", "", "fix.token")
	});
	else if (tokenTyped) rows.push({
		id: "token",
		state: "after_save",
		key: "ready.token.typed",
		fix: {
			kind: "save",
			label: "fix.save"
		}
	});
	else if (token && token.ok === false) rows.push({
		id: "token",
		state: "broken",
		key: "ready.token.failed",
		params: { reason: token.reason || "" },
		fix: jump("token", "", "fix.tokenNew")
	});
	else if (token && token.ok) rows.push({
		id: "token",
		state: "ok",
		key: "ready.token.checked",
		params: { bot: token.bot || "" }
	});
	else rows.push({
		id: "token",
		state: "ok",
		key: "ready.token.saved"
	});
	const agent = agents.find((a) => a.id === form.agent_id);
	if (toolOnly) {} else if (!form.agent_id) rows.push(agentOptional ? {
		id: "agent",
		state: "off",
		key: "ready.agent.credentialsOnly"
	} : {
		id: "agent",
		state: "attention",
		key: "ready.agent.none",
		fix: jump("agent_id", "", "fix.agent")
	});
	else if (agents.length > 0 && !agent) rows.push({
		id: "agent",
		state: "attention",
		key: "ready.agent.gone",
		fix: jump("agent_id", "", "fix.agent")
	});
	else if (agent && !agent.model) rows.push({
		id: "agent",
		state: "broken",
		key: "ready.agent.noModel",
		params: { name: agent.name },
		fix: {
			kind: "open_agent",
			target: agent.id
		}
	});
	else rows.push(afterSave({
		id: "agent",
		state: "ok",
		key: agent ? "ready.agent.ok" : "ready.agent.okUnknown",
		params: {
			name: agent?.name || "",
			model: agent?.model || ""
		}
	}, "agent_id"));
	const multi = lists.length > 1;
	const entries = form.allow || [];
	const people = multi ? listEntries(entries, lists, 0).length : entries.length;
	if (form.accept_any) rows.push(afterSave({
		id: "who",
		state: "ok",
		key: "ready.who.anyone"
	}, "accept_any", "allow"));
	else if (entries.length === 0) rows.push({
		id: "who",
		state: "attention",
		key: "ready.who.nobody",
		fix: {
			kind: "add_person",
			target: "allow"
		}
	});
	else if (channelOnly(form, lists)) rows.push({
		id: "who",
		state: "attention",
		key: "ready.who.channelsOnly",
		fix: {
			kind: "add_person",
			target: "allow"
		}
	});
	else rows.push(afterSave({
		id: "who",
		state: "ok",
		key: multi && entries.length > people ? "ready.who.mixed" : "ready.who.listed",
		params: { count: entries.length }
	}, "accept_any", "allow"));
	const listening = form.accept_any ? [] : channelEntries(form, isChannel);
	const acting = listening.filter((x) => trustOf(form, x) === "act");
	const answering = listening.filter((x) => trustOf(form, x) !== "act");
	if (answering.length > 0) rows.push({
		id: "channelTrust",
		state: "attention",
		key: "ready.channelTrust.answer",
		params: { channels: answering.join(", ") },
		fix: jump("trust", "", "fix.trust")
	});
	else if (acting.length > 0 && caps.length === 0) rows.push({
		id: "channelTrust",
		state: "attention",
		key: "ready.channelTrust.noCaps",
		fix: jump("usual", "", "fix.usual")
	});
	else if (acting.length > 0) rows.push(afterSave({
		id: "channelTrust",
		state: "ok",
		key: "ready.channelTrust.act",
		params: { channels: acting.join(", ") }
	}, "allow", "allow_trust", "caps"));
	if (on("talkback.channels") && (form.channels || []).length > 0) rows.push({
		id: "postTo",
		state: "ok",
		key: "ready.postTo",
		params: { count: form.channels.length }
	});
	const others = caps.filter((n) => n !== "triggers.propose" && n !== "files.upload");
	if (caps.length === 0) rows.push({
		id: "permissions",
		state: saved ? "attention" : "off",
		key: saved ? "ready.perm.noneSaved" : "ready.perm.none",
		fix: jump("usual", "", "fix.usual")
	});
	else if (others.length === 0) rows.push(afterSave({
		id: "permissions",
		state: "ok",
		key: "ready.perm.onlyOwnRows"
	}, "caps"));
	else if (pending) rows.push({
		id: "permissions",
		state: pending,
		key: pending === "checking" ? "ready.checking" : "ready.unchecked"
	});
	else {
		const dead = others.map((n) => unusable(n, view, form, lists, paired, now)).filter(Boolean);
		if (dead.length > 0) {
			const first = dead[0];
			rows.push({
				id: "permissions",
				state: "attention",
				key: "ready.perm.dead",
				params: {
					count: dead.length,
					names: dead.map((d) => titleOf(d.capability)).join(", "),
					message: messageOf(first),
					messageKey: messageKey(first)
				},
				fix: first.fix
			});
		} else rows.push(afterSave({
			id: "permissions",
			state: "ok",
			key: "ready.perm.ok",
			params: { count: others.length }
		}, "caps", "grants", "allow", "accept_any"));
	}
	for (const hold of view?.addon_tools || []) {
		const names = (hold.tools || []).join(", ");
		const params = {
			addon: hold.addon,
			tools: names,
			permission: titleOf(hold.capability)
		};
		const id = `addons:${hold.addon}`;
		if (!on(hold.capability)) {
			const conns = hold.connections || [];
			const live = conns.find((c) => c.write_mode && c.write_mode !== "off");
			if ((hold.without_tick || []).includes("paired") && live) {
				const p = {
					...params,
					connection: live.name,
					modeKey: `ready.addons.mode.${live.write_mode}`
				};
				if (!hasPairing(paired, now)) {
					const d = {
						capability: hold.capability,
						code: "nobody_paired",
						fix: {
							kind: "pair_sender",
							target: "pairing"
						}
					};
					rows.push({
						id,
						labelKey: "ready.row.addons",
						state: "attention",
						key: "ready.addons.blocked",
						params: {
							...params,
							message: messageOf(d),
							messageKey: messageKey(d)
						},
						fix: d.fix
					});
				} else {
					rows.push(afterSave({
						id,
						labelKey: "ready.row.addons",
						state: "ok",
						key: "ready.addons.paired",
						params: p
					}, "caps", "agent_id"));
					if (conns.some((c) => c.write_mode === "propose") && on("proposals.confirm")) rows.push(afterSave({
						id: `${id}:confirm`,
						labelKey: "ready.row.addons",
						state: "ok",
						key: "ready.addons.confirmChat",
						params: { addon: hold.addon }
					}, "caps", "agent_id"));
				}
			} else if (hold.tick_removed) rows.push({
				id,
				labelKey: "ready.row.addons",
				state: "attention",
				key: "ready.addons.removed",
				params,
				fix: jump("caps", hold.capability, "fix.turnOn")
			});
			else if (conns.length > 0 && !live) rows.push({
				id,
				labelKey: "ready.row.addons",
				state: "attention",
				key: "ready.addons.modeOff",
				params: {
					...params,
					connection: conns.map((c) => c.name).join(", ")
				}
			});
			else rows.push({
				id,
				labelKey: "ready.row.addons",
				state: "attention",
				key: "ready.addons.off",
				params,
				fix: jump("caps", hold.capability, "fix.turnOn")
			});
			continue;
		}
		const d = unusable(hold.capability, view, form, lists, paired, now);
		if (d) rows.push({
			id,
			labelKey: "ready.row.addons",
			state: "attention",
			key: "ready.addons.blocked",
			params: {
				...params,
				message: messageOf(d),
				messageKey: messageKey(d)
			},
			fix: d.fix
		});
		else {
			rows.push(afterSave({
				id,
				labelKey: "ready.row.addons",
				state: "ok",
				key: "ready.addons.ok",
				params
			}, "caps", "grants", "allow", "accept_any", "agent_id"));
			if ((hold.connections || []).some((c) => c.write_mode === "propose") && on("proposals.confirm") && hasPairing(paired, now)) rows.push(afterSave({
				id: `${id}:confirm`,
				labelKey: "ready.row.addons",
				state: "ok",
				key: "ready.addons.confirmChat",
				params: { addon: hold.addon }
			}, "caps", "agent_id"));
		}
	}
	if (!on("triggers.propose")) rows.push({
		id: "triggers",
		state: "off",
		key: "ready.triggers.off",
		fix: jump("caps", "triggers.propose", "fix.turnOn")
	});
	else if (pending) rows.push({
		id: "triggers",
		state: pending,
		key: pending === "checking" ? "ready.checking" : "ready.unchecked"
	});
	else {
		const d = unusable("triggers.propose", view, form, lists, paired, now);
		if (d) rows.push({
			id: "triggers",
			state: "attention",
			key: "ready.triggers.blocked",
			params: {
				message: messageOf(d),
				messageKey: messageKey(d)
			},
			fix: d.fix
		});
		else {
			const mode = form.approval?.mode || "ask";
			rows.push(afterSave({
				id: "triggers",
				state: "ok",
				key: `ready.triggers.ok.${mode}`
			}, "caps", "approval", "allow", "accept_any", "agent_id"));
		}
	}
	if (!(kindInfo?.files && !kindInfo.files.receive?.allowed_bytes && !kindInfo.files.send?.allowed_bytes)) if (!on("files.upload")) rows.push({
		id: "files",
		state: "off",
		key: form.send_files === false ? "ready.files.offBoth" : "ready.files.offReceive",
		fix: jump("caps", "files.upload", "fix.turnOn")
	});
	else if (pending) rows.push({
		id: "files",
		state: pending,
		key: pending === "checking" ? "ready.checking" : "ready.unchecked"
	});
	else {
		const d = unusable("files.upload", view, form, lists, paired, now);
		if (d) rows.push({
			id: "files",
			state: "attention",
			key: "ready.files.blocked",
			params: {
				message: messageOf(d),
				messageKey: messageKey(d)
			},
			fix: d.fix
		});
		else rows.push(afterSave({
			id: "files",
			state: "ok",
			key: form.send_files === false ? "ready.files.okReceive" : "ready.files.ok"
		}, "caps", "send_files", "allow", "accept_any", "agent_id"));
	}
	const notify = (form.notify_chat || "").trim();
	rows.push(notify ? afterSave({
		id: "notify",
		state: "ok",
		key: "ready.notify.ok",
		params: { chat: notify }
	}, "notify_chat") : {
		id: "notify",
		state: "off",
		key: "ready.notify.off",
		fix: jump("notify", "", "fix.turnOn")
	});
	return rows;
}
function messageOf(d) {
	if (d.message) return d.message;
	if (d.code === "nobody_let_in") return "Nobody is let in yet.";
	if (d.code === "nobody_paired") return "This needs a verified person, and nobody is verified yet.";
	return d.reason || "";
}
function messageKey(d) {
	if (d.message) return "";
	if (d.code === "nobody_let_in") return "ready.blocker.nobodyLetIn";
	if (d.code === "nobody_paired") return "ready.blocker.nobodyPaired";
	return "";
}
function visibleRows(rows, expanded) {
	if (expanded) return {
		shown: rows,
		hidden: 0
	};
	const shown = rows.filter((r) => isProblem(r.state));
	return {
		shown,
		hidden: rows.length - shown.length
	};
}
function toolOutcomeRows(view, limit = 20) {
	return (view?.tool_outcomes || []).slice(0, limit).map((e, i) => ({
		key: `${e.at}-${e.tool}-${i}`,
		tool: e.addon ? `${e.addon} / ${e.tool}` : e.tool,
		outcome: Object.hasOwn(OUTCOME_TONES, e.outcome) ? e.outcome : "error",
		tone: OUTCOME_TONES[e.outcome] || "failed",
		at: e.at,
		code: e.code || "",
		message: e.message || "",
		status: e.status || 0,
		senders: e.senders || [],
		asker: e.asker || "",
		senderName: e.sender_name || ""
	}));
}
var enc, previewId, previewKey, WATCHED, CHANGE_PART, agentEditor, sel, pairingTargets, remainingChecks, THEN_CHECK, decisionOf, isProblem, jump, STATUS_ROW_IDS, statusRows, forNewConnection, isThingToSet, thingsToSet, OUTCOME_TONES;
var init_access = __esmMin((() => {
	init_connector();
	enc = encodeURIComponent;
	previewId = (form) => form.id || "new";
	previewKey = (form, kind) => JSON.stringify([previewId(form), previewBody(form, kind)]);
	WATCHED = [
		"agent_id",
		"accept_any",
		"allow",
		"allow_trust",
		"caps",
		"grants",
		"approval",
		"send_files",
		"file_receive_mib",
		"file_send_mib",
		"notify_chat"
	];
	CHANGE_PART = {
		name: "name",
		agent_id: "agent",
		accept_any: "who",
		allow: "who",
		allow_trust: "who",
		caps: "permissions",
		grants: "permissions",
		approval: "approval",
		send_files: "files",
		file_receive_mib: "files",
		file_send_mib: "files",
		notify_chat: "notify"
	};
	agentEditor = (id) => `/app/agents/${enc(id)}/edit`;
	sel = (testid) => `[data-testid="${testid}"]`;
	pairingTargets = () => [sel("connector-pair-start"), sel("connector-pairing")];
	remainingChecks = (thenCheck) => (thenCheck || []).filter((x) => x !== "sender" && THEN_CHECK.includes(x));
	THEN_CHECK = [
		"server",
		"tools",
		"agent",
		"connection",
		"sender",
		"approval"
	];
	decisionOf = (view, subject, cap) => (view?.subjects || []).find((s) => s.id === subject)?.decisions.find((d) => d.capability === cap) || null;
	isProblem = (state) => state === "attention" || state === "broken" || state === "after_save" || state === "unknown";
	jump = (target, field, label) => ({
		kind: "open_connection",
		target,
		field,
		label
	});
	STATUS_ROW_IDS = [
		"token",
		"agent",
		"who"
	];
	statusRows = (rows) => rows.filter((r) => STATUS_ROW_IDS.includes(r.id));
	forNewConnection = (rows) => rows.map((r) => r.fix?.kind === "save" ? {
		...r,
		fix: void 0
	} : r);
	isThingToSet = (state) => isProblem(state) && state !== "after_save";
	thingsToSet = (rows) => rows.filter((r) => isThingToSet(r.state)).length;
	OUTCOME_TONES = {
		ok: "done",
		held: "skipped",
		denied: "failed",
		error: "failed",
		confirmed: "done",
		cancelled: "skipped",
		expired: "skipped"
	};
}));

//#endregion
//#region addons/internal/connector-ui/src/accessHooks.jsx
function jumpTo(selectors) {
	for (const sel of selectors) {
		const el = document.querySelector(sel);
		if (!el) continue;
		el.scrollIntoView?.({ block: "center" });
		((el.matches?.("button:not([disabled]), input, select, textarea, a[href]") ? el : el.querySelector?.("button:not([disabled]), input, select, textarea")) || el).focus?.({ preventScroll: true });
		const mark = el.closest?.("li, fieldset, .dk-field, .cn-sub") || el;
		mark.setAttribute("data-jumped", "true");
		setTimeout(() => mark.removeAttribute("data-jumped"), FLASH_MS);
		return true;
	}
	return false;
}
function useIsAdmin(useAuth) {
	try {
		return Boolean(useAuth().isAdmin);
	} catch (_e) {
		return null;
	}
}
/**
* Asks the host what the form will do, 400 ms after the last change, and drops
* the answer of a request that is already stale.
* @returns {{ status: 'idle'|'loading'|'ready'|'error', view: object|null, error: string, reload: Function, settled: boolean }}
*/
function useAccessPreview({ form, kind, enabled, version = 0 }) {
	const [state, setState] = useState$1({
		status: "idle",
		view: null,
		error: "",
		key: ""
	});
	const [again, setAgain] = useState$1(0);
	const key = enabled && form ? previewKey(form, kind) : "";
	const latest = useRef(form);
	latest.current = form;
	useEffect$1(() => {
		if (!key) {
			setState({
				status: "idle",
				view: null,
				error: "",
				key: ""
			});
			return;
		}
		setState((s) => ({
			...s,
			status: "loading",
			error: ""
		}));
		const ctl = new AbortController();
		const timer = setTimeout(async () => {
			try {
				const f = latest.current;
				const view = await connectorsApi.preview(previewId(f), previewBody(f, kind), ctl.signal);
				if (!ctl.signal.aborted) setState({
					status: "ready",
					view,
					error: "",
					key
				});
			} catch (e) {
				if (ctl.signal.aborted || e?.name === "AbortError") return;
				setState((s) => ({
					...s,
					status: "error",
					error: e?.message || ""
				}));
			}
		}, 400);
		return () => {
			clearTimeout(timer);
			ctl.abort();
		};
	}, [
		key,
		kind,
		version,
		again
	]);
	const reload = useCallback(() => setAgain((n) => n + 1), []);
	return {
		status: state.status,
		view: state.view,
		error: state.error,
		reload
	};
}
function FixButton({ fix, ctx, s, onTest, onSave, variant = "secondary" }) {
	const action = fixAction(fix, ctx);
	if (!action) return null;
	const cls = `dk-btn dk-btn--${variant} dk-btn--sm cn-fix`;
	const label = s(fixLabelKey(fix));
	if (action.type === "text") return /* @__PURE__ */ jsx("span", {
		className: "cn-muted cn-fix__text",
		"data-testid": "connector-fix-text",
		children: s(`fix.${action.key}`)
	});
	if (action.type === "link") return /* @__PURE__ */ jsxs("a", {
		className: cls,
		href: basePath + action.to,
		target: "_blank",
		rel: "noopener noreferrer",
		"data-testid": "connector-fix",
		children: [label, /* @__PURE__ */ jsxs("span", {
			className: "cn-vh",
			children: [" ", s("fix.newTab")]
		})]
	});
	if (action.type === "save") {
		const save = () => {
			const b = document.querySelector(action.selectors[0]);
			if (b && !b.disabled) b.click();
			else jumpTo(action.selectors);
		};
		return /* @__PURE__ */ jsx("button", {
			type: "button",
			className: cls,
			"data-testid": "connector-fix",
			onClick: save,
			children: label
		});
	}
	if (action.type === "test") return /* @__PURE__ */ jsx("button", {
		type: "button",
		className: cls,
		"data-testid": "connector-fix",
		onClick: onTest,
		children: label
	});
	return /* @__PURE__ */ jsx("button", {
		type: "button",
		className: cls,
		"data-testid": "connector-fix",
		onClick: () => jumpTo(action.selectors),
		children: label
	});
}
var FLASH_MS;
var init_accessHooks = __esmMin((() => {
	init_react();
	init_basePath();
	init_api();
	init_access();
	init_jsx_runtime();
	FLASH_MS = 1600;
}));

//#endregion
//#region addons/internal/host-compat/src/context/AuthContext.jsx
function useAuth() {
	const { viewer } = getSdk();
	return {
		isAdmin: viewer.isAdmin(),
		hasFeature: (name) => viewer.hasFeature(name)
	};
}
var init_AuthContext = __esmMin((() => {
	init_runtime();
}));

//#endregion
//#region addons/internal/host-compat/src/components/ui/SidePane.jsx
var SidePane_default, PaneLayout;
var init_SidePane = __esmMin((() => {
	init_ui();
	SidePane_default = fromSdk("SidePane");
	PaneLayout = fromSdk("PaneLayout");
}));

//#endregion
//#region addons/internal/host-compat/src/components/ActionMenu.jsx
var ActionMenu_default;
var init_ActionMenu = __esmMin((() => {
	init_ui();
	ActionMenu_default = fromSdk("ActionMenu");
}));

//#endregion
//#region addons/internal/host-compat/src/components/ui/StatusChip.jsx
var StatusChip_default;
var init_StatusChip = __esmMin((() => {
	init_ui();
	StatusChip_default = fromSdk("StatusChip");
}));

//#endregion
//#region addons/internal/connector-ui/src/ConnectionRow.jsx
function Tile({ c }) {
	const name = (c.name || c.id || "?").trim();
	return /* @__PURE__ */ jsx("span", {
		className: "cn-tile",
		"data-hue": hueOf(c.id || name),
		"aria-hidden": "true",
		children: [...name][0]?.toUpperCase()
	});
}
function StateChip({ state, label, title }) {
	return /* @__PURE__ */ jsx(StatusChip_default, {
		tone: CHIP_TONE[state] || "idle",
		title,
		testId: "connector-state",
		children: label
	});
}
function ConnectionRow({ c, state, attention, fix, facts, line, selected, testing, busy, messaging, t, s, onOpen, onToggle, onTest, onFix, onEdit, onDelete, onShare }) {
	const stateText = s(`conn.state.${state}`);
	const items = [
		{
			key: "edit",
			icon: "pencil",
			label: t("editButton"),
			onClick: (trigger) => onEdit(c, trigger)
		},
		{
			key: "share",
			icon: "share",
			label: s("share.label"),
			onClick: () => onShare(c),
			hidden: !onShare
		},
		{
			divider: true,
			key: "divider"
		},
		{
			key: "delete",
			icon: "trash",
			label: t("delete"),
			danger: true,
			onClick: () => onDelete(c)
		}
	];
	return /* @__PURE__ */ jsxs("li", {
		className: "cn-conn",
		"data-testid": "connector-row",
		"data-id": c.id,
		"data-state": state,
		"data-on": c.enabled ? "true" : "false",
		"data-attention": state === "attention" ? "true" : void 0,
		"data-selected": selected ? "true" : void 0,
		children: [/* @__PURE__ */ jsxs("button", {
			type: "button",
			className: "cn-conn__open",
			"aria-pressed": selected,
			"data-testid": "connector-open",
			"aria-label": s("conn.row.open", {
				name: c.name,
				state: stateText
			}),
			onClick: () => onOpen(c.id),
			children: [/* @__PURE__ */ jsx(Tile, { c }), /* @__PURE__ */ jsxs("span", {
				className: "cn-conn__text",
				children: [
					/* @__PURE__ */ jsxs("span", {
						className: "cn-conn__head",
						children: [/* @__PURE__ */ jsx("span", {
							className: "cn-conn__name",
							children: c.name
						}), /* @__PURE__ */ jsx(StateChip, {
							state,
							label: stateText,
							title: attention?.reason || void 0
						})]
					}),
					/* @__PURE__ */ jsx("span", {
						className: "cn-conn__facts",
						"data-testid": "connector-facts",
						title: facts,
						children: facts
					}),
					line && /* @__PURE__ */ jsx("span", {
						className: "cn-conn__line",
						"data-testid": line.testId,
						title: line.text,
						children: line.text
					})
				]
			})]
		}), /* @__PURE__ */ jsxs("span", {
			className: "cn-conn__side",
			children: [
				fix ? /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--secondary dk-btn--sm",
					"data-testid": `connector-fix-${fix.kind}`,
					onClick: () => onFix(c, fix.kind),
					children: fix.label
				}) : /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--secondary dk-btn--sm",
					"aria-busy": testing ? "true" : void 0,
					disabled: testing,
					"aria-label": s("conn.row.testNamed", { name: c.name }),
					"data-testid": "connector-test",
					onClick: () => onTest(c),
					children: t("test")
				}),
				messaging && !c.credentials_only && /* @__PURE__ */ jsx(Switch, {
					checked: Boolean(c.enabled),
					disabled: busy,
					label: t("onFor", { name: c.name }),
					testId: "connector-switch",
					onChange: (on) => onToggle(c, on)
				}),
				/* @__PURE__ */ jsx(ActionMenu_default, {
					items,
					ariaLabel: s("conn.row.menu", { name: c.name }),
					compact: true
				})
			]
		})]
	});
}
var CHIP_TONE, hueOf;
var init_ConnectionRow = __esmMin((() => {
	init_ActionMenu();
	init_StatusChip();
	init_controls();
	init_jsx_runtime();
	CHIP_TONE = {
		running: "ok",
		ready: "ok",
		off: "idle",
		attention: "warn"
	};
	hueOf = (text) => [...String(text)].reduce((n, ch) => (n * 31 + ch.codePointAt(0)) % 12, 7);
}));

//#endregion
//#region addons/internal/connector-ui/src/matrix.js
function matrixColumns(form, view, roles = []) {
	const has = (id) => (view?.subjects || []).some((s) => s.id === id);
	const kinds = MATRIX_COLUMNS.filter((c) => {
		if (c.onlyWhenAny) return Boolean(form?.accept_any) && has(c.subject);
		return !c.subject || has(c.subject);
	});
	const byRole = (roles || []).filter((r) => has(`role:${r.id}`)).map((r) => ({
		id: `role:${r.id}`,
		subject: `role:${r.id}`,
		role: r.id,
		title: r.title
	}));
	return [...kinds, ...byRole];
}
function asksFirst(cap, subject, view) {
	if (cap === "memory.write") return subject?.note_save === "ask";
	if (cap === "triggers.propose" || cap === "triggers.change") return Boolean(view?.proposal_mode) && view.proposal_mode !== "auto";
	return false;
}
function cellOf(decision, subject, view, cap) {
	if (!decision) return {
		state: "unknown",
		decision: null
	};
	if (!decision.allowed) return {
		state: OFF_LINKS.has(decision.blocked_by) ? "off" : "no",
		decision
	};
	return {
		state: asksFirst(cap, subject, view) ? "asks" : "yes",
		decision
	};
}
function toolState(base, tool, hold, view, col) {
	if (base.state !== "yes") return base;
	const approval = (view?.approvals || []).find((a) => a.tool === tool);
	if (approval && (approval.runs_without_asking || []).includes("paired") && col === "paired") return {
		...base,
		state: "yes"
	};
	if ((hold.connections || []).some((c) => c.write_mode === "propose")) return {
		...base,
		state: "waiting"
	};
	if (approval?.skip && col !== "paired") return {
		...base,
		state: "asks"
	};
	return base;
}
function matrixRows(view, capabilities, form, columns) {
	const subjectOf = (col) => (view?.subjects || []).find((s) => s.id === col.subject);
	const rows = [];
	for (const c of capabilities || []) {
		const cells = {};
		for (const col of columns) {
			if (col.id === "on") {
				cells.on = {
					state: (form?.caps || []).includes(c.name) ? "yes" : "off",
					decision: null
				};
				continue;
			}
			const subject = subjectOf(col);
			cells[col.id] = cellOf((subject?.decisions || []).find((d) => d.capability === c.name), subject, view, c.name);
		}
		rows.push({
			key: c.name,
			cap: c.name,
			title: c.title,
			cells
		});
		for (const hold of (view?.addon_tools || []).filter((h) => h.capability === c.name)) for (const tool of hold.tools || []) {
			const sub = {};
			for (const col of columns) sub[col.id] = toolState(cells[col.id], tool, hold, view, col.id);
			rows.push({
				key: `${c.name}:${hold.addon}:${tool}`,
				cap: c.name,
				parent: c.name,
				addon: hold.addon,
				tool,
				cells: sub
			});
		}
	}
	return rows;
}
var MATRIX_COLUMNS, OFF_LINKS;
var init_matrix = __esmMin((() => {
	MATRIX_COLUMNS = [
		{ id: "on" },
		{
			id: "paired",
			subject: "paired"
		},
		{
			id: "listed",
			subject: "listed"
		},
		{
			id: "channel_acts",
			subject: "channel_acts"
		},
		{
			id: "channel_member",
			subject: "anyone"
		},
		{
			id: "anyone",
			subject: "anyone",
			onlyWhenAny: true
		}
	];
	OFF_LINKS = new Set([
		"server",
		"tools",
		"agent",
		"connection"
	]);
}));

//#endregion
//#region addons/internal/connector-ui/src/people.js
function peopleFrom(senders) {
	const m = /* @__PURE__ */ new Map();
	for (const s of senders || []) {
		if (!s || !s.id) continue;
		m.set(s.id, {
			name: s.name && s.name !== s.id ? s.name : "",
			chat: s.chat || "",
			chatName: s.chat_name || ""
		});
	}
	return m;
}
function nameOf(people, id, own = "") {
	const n = own || people?.get(id)?.name || "";
	return n && n !== id ? n : "";
}
function personText(people, id, own = "") {
	const n = nameOf(people, id, own);
	return n ? `${n} · ${id}` : id;
}
function chatText(chat, chatName) {
	if (!chat) return chatName || "";
	return chatName && chatName !== chat ? `${chatName} (${chat})` : chat;
}
function chatNamesFrom(senders) {
	const m = /* @__PURE__ */ new Map();
	for (const s of senders || []) if (s?.chat && s.chat_name && s.chat_name !== s.chat) m.set(s.chat, s.chat_name);
	return m;
}
function recentPeople(senders, listed, max = 8) {
	const on = new Set(listed || []);
	return [...senders || []].filter((s) => s?.id && !on.has(s.id)).sort((a, b) => String(b.last || "").localeCompare(String(a.last || ""))).slice(0, max).map((s) => ({
		id: s.id,
		name: s.name && s.name !== s.id ? s.name : ""
	}));
}
function knownTargets({ form, senders, isChannel = () => false }) {
	const people = /* @__PURE__ */ new Map();
	const channels = /* @__PURE__ */ new Map();
	const dir = peopleFrom(senders);
	const chatNames = chatNamesFrom(senders);
	for (const x of form?.allow || []) if (isChannel(x)) channels.set(x, chatNames.get(x) || "");
	else people.set(x, dir.get(x)?.name || "");
	for (const s of senders || []) if (s?.id && !people.has(s.id) && !channels.has(s.id)) people.set(s.id, dir.get(s.id)?.name || "");
	for (const [id, name] of chatNames) if (!people.has(id) && !channels.has(id)) channels.set(id, name);
	for (const c of form?.channels || []) {
		const id = (c.id || "").trim();
		if (id && !channels.has(id) && !people.has(id)) channels.set(id, (c.label || "").trim() || chatNames.get(id) || "");
	}
	const list = (m) => [...m].map(([id, name]) => ({
		id,
		name: name && name !== id ? name : ""
	}));
	return {
		people: list(people),
		channels: list(channels)
	};
}
var init_people = __esmMin((() => {}));

//#endregion
//#region addons/internal/connector-ui/src/check.js
function tryChoices({ form, people, chatNames, paired = [], isChannel = () => false, mixed = false, roles = [], now = Date.now() }) {
	const allow = form?.accept_any ? [] : form?.allow || [];
	const verified = new Set((paired || []).filter((p) => hasPairing([p], now)).map((p) => p.sender_id));
	const channels = mixed ? allow : allow.filter((x) => isChannel(x));
	const persons = mixed ? allow : allow.filter((x) => !isChannel(x));
	for (const id of verified) if (!persons.includes(id)) persons.push(id);
	const who = [];
	for (const id of persons) who.push({
		value: `person:${id}`,
		kind: "person",
		id,
		name: nameOf(people, id),
		subject: verified.has(id) ? "paired" : "listed"
	});
	for (const id of channels) who.push({
		value: `channel:${id}`,
		kind: "channel",
		id,
		name: chatNames?.get(id) || "",
		subject: trustOf(form, id) === "act" ? "channel_acts" : "anyone"
	});
	if (form?.accept_any) who.push({
		value: "anyone",
		kind: "anyone",
		id: "",
		name: "",
		subject: "anyone"
	});
	for (const r of roles || []) who.push({
		value: `role:${r.id}`,
		kind: "role",
		id: r.id,
		name: r.title,
		subject: `role:${r.id}`
	});
	const places = [{
		value: DM,
		kind: "dm",
		id: "",
		name: ""
	}];
	for (const id of form?.accept_any ? [] : channels) places.push({
		value: `channel:${id}`,
		kind: "channel",
		id,
		name: chatNames?.get(id) || ""
	});
	return {
		who,
		places
	};
}
function tryAnswer({ view, who, capability, proposalMode }) {
	if (!view || !who || !capability) return null;
	const subject = (view.subjects || []).find((s) => s.id === who.subject);
	if (!subject) return {
		verdict: "unknown",
		subject: who.subject
	};
	const decision = (subject.decisions || []).find((d) => d.capability === capability);
	if (!decision) return {
		verdict: "unknown",
		subject: who.subject
	};
	const cell = cellOf(decision, subject, view, capability);
	return {
		verdict: !decision.allowed ? "refused" : cell.state === "asks" ? "asks" : "allowed",
		subject: who.subject,
		decision,
		message: decision.allowed ? "" : decision.message || decision.reason || "",
		then: decision.allowed ? [] : remainingChecks(decision.then_check),
		fix: decision.allowed ? null : decision.fix || null
	};
}
function refusalRows({ recent = [], senders = [], titleOf = (x) => x, limit = 20 }) {
	const rows = [];
	(recent || []).forEach((e, i) => {
		if (!e || e.allowed !== false || !e.capability) return;
		const sender = (e.senders || [])[0] || "";
		rows.push({
			key: `a${i}-${e.at}`,
			at: e.at,
			source: "access",
			sender,
			name: e.sender_name || "",
			chat: e.chat || "",
			chatName: e.chat_name || "",
			action: titleOf(e.capability),
			code: e.code || "",
			reason: e.reason || ""
		});
	});
	(senders || []).forEach((s, i) => {
		if (!s || s.allowed !== false || !s.id) return;
		rows.push({
			key: `s${i}-${s.id}`,
			at: s.last || s.first || "",
			source: "sender",
			sender: s.id,
			name: s.name && s.name !== s.id ? s.name : "",
			chat: s.chat || "",
			chatName: s.chat_name || "",
			action: "",
			code: s.reason || "",
			reason: ""
		});
	});
	return rows.sort((a, b) => String(b.at).localeCompare(String(a.at))).slice(0, limit);
}
function refusalActions(row, form) {
	const listed = (form?.allow || []).includes(row.sender);
	const out = [];
	if (row.sender && !form?.accept_any && !listed) out.push({
		type: "allow",
		sender: row.sender
	});
	if (row.chat && row.code === "channel_not_trusted" && (form?.allow || []).includes(row.chat) && trustOf(form, row.chat) !== "act") out.push({
		type: "act",
		chat: row.chat
	});
	return out;
}
var DM, placeFor;
var init_check = __esmMin((() => {
	init_matrix();
	init_access();
	init_connector();
	init_people();
	DM = "dm";
	placeFor = (who) => who?.kind === "channel" ? `channel:${who.id}` : "";
}));

//#endregion
//#region addons/internal/connector-ui/src/ConnectionPane.jsx
function AddonScope({ className = "", children }) {
	return /* @__PURE__ */ jsx("div", {
		"data-addon": getSdk().addonId,
		className: "cn-scope",
		children: /* @__PURE__ */ jsx("div", {
			className: className || void 0,
			children
		})
	});
}
function RecentRefusals({ id, s }) {
	const [rows, setRows] = useState$1(null);
	useEffect$1(() => {
		let live = true;
		Promise.all([connectorsApi.access(id).catch(() => null), connectorsApi.senders(id).catch(() => null)]).then(([view, log]) => {
			if (live) setRows(refusalRows({
				recent: view?.recent || [],
				senders: log?.senders || [],
				titleOf: (x) => x,
				limit: 3
			}));
		});
		return () => {
			live = false;
		};
	}, [id]);
	if (rows === null) return null;
	return /* @__PURE__ */ jsxs("section", {
		className: "cn-pane__section",
		"aria-labelledby": `cn-pane-ref-${id}`,
		children: [/* @__PURE__ */ jsx("h3", {
			className: "cn-pane__title",
			id: `cn-pane-ref-${id}`,
			children: s("refusals.title")
		}), rows.length === 0 ? /* @__PURE__ */ jsx("p", {
			className: "cn-muted",
			"data-testid": "connector-pane-refusals-none",
			children: s("refusals.none")
		}) : /* @__PURE__ */ jsx("ul", {
			className: "cn-runs cn-refusals",
			"data-testid": "connector-pane-refusals",
			children: rows.map((r) => /* @__PURE__ */ jsxs("li", { children: [
				/* @__PURE__ */ jsx("span", { children: r.name || r.sender || s("refusals.talk") }),
				r.chat && /* @__PURE__ */ jsx("span", {
					className: "cn-muted",
					children: s("access.chat", { chat: chatText(r.chat, r.chatName) })
				}),
				/* @__PURE__ */ jsx("span", {
					className: "cn-muted cn-refusals__reason",
					children: r.reason || (r.code ? s(`sender.reason.${r.code}`, { defaultValue: r.code }) : "")
				})
			] }, r.key))
		})]
	});
}
function ConnectionPane({ c, state, attention, check, testing, busy, messaging, facts, Senders, RowInfo, t, s, onClose, onToggle, onTest, onFix, fix, onEdit, onDelete, onShare }) {
	const stateText = s(`conn.state.${state}`);
	const reasonText = attention ? attention.cause === "inactive" ? t("inactive", { reason: attention.reason }) : attention.cause === "noToken" ? s("conn.reason.noToken") : attention.cause === "duplicate" ? s("conn.reason.duplicate", { name: attention.reason }) : s("conn.reason.testFailed", { reason: attention.reason }) : "";
	return /* @__PURE__ */ jsx(SidePane_default, {
		open: true,
		title: c.name,
		onClose,
		testId: "connector-pane",
		meta: /* @__PURE__ */ jsx(StateChip, {
			state,
			label: stateText
		}),
		footer: /* @__PURE__ */ jsxs("div", {
			className: "cn-pane__foot",
			children: [
				/* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--danger-ghost dk-btn--sm",
					"data-testid": "connector-pane-delete",
					onClick: () => onDelete(c),
					children: s("conn.pane.remove")
				}),
				/* @__PURE__ */ jsx("span", { className: "cn-pane__grow" }),
				onShare && /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--ghost dk-btn--sm",
					"data-testid": "connector-share",
					"aria-label": s("share.button", { name: c.name }),
					onClick: () => onShare(c),
					children: s("share.label")
				}),
				/* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--ghost dk-btn--sm",
					"data-testid": "connector-pane-edit",
					onClick: () => onEdit(c),
					children: t("editButton")
				}),
				/* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--primary dk-btn--sm",
					"aria-busy": testing ? "true" : void 0,
					disabled: testing,
					"data-testid": "connector-pane-test",
					onClick: () => onTest(c),
					children: testing ? s("conn.pane.testing") : s("conn.pane.test")
				})
			]
		}),
		children: /* @__PURE__ */ jsxs(AddonScope, {
			className: "cn-pane__body",
			children: [
				reasonText && /* @__PURE__ */ jsxs(Notice, {
					tone: "warn",
					role: "status",
					testId: "connector-pane-attention",
					children: [/* @__PURE__ */ jsx("p", {
						className: "cn-notice__text",
						children: reasonText
					}), fix && /* @__PURE__ */ jsx("button", {
						type: "button",
						className: "dk-btn dk-btn--secondary dk-btn--sm",
						"data-testid": `connector-pane-fix-${fix.kind}`,
						onClick: () => onFix(c, fix.kind),
						children: fix.label
					})]
				}),
				messaging && !c.credentials_only && /* @__PURE__ */ jsxs("div", {
					className: "cn-pane__use",
					children: [/* @__PURE__ */ jsx("span", {
						id: `cn-pane-use-${c.id}`,
						children: t("on")
					}), /* @__PURE__ */ jsx(Switch, {
						checked: Boolean(c.enabled),
						disabled: busy,
						label: t("onFor", { name: c.name }),
						testId: "connector-pane-switch",
						onChange: (on) => onToggle(c, on)
					})]
				}),
				/* @__PURE__ */ jsxs("section", {
					className: "cn-pane__section",
					"aria-labelledby": `cn-pane-test-${c.id}`,
					children: [
						/* @__PURE__ */ jsx("h3", {
							className: "cn-pane__title",
							id: `cn-pane-test-${c.id}`,
							children: s("conn.pane.lastTest")
						}),
						!check && /* @__PURE__ */ jsx("p", {
							className: "cn-muted",
							"data-testid": "connector-pane-never",
							children: s("conn.pane.never")
						}),
						check?.ok && /* @__PURE__ */ jsxs("p", {
							className: "cn-pane__ok",
							"data-testid": "connector-pane-ok",
							children: [
								/* @__PURE__ */ jsx(Icon, { name: "check-circle" }),
								" ",
								s("conn.pane.passed", { when: when(check.at) }),
								check.text ? /* @__PURE__ */ jsxs("span", {
									className: "cn-muted",
									children: [" ", check.text]
								}) : null
							]
						}),
						check && !check.ok && /* @__PURE__ */ jsxs("p", {
							className: "cn-pane__bad",
							"data-testid": "connector-pane-failed",
							children: [
								/* @__PURE__ */ jsx(Icon, { name: "alert-circle" }),
								" ",
								s("conn.pane.failed", { when: when(check.at) }),
								check.reason ? /* @__PURE__ */ jsxs("span", {
									className: "cn-muted",
									children: [" ", check.reason]
								}) : null
							]
						})
					]
				}),
				/* @__PURE__ */ jsxs("section", {
					className: "cn-pane__section",
					"aria-labelledby": `cn-pane-conn-${c.id}`,
					children: [
						/* @__PURE__ */ jsx("h3", {
							className: "cn-pane__title",
							id: `cn-pane-conn-${c.id}`,
							children: s("conn.pane.connection")
						}),
						/* @__PURE__ */ jsx("dl", {
							className: "cn-kv",
							"data-testid": "connector-pane-facts",
							children: facts.map(([k, v]) => /* @__PURE__ */ jsxs("span", {
								className: "cn-kv__row",
								children: [/* @__PURE__ */ jsx("dt", { children: k }), /* @__PURE__ */ jsx("dd", { children: v })]
							}, k))
						}),
						RowInfo && /* @__PURE__ */ jsx("div", {
							className: "cn-pane__info",
							children: /* @__PURE__ */ jsx(RowInfo, {
								c,
								t
							})
						})
					]
				}),
				messaging && /* @__PURE__ */ jsx(RecentRefusals, {
					id: c.id,
					s
				}),
				messaging && /* @__PURE__ */ jsxs("section", {
					className: "cn-pane__section",
					"aria-labelledby": `cn-pane-snd-${c.id}`,
					children: [/* @__PURE__ */ jsx("h3", {
						className: "cn-pane__title",
						id: `cn-pane-snd-${c.id}`,
						children: t("senders")
					}), Senders]
				})
			]
		})
	});
}
var when;
var init_ConnectionPane = __esmMin((() => {
	init_react();
	init_SidePane();
	init_runtime();
	init_Icon();
	init_api();
	init_check();
	init_connector();
	init_controls();
	init_ConnectionRow();
	init_people();
	init_jsx_runtime();
	when = (at) => at ? new Date(at).toLocaleString(pageLocale(), {
		dateStyle: "short",
		timeStyle: "short"
	}) : "";
}));

//#endregion
//#region addons/internal/host-compat/src/components/SideSheet.jsx
var SideSheet_default;
var init_SideSheet = __esmMin((() => {
	init_ui();
	SideSheet_default = fromSdk("SideSheet");
}));

//#endregion
//#region addons/internal/connector-ui/src/Person.jsx
var PeopleContext, usePeople;
var init_Person = __esmMin((() => {
	init_react();
	init_jsx_runtime();
	PeopleContext = createContext(/* @__PURE__ */ new Map());
	usePeople = () => useContext(PeopleContext);
}));

//#endregion
//#region addons/internal/connector-ui/src/Refusals.jsx
function Refusals({ recent, senders, titleOf, form, setForm, onAllow, s }) {
	const people = usePeople();
	const rows = refusalRows({
		recent,
		senders,
		titleOf
	});
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-sub",
		"data-testid": "connector-refusals",
		children: [
			/* @__PURE__ */ jsx("h3", {
				className: "cn-sub__title",
				children: s("refusals.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				"data-testid": "connector-refusals-note",
				children: s("refusals.help")
			}),
			rows.length === 0 ? /* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				"data-testid": "connector-refusals-none",
				children: s("refusals.none")
			}) : /* @__PURE__ */ jsx("ul", {
				className: "cn-runs cn-refusals",
				"aria-label": s("refusals.title"),
				"data-testid": "connector-audit",
				children: rows.map((r) => {
					const name = people?.get(r.sender)?.name || r.name || r.sender;
					return /* @__PURE__ */ jsxs("li", {
						"data-source": r.source,
						"data-code": r.code || void 0,
						children: [
							/* @__PURE__ */ jsx("span", {
								className: "cn-status cn-status--failed",
								children: s("refusals.refused")
							}),
							r.sender && /* @__PURE__ */ jsx("span", {
								"data-testid": "connector-audit-who",
								children: personText(people, r.sender, r.name)
							}),
							r.chat && /* @__PURE__ */ jsx("span", {
								className: "cn-muted",
								"data-testid": "connector-audit-chat",
								children: s("access.chat", { chat: chatText(r.chat, r.chatName) })
							}),
							/* @__PURE__ */ jsx("span", {
								"data-testid": "connector-audit-action",
								children: r.action ? s("refusals.action", { action: r.action }) : s("refusals.talk")
							}),
							/* @__PURE__ */ jsx("span", {
								className: "cn-muted cn-refusals__reason",
								"data-testid": "connector-audit-reason",
								children: r.reason || (r.code ? s(`sender.reason.${r.code}`, { defaultValue: r.code }) : "")
							}),
							/* @__PURE__ */ jsx("span", {
								className: "cn-muted",
								children: r.at ? new Date(r.at).toLocaleString(pageLocale(), {
									dateStyle: "short",
									timeStyle: "medium"
								}) : ""
							}),
							refusalActions(r, form).map((a) => a.type === "allow" ? /* @__PURE__ */ jsx("button", {
								type: "button",
								className: "dk-btn dk-btn--secondary dk-btn--sm",
								"data-testid": "connector-audit-allow",
								onClick: () => onAllow(a.sender),
								children: s("refusals.allow", { name })
							}, "allow") : /* @__PURE__ */ jsx("button", {
								type: "button",
								className: "dk-btn dk-btn--secondary dk-btn--sm",
								"data-testid": "connector-audit-act",
								onClick: () => setForm((f) => ({
									...f,
									allow_trust: {
										...f.allow_trust || {},
										[a.chat]: "act"
									}
								})),
								children: s("refusals.act", { channel: r.chatName || r.chat })
							}, "act"))
						]
					}, r.key);
				})
			})
		]
	});
}
var init_Refusals = __esmMin((() => {
	init_connector();
	init_check();
	init_people();
	init_Person();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/TryIt.jsx
function whoSentence(who, place, s) {
	const name = who.name || who.id;
	const where = place.kind === "dm" ? s("try.where.dm") : s("try.where.channel", { channel: place.name || place.id });
	switch (who.subject) {
		case "paired": return s("try.is.paired", {
			who: name,
			where
		});
		case "listed": return s("try.is.listed", {
			who: name,
			where
		});
		case "channel_acts": return s("try.is.channelActs", { channel: who.name || who.id });
		case "anyone": return who.kind === "channel" ? s("try.is.channelAnswers", { channel: who.name || who.id }) : s("try.is.anyone");
		default: return s("try.is.role", { role: who.name || who.id });
	}
}
function TryIt({ form, capabilities, preview, kindInfo, s, ctx, paired, isChannel, mixed, chatNames }) {
	const { who, places } = tryChoices({
		form,
		people: usePeople(),
		chatNames,
		paired,
		isChannel,
		mixed,
		roles: kindInfo?.roles
	});
	const [whoValue, setWho] = useState$1("");
	const [placeValue, setPlace] = useState$1("dm");
	const [cap, setCap] = useState$1("");
	const pickedWho = who.find((x) => x.value === whoValue) || who[0] || null;
	const forced = placeFor(pickedWho);
	const place = places.find((p) => p.value === (forced || placeValue)) || places[0];
	const capName = capabilities.some((c) => c.name === cap) ? cap : capabilities[0]?.name || "";
	const answer = tryAnswer({
		view: preview.status === "ready" || preview.status === "loading" && preview.view ? preview.view : null,
		who: pickedWho,
		capability: capName
	});
	const title = (c) => c.name === "tools.write" ? s("matrix.row.tools") : sentenceCase(c.title);
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-sub cn-try",
		"data-testid": "connector-try",
		children: [
			/* @__PURE__ */ jsx("h3", {
				className: "cn-sub__title",
				children: s("try.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				children: s("try.help")
			}),
			who.every((x) => x.kind === "role") ? /* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				"data-testid": "connector-try-none",
				children: s("try.noone")
			}) : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("div", {
				className: "cn-try__selects",
				children: [
					/* @__PURE__ */ jsx(Field, {
						label: s("try.whoLabel"),
						children: (p) => /* @__PURE__ */ jsx(Select, {
							...p,
							"data-testid": "connector-try-who",
							value: pickedWho.value,
							onChange: (e) => setWho(e.target.value),
							children: who.map((x) => /* @__PURE__ */ jsx("option", {
								value: x.value,
								children: label(x, s)
							}, x.value))
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: s("try.placeLabel"),
						children: (p) => /* @__PURE__ */ jsx(Select, {
							...p,
							"data-testid": "connector-try-place",
							value: place.value,
							disabled: Boolean(forced),
							onChange: (e) => setPlace(e.target.value),
							children: places.map((x) => /* @__PURE__ */ jsx("option", {
								value: x.value,
								children: placeLabel(x, s)
							}, x.value))
						})
					}),
					/* @__PURE__ */ jsx(Field, {
						label: s("try.actionLabel"),
						children: (p) => /* @__PURE__ */ jsx(Select, {
							...p,
							"data-testid": "connector-try-action",
							value: capName,
							onChange: (e) => setCap(e.target.value),
							children: capabilities.map((c) => /* @__PURE__ */ jsx("option", {
								value: c.name,
								children: title(c)
							}, c.name))
						})
					})
				]
			}), /* @__PURE__ */ jsx("div", {
				className: "cn-try__answer",
				role: "status",
				"aria-live": "polite",
				"data-testid": "connector-try-answer",
				"data-verdict": answer?.verdict || "wait",
				children: preview.status === "error" ? /* @__PURE__ */ jsx("p", { children: s("try.error") }) : !answer ? /* @__PURE__ */ jsx("p", {
					className: "cn-muted",
					children: s("try.loading")
				}) : answer.verdict === "unknown" ? /* @__PURE__ */ jsx("p", { children: s("try.unknown") }) : /* @__PURE__ */ jsxs(Fragment, { children: [
					/* @__PURE__ */ jsxs("p", { children: [
						/* @__PURE__ */ jsx("strong", {
							className: `cn-try__verdict cn-try__verdict--${answer.verdict}`,
							children: s(`try.verdict.${answer.verdict}`)
						}),
						" ",
						/* @__PURE__ */ jsx("span", { children: whoSentence(pickedWho, place, s) }),
						" ",
						/* @__PURE__ */ jsx("span", { children: answer.message })
					] }),
					answer.then.length > 0 && /* @__PURE__ */ jsx("p", {
						className: "cn-muted",
						"data-testid": "connector-try-then",
						children: s("can.then", { list: answer.then.map((x) => s(`can.then.${x}`)).join(", ") })
					}),
					answer.fix && /* @__PURE__ */ jsx("div", {
						className: "cn-can__fix",
						children: /* @__PURE__ */ jsx(FixButton, {
							fix: answer.fix,
							ctx,
							s
						})
					})
				] })
			})] }),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				"data-testid": "connector-try-note",
				children: s("try.note")
			})
		]
	});
}
var label, placeLabel;
var init_TryIt = __esmMin((() => {
	init_react();
	init_controls();
	init_accessHooks();
	init_access();
	init_check();
	init_Person();
	init_jsx_runtime();
	label = (c, s) => c.kind === "person" ? c.name || c.id : c.kind === "channel" ? s("try.someoneIn", { channel: c.name || c.id }) : c.kind === "anyone" ? s("try.anyone") : s("try.role", { role: c.name || c.id });
	placeLabel = (p, s) => p.kind === "dm" ? s("try.dm") : p.name || p.id;
}));

//#endregion
//#region addons/internal/connector-ui/src/approvals.js
function approvalState(a, sender = "") {
	if (!a) return "asks";
	const who = Array.isArray(a.runs_without_asking) ? a.runs_without_asking : [];
	if (who.length === 0) return a.skip === true ? "idle" : "asks";
	if (sender && !who.includes(sender)) return "other";
	return "runs";
}
var init_approvals = __esmMin((() => {}));

//#endregion
//#region addons/internal/connector-ui/src/ApprovalsView.jsx
function ApprovalsView({ approvals, s, sender = "", testId = "connector-approvals" }) {
	const list = Array.isArray(approvals) ? approvals : [];
	if (list.length === 0) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-approvals",
		"data-testid": testId,
		children: [
			/* @__PURE__ */ jsx("h4", {
				className: "cn-approvals__title",
				children: s("approvals.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				children: s("approvals.help")
			}),
			/* @__PURE__ */ jsx("ul", {
				className: "cn-approvals__list",
				"aria-label": s("approvals.title"),
				children: list.map((a) => {
					const state = approvalState(a, sender);
					return /* @__PURE__ */ jsxs("li", {
						className: "cn-approvals__row",
						"data-testid": `connector-approval-${a.tool}`,
						"data-state": state,
						children: [
							/* @__PURE__ */ jsx("code", {
								className: "cn-approvals__tool",
								children: a.tool
							}),
							/* @__PURE__ */ jsx("span", {
								className: `cn-approvals__state cn-approvals__state--${state}`,
								children: s(`approvals.state.${state}`)
							}),
							/* @__PURE__ */ jsx("span", {
								className: "cn-muted",
								children: s(`approvals.line.${state}`)
							})
						]
					}, a.tool);
				})
			})
		]
	});
}
var init_ApprovalsView = __esmMin((() => {
	init_approvals();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/NoteSaveView.jsx
function NoteSaveView({ subjects, s, testId = "connector-notesave" }) {
	const rows = (Array.isArray(subjects) ? subjects : []).filter((x) => x && (x.note_save === "now" || x.note_save === "ask"));
	if (rows.length === 0) return null;
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-approvals",
		"data-testid": testId,
		children: [/* @__PURE__ */ jsx("h4", {
			className: "cn-approvals__title",
			children: s("access.noteSave.title")
		}), /* @__PURE__ */ jsx("ul", {
			className: "cn-approvals__list",
			"aria-label": s("access.noteSave.title"),
			children: rows.map((x) => /* @__PURE__ */ jsxs("li", {
				className: "cn-approvals__row",
				"data-testid": `${testId}-${x.id}`,
				"data-state": x.note_save,
				children: [rows.length > 1 && /* @__PURE__ */ jsx("span", {
					className: "cn-muted",
					children: x.title
				}), /* @__PURE__ */ jsx("span", { children: s(`access.noteSave.${x.note_save}`) })]
			}, x.id))
		})]
	});
}
var init_NoteSaveView = __esmMin((() => {
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/AccessView.jsx
function AccessView({ binding, capabilities, s, version, onAllowed, setForm, preview, kindInfo, ctx, paired, isChannel, mixed, chatNames, senders }) {
	const [view, setView] = useState$1(null);
	const [error, setError] = useState$1("");
	const [loading, setLoading] = useState$1(false);
	const id = binding.id;
	const load = useCallback(async () => {
		if (!id) return;
		setLoading(true);
		setError("");
		try {
			setView(await connectorsApi.access(id));
		} catch (e) {
			setError(e?.message || "");
		} finally {
			setLoading(false);
		}
	}, [id]);
	useEffect$1(() => {
		load();
	}, [load, version]);
	const allowPerson = async (sender) => {
		setError("");
		try {
			await connectorsApi.allow(id, sender);
			await load();
			onAllowed?.(sender);
		} catch (e) {
			setError(e?.message || "");
		}
	};
	const titleOf = (name) => name === "tools.write" ? s("matrix.row.tools") : (capabilities || []).find((c) => c.name === name)?.title || name;
	return /* @__PURE__ */ jsxs("fieldset", {
		className: "cn-group",
		"data-testid": "connector-access",
		children: [
			/* @__PURE__ */ jsx("legend", { children: s("access.title") }),
			/* @__PURE__ */ jsx(TryIt, {
				form: binding,
				capabilities: capabilities || [],
				preview,
				kindInfo,
				s,
				ctx,
				paired,
				isChannel,
				mixed,
				chatNames
			}),
			!id ? /* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				children: s("access.needSave")
			}) : /* @__PURE__ */ jsxs(Fragment, { children: [
				error && /* @__PURE__ */ jsx(Notice, {
					tone: "error",
					role: "alert",
					children: error
				}),
				/* @__PURE__ */ jsx("div", { children: /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--secondary dk-btn--sm",
					"aria-busy": loading ? "true" : void 0,
					disabled: loading,
					onClick: load,
					children: s("access.refresh")
				}) }),
				view && /* @__PURE__ */ jsxs(Fragment, { children: [
					/* @__PURE__ */ jsx(Refusals, {
						recent: view.recent,
						senders,
						titleOf,
						form: binding,
						setForm,
						onAllow: allowPerson,
						s
					}),
					/* @__PURE__ */ jsx(NoteSaveView, {
						subjects: view.subjects,
						s,
						testId: "connector-access-notesave"
					}),
					/* @__PURE__ */ jsx(ApprovalsView, {
						approvals: view.approvals,
						s,
						testId: "connector-access-approvals"
					}),
					/* @__PURE__ */ jsx(ToolOutcomes, {
						rows: toolOutcomeRows(view),
						s
					})
				] })
			] })
		]
	});
}
function ToolOutcomes({ rows, s }) {
	const people = usePeople();
	return /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("p", {
		className: "dk-hint",
		children: s("access.toolsHelp")
	}), rows.length === 0 ? /* @__PURE__ */ jsx("p", {
		className: "cn-muted",
		children: s("access.toolsNone")
	}) : /* @__PURE__ */ jsx("ul", {
		className: "cn-runs",
		"aria-label": s("access.toolsTitle"),
		"data-testid": "connector-tool-outcomes",
		children: rows.map((r) => /* @__PURE__ */ jsxs("li", {
			"data-outcome": r.outcome,
			children: [
				/* @__PURE__ */ jsx("span", {
					className: `cn-status cn-status--${r.tone}`,
					children: s(`access.outcome.${r.outcome}`)
				}),
				/* @__PURE__ */ jsx("span", {
					className: "cn-mono",
					children: r.tool
				}),
				/* @__PURE__ */ jsx("span", {
					className: "cn-muted",
					children: new Date(r.at).toLocaleString(pageLocale(), {
						dateStyle: "short",
						timeStyle: "medium"
					})
				}),
				r.message && /* @__PURE__ */ jsx("span", {
					className: "cn-muted",
					children: r.message
				}),
				r.senders.length > 0 && /* @__PURE__ */ jsx("span", {
					className: "cn-muted cn-mono",
					children: s("access.who", { senders: r.senders.map((x, k) => personText(people, x, k === 0 ? r.senderName : "")).join(", ") })
				}),
				r.asker && /* @__PURE__ */ jsx("span", {
					className: "cn-muted cn-mono",
					children: s("access.askedBy", { sender: personText(people, r.asker) })
				})
			]
		}, r.key))
	})] });
}
var init_AccessView = __esmMin((() => {
	init_react();
	init_controls();
	init_api();
	init_connector();
	init_Refusals();
	init_TryIt();
	init_ApprovalsView();
	init_NoteSaveView();
	init_access();
	init_people();
	init_Person();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/ReadinessList.jsx
function sentence(row, s) {
	const { messageKey, modeKey, ...rest } = row.params || {};
	const words = messageKey ? {
		...rest,
		message: s(messageKey)
	} : rest;
	return s(row.key, modeKey ? {
		...words,
		mode: s(modeKey)
	} : words);
}
function ReadinessList({ rowsInput, s, ctx, onTest, onSave, isNew = false }) {
	const all = statusRows(readinessRows(rowsInput));
	const rows = isNew ? forNewConnection(all) : all;
	const [expanded, setExpanded] = useState$1(false);
	const [open, setOpen] = useState$1(false);
	const collapsed = visibleRows(rows, expanded);
	const shown = isNew && !expanded ? collapsed.shown.filter((r) => isThingToSet(r.state)) : collapsed.shown;
	const hidden = isNew && !expanded ? rows.length - shown.length : collapsed.hidden;
	const problems = isNew ? thingsToSet(rows) : rows.length - rows.filter((r) => [
		"ok",
		"off",
		"checking"
	].includes(r.state)).length;
	const body = /* @__PURE__ */ jsxs("section", {
		id: "cn-ready-body",
		className: "cn-ready",
		"aria-labelledby": "cn-ready-title",
		"data-testid": "connector-readiness",
		children: [
			/* @__PURE__ */ jsxs("div", {
				className: "cn-ready__head",
				children: [
					/* @__PURE__ */ jsx("h2", {
						id: "cn-ready-title",
						className: "cn-sub__title",
						children: s("ready.title")
					}),
					/* @__PURE__ */ jsx("span", {
						className: "cn-muted",
						"data-testid": "connector-ready-summary",
						children: problems > 0 ? s("ready.notReady") : rows.some((r) => r.state === "checking") ? s("ready.checkingSummary") : s("ready.allGood")
					}),
					problems > 0 && /* @__PURE__ */ jsx("span", {
						className: "cn-pill",
						"data-testid": "connector-ready-pill",
						children: s("ready.fixCount", { count: problems })
					})
				]
			}),
			/* @__PURE__ */ jsx("ul", {
				className: "cn-ready__list",
				"aria-label": s("ready.title"),
				children: shown.map((r) => /* @__PURE__ */ jsxs("li", {
					className: "cn-ready__row",
					"data-testid": `connector-ready-${r.id}`,
					"data-state": r.state,
					children: [
						/* @__PURE__ */ jsxs("span", {
							className: `cn-ready__state cn-ready__state--${r.state}`,
							children: [/* @__PURE__ */ jsx(Icon, { name: ICON$1[r.state] || "info" }), /* @__PURE__ */ jsx("span", { children: s(`ready.state.${r.state}`) })]
						}),
						/* @__PURE__ */ jsxs("div", {
							className: "cn-ready__text",
							children: [/* @__PURE__ */ jsx("span", {
								className: "cn-ready__label",
								children: s(r.labelKey || `ready.row.${r.id}`)
							}), /* @__PURE__ */ jsx("span", {
								className: "cn-ready__sentence",
								children: sentence(r, s)
							})]
						}),
						r.fix && /* @__PURE__ */ jsx("div", {
							className: "cn-ready__fix",
							children: /* @__PURE__ */ jsx(FixButton, {
								fix: r.fix,
								ctx,
								s,
								onTest,
								onSave
							})
						})
					]
				}, r.id))
			}),
			(hidden > 0 || expanded) && /* @__PURE__ */ jsx("button", {
				type: "button",
				className: "cn-hint__more cn-ready__toggle",
				"aria-expanded": expanded,
				"data-testid": "connector-ready-toggle",
				onClick: () => setExpanded(!expanded),
				children: expanded ? s("ready.showProblems") : s("ready.showAll", { count: rows.length })
			})
		]
	});
	if (!isNew) return body;
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-ready-quiet",
		children: [/* @__PURE__ */ jsx("button", {
			type: "button",
			className: "cn-hint__more",
			"aria-expanded": open,
			"aria-controls": open ? "cn-ready-body" : void 0,
			"data-testid": "connector-ready-quiet",
			onClick: () => setOpen(!open),
			children: problems > 0 ? s("ready.quiet", { count: problems }) : s("ready.quietDone")
		}), open && body]
	});
}
var ICON$1;
var init_ReadinessList = __esmMin((() => {
	init_react();
	init_Icon();
	init_accessHooks();
	init_access();
	init_jsx_runtime();
	ICON$1 = {
		ok: "check-circle",
		attention: "warning",
		off: "minus",
		after_save: "save",
		broken: "alert-circle",
		checking: "spinner",
		unknown: "help-circle"
	};
}));

//#endregion
//#region addons/internal/connector-ui/src/ApprovalFields.jsx
/** The line under "Propose triggers": the mode, and the acts a run may do. */
function approvalEffect(a, s) {
	const base = s("approval.effect", { mode: s(`approval.short.${a.mode || "ask"}`) });
	const acts = APPROVAL_ACTS.filter((n) => (a.acts || []).includes(n));
	return acts.length === 0 ? base : base + s("approval.effectActs", { acts: acts.map((n) => s(`approval.actShort.${n}`)).join(", ") });
}
function changeEffect(a, s) {
	return s("approval.effectChange", { mode: s(`approval.short.${a.mode === "auto" ? "auto" : "ask"}`) });
}
/**
* The approval mode and its limits, as an option under "Propose triggers".
* With off set (the permission is not ticked) the choice is greyed, with the
* reason, and nothing can be changed. The limits sit in a closed disclosure.
*/
function ApprovalOptions({ form, setForm, s, off = false, held = null }) {
	const a = form.approval;
	const reasonId = useId();
	const [actsOpen, setActsOpen] = useState$1(false);
	const set = (patch) => setForm({
		...form,
		approval: {
			...a,
			...patch
		}
	});
	const bad = approvalProblem(a);
	const acts = a.acts || [];
	const actsOn = acts.length > 0 || actsOpen;
	const toggle = (name, v) => set({ acts: APPROVAL_ACTS.filter((n) => n === name ? v : acts.includes(n)) });
	return /* @__PURE__ */ jsxs("fieldset", {
		className: "cn-option",
		"data-testid": "connector-approval",
		"data-off": off ? "true" : void 0,
		disabled: off,
		"aria-describedby": off ? reasonId : void 0,
		children: [
			/* @__PURE__ */ jsx("legend", {
				className: "cn-vh",
				children: s("approval.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "cn-option__title",
				children: s("approval.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				children: s("approval.help")
			}),
			off && /* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				id: reasonId,
				"data-testid": "connector-approval-off",
				children: s("perm.triggersNeed")
			}),
			/* @__PURE__ */ jsx(RadioCards, {
				name: "approval",
				legend: s("approval.title"),
				value: a.mode,
				onChange: (mode) => set({ mode }),
				options: APPROVAL_MODES.map((m) => ({
					value: m,
					label: s(`approval.mode.${m}`)
				}))
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "cn-acts",
				"data-testid": "connector-acts",
				children: [
					/* @__PURE__ */ jsx(Switch, {
						checked: actsOn,
						testId: "connector-acts-switch",
						onChange: (v) => {
							setActsOpen(v);
							if (!v) set({ acts: [] });
						},
						children: /* @__PURE__ */ jsx("span", {
							className: "cn-cap__title",
							children: s("approval.acts.title")
						})
					}),
					/* @__PURE__ */ jsx("p", {
						className: "dk-hint",
						children: s("approval.acts.help")
					}),
					actsOn && /* @__PURE__ */ jsx("ul", {
						className: "cn-acts__list",
						children: APPROVAL_ACTS.map((n) => {
							const on = acts.includes(n);
							const lacks = !agentHoldsAct(held, n);
							const blocked = lacks && !on;
							return /* @__PURE__ */ jsxs("li", {
								className: "cn-acts__item",
								"data-testid": `connector-act-${n}`,
								"data-lacks": lacks ? "true" : void 0,
								children: [
									/* @__PURE__ */ jsxs("label", {
										className: "cn-acts__label",
										children: [/* @__PURE__ */ jsx("input", {
											type: "checkbox",
											className: "dk-check",
											"data-testid": `connector-act-check-${n}`,
											checked: on,
											disabled: blocked,
											"aria-describedby": lacks ? `${reasonId}-${n}` : void 0,
											onChange: (e) => toggle(n, e.target.checked)
										}), /* @__PURE__ */ jsxs("span", {
											className: "cn-acts__text",
											children: [/* @__PURE__ */ jsx("span", {
												className: "cn-cap__title",
												children: s(`approval.acts.${n}`)
											}), /* @__PURE__ */ jsx("span", {
												className: "cn-badge cn-badge--warn",
												children: s("approval.acts.sensitive")
											})]
										})]
									}),
									/* @__PURE__ */ jsx("p", {
										className: "cn-cap__effect",
										children: s(`approval.acts.${n}.effect`)
									}),
									lacks && /* @__PURE__ */ jsx("p", {
										className: "cn-cap__lacks",
										id: `${reasonId}-${n}`,
										"data-testid": `connector-act-lacks-${n}`,
										children: s("approval.acts.lacks")
									})
								]
							}, n);
						})
					}),
					/* @__PURE__ */ jsx("p", {
						className: "dk-hint",
						"data-testid": "connector-acts-modes",
						children: s("approval.acts.modes")
					})
				]
			}),
			/* @__PURE__ */ jsxs("details", {
				className: "cn-option__limits",
				"data-testid": "connector-approval-limits",
				open: bad ? true : void 0,
				children: [
					/* @__PURE__ */ jsx("summary", { children: s("approval.limits") }),
					/* @__PURE__ */ jsx("p", {
						className: "dk-hint",
						children: s("approval.limitsHelp")
					}),
					APPROVAL_LIMITS.map(({ key, max, fallback }) => /* @__PURE__ */ jsx(Field, {
						label: s(`approval.${key}`),
						hint: s("approval.default", { value: fallback }),
						error: bad === key ? s("approval.invalid", { max }) : void 0,
						children: (p) => /* @__PURE__ */ jsx(TextInput, {
							...p,
							type: "number",
							inputMode: "numeric",
							min: "1",
							max,
							step: "1",
							"data-testid": `connector-approval-${key}`,
							value: a[key],
							onChange: (e) => set({ [key]: e.target.value })
						})
					}, key))
				]
			})
		]
	});
}
var init_ApprovalFields = __esmMin((() => {
	init_react();
	init_controls();
	init_connector();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/FilesFields.jsx
function shown(base, saved, mib) {
	return previewLimit(base, mib) || (saved ? {
		bytes: saved.effective_bytes,
		layer: saved.layer
	} : null);
}
function Limit({ label, help, mib, onChange, base, saved, s, testId }) {
	const dir = fileDirection(base);
	const problem = dir === "off" ? "" : fileLimitProblem(mib, base?.allowed_bytes);
	const limit = dir === "off" ? null : shown(base, saved, mib);
	return /* @__PURE__ */ jsx(Field, {
		label,
		error: problem === "invalid" ? s("files.invalid") : problem === "tooHigh" ? s("files.tooHigh", { max: formatBytes(base.allowed_bytes) }) : void 0,
		hint: [
			help,
			dir === "declared" ? s("files.addon.declared", { max: formatBytes(base.declared_bytes) }) : dir === "open" ? s("files.addon.open") : dir === "off" ? s("files.addon.off") : "",
			limit ? s("files.now", {
				limit: formatBytes(limit.bytes),
				layer: s(`files.layer.${limit.layer}`)
			}) : ""
		].filter(Boolean).join(" "),
		children: (p) => /* @__PURE__ */ jsx(TextInput, {
			...p,
			type: "number",
			inputMode: "decimal",
			min: "0",
			step: "any",
			"data-testid": testId,
			disabled: dir === "off",
			value: dir === "off" ? "" : mib,
			onChange: (e) => onChange(e.target.value)
		})
	});
}
/**
* @param {object} props
* @param {object} props.form    the form of the binding
* @param {Function} props.setForm
* @param {object} [props.kind]  the files of the kind, from the kind list
* @param {object} [props.saved] the files of the saved binding, when there is one
* @param {Function} props.s     the translation function with the defaults
*/
function FilesFields({ form, setForm, kind, saved, s }) {
	const hostCeiling = kind?.host_ceiling_bytes || 0;
	return /* @__PURE__ */ jsxs("fieldset", {
		className: "cn-group",
		"data-testid": "connector-filelimits",
		children: [
			/* @__PURE__ */ jsx("legend", { children: s("files.title") }),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				children: s("files.help")
			}),
			hostCeiling > 0 && /* @__PURE__ */ jsx(Hint, { children: s("files.host", { max: formatBytes(hostCeiling) }) }),
			/* @__PURE__ */ jsx(Limit, {
				label: s("files.receiveLabel"),
				help: s("files.receiveHelp"),
				mib: form.file_receive_mib,
				base: kind?.receive,
				saved: saved?.receive,
				s,
				testId: "connector-file-receive",
				onChange: (v) => setForm({
					...form,
					file_receive_mib: v
				})
			}),
			/* @__PURE__ */ jsx(Limit, {
				label: s("files.sendLabel"),
				help: s("files.sendHelp"),
				mib: form.file_send_mib,
				base: kind?.send,
				saved: saved?.send,
				s,
				testId: "connector-file-send",
				onChange: (v) => setForm({
					...form,
					file_send_mib: v
				})
			})
		]
	});
}
var init_FilesFields = __esmMin((() => {
	init_controls();
	init_connector();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/pairing.jsx
function time(iso) {
	const d = new Date(iso);
	return Number.isNaN(d.getTime()) ? "" : d.toLocaleString(pageLocale(), {
		dateStyle: "medium",
		timeStyle: "short"
	});
}
/**
* The pairings of one saved binding and the code of the one being made. The
* list follows the host: it is read again while a code is live, and a sender
* that used it is reported to onPaired.
*/
function usePairing(binding, onPaired) {
	const [paired, setPaired] = useState$1(binding.paired || []);
	const [code, setCode] = useState$1(null);
	const [expired, setExpired] = useState$1(false);
	const [done, setDone] = useState$1("");
	const [error, setError] = useState$1("");
	const [busy, setBusy] = useState$1(false);
	const known = useRef(new Set((binding.paired || []).map((p) => p.sender_id)));
	const id = binding.id;
	useEffect$1(() => {
		if (!code || !id) return void 0;
		const stop = () => {
			clearInterval(timer);
		};
		const timer = setInterval(async () => {
			if (Date.now() > new Date(code.expires).getTime()) {
				setExpired(true);
				setCode(null);
				stop();
				return;
			}
			try {
				const list = ((await connectorsApi.list()).connectors || []).find((c) => c.id === id)?.paired || [];
				const fresh = list.find((p) => !known.current.has(p.sender_id));
				if (fresh) {
					known.current = new Set(list.map((p) => p.sender_id));
					setPaired(list);
					setCode(null);
					setDone(fresh.sender_id);
					onPaired?.(list);
					stop();
				}
			} catch (_e) {}
		}, POLL_MS);
		return stop;
	}, [
		code,
		id,
		onPaired
	]);
	const start = async () => {
		setBusy(true);
		setError("");
		setDone("");
		setExpired(false);
		try {
			setCode(await connectorsApi.pair(id));
		} catch (e) {
			setError(e?.message || "");
		} finally {
			setBusy(false);
		}
	};
	const remove = async (sender) => {
		setError("");
		try {
			const list = (await connectorsApi.unpair(id, sender))?.paired || paired.filter((p) => p.sender_id !== sender);
			known.current = new Set(list.map((p) => p.sender_id));
			setPaired(list);
			onPaired?.(list);
		} catch (e) {
			setError(e?.message || "");
		}
	};
	return {
		paired,
		code,
		expired,
		done,
		error,
		busy,
		start,
		remove,
		hideCode: () => setCode(null),
		full: paired.length >= 3,
		saved: Boolean(id)
	};
}
/** What the last verification did: an error, the person who was verified, an expired code, or the code itself. */
function PairingNotices({ p, s }) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		p.error && /* @__PURE__ */ jsx(Notice, {
			tone: "error",
			role: "alert",
			children: p.error
		}),
		p.done && /* @__PURE__ */ jsx(Notice, {
			tone: "ok",
			role: "status",
			children: s("pair.done", { sender: p.done })
		}),
		p.expired && /* @__PURE__ */ jsx(Notice, {
			tone: "info",
			role: "status",
			children: s("pair.codeGone")
		}),
		p.code && /* @__PURE__ */ jsxs(Notice, {
			tone: "info",
			role: "status",
			testId: "connector-pair-code-box",
			children: [
				/* @__PURE__ */ jsx("p", {
					className: "cn-notice__title",
					children: s("pair.codeTitle")
				}),
				/* @__PURE__ */ jsx("p", {
					className: "cn-pairing__code",
					"data-testid": "connector-pair-code",
					children: p.code.code
				}),
				/* @__PURE__ */ jsx("p", {
					className: "cn-notice__text",
					children: s("pair.codeHelp", { time: time(p.code.expires) })
				}),
				/* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--secondary dk-btn--sm",
					onClick: p.hideCode,
					children: s("pair.dismiss")
				})
			]
		})
	] });
}
var MAX_PAIRED, POLL_MS;
var init_pairing = __esmMin((() => {
	init_react();
	init_controls();
	init_api();
	init_connector();
	init_jsx_runtime();
	MAX_PAIRED = 3;
	POLL_MS = 3e3;
}));

//#endregion
//#region addons/internal/connector-ui/src/WhoFields.jsx
function Who({ id, name }) {
	return /* @__PURE__ */ jsxs("span", {
		className: "cn-who__who",
		children: [/* @__PURE__ */ jsx("span", {
			className: "cn-who__name",
			children: name || id
		}), name && /* @__PURE__ */ jsx("span", {
			className: "cn-who__id cn-mono",
			children: id
		})]
	});
}
function LevelSelect({ entry, level, onChange, t, testId = "connector-trust-level" }) {
	return /* @__PURE__ */ jsxs(Select, {
		"data-testid": testId,
		"aria-label": t("who.levelFor", { channel: entry }),
		value: level,
		onChange: (e) => onChange(e.target.value),
		children: [/* @__PURE__ */ jsx("option", {
			value: "answer",
			children: t("trust.answer")
		}), /* @__PURE__ */ jsx("option", {
			value: "act",
			children: t("trust.act")
		})]
	});
}
function PostStatus({ form, id, name, s, onAdd, onShow }) {
	const place = placeFor$1(form, id);
	if (!place) return /* @__PURE__ */ jsxs("span", {
		className: "cn-who__post",
		"data-testid": "connector-post-status",
		"data-post": "none",
		children: [/* @__PURE__ */ jsx("span", {
			className: "cn-muted",
			children: s("who.post.none")
		}), /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "dk-btn dk-btn--secondary dk-btn--sm",
			"data-testid": "connector-post-add",
			"aria-label": s("who.post.addFor", { name }),
			onClick: onAdd,
			children: s("who.post.add")
		})]
	});
	return /* @__PURE__ */ jsxs("span", {
		className: "cn-who__post",
		"data-testid": "connector-post-status",
		"data-post": place.approved ? "any" : "verified",
		children: [/* @__PURE__ */ jsx("span", {
			className: "cn-muted",
			children: place.approved ? s("who.post.any") : s("who.post.verified")
		}), /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "cn-link cn-link--text",
			"data-testid": "connector-post-show",
			"aria-label": s("who.post.showFor", { name }),
			onClick: onShow,
			children: s("who.post.show")
		})]
	});
}
/**
* @param {object} props
* @param {object} props.form
* @param {Function} props.setForm
* @param {Function} props.t            the words of the add-on, then the shared ones
* @param {Function} props.s            the shared words
* @param {boolean} props.confirmed     the "anyone" warning is confirmed
* @param {Function} props.setConfirmed
* @param {Function} props.isChannel    whether an entry names a channel or group (a kind knows its IDs)
* @param {boolean} [props.mixed]       a kind that cannot tell a person from a channel by its ID keeps one list and
*                                      shows the level on every entry
* @param {Function} [props.onPaired]   called with the pairings of the binding when they change
* @param {Array} props.recent          people of the sender log who are not listed: { id, name }
* @param {Map} props.chatNames         chat ID -> name
* @param {string} [props.hint]         the placeholder of the add box
* @param {string} [props.help]         a line under the add box
*/
function WhoFields({ form, setForm, t, s, confirmed, setConfirmed, isChannel, mixed = false, onPaired, recent, chatNames, hint, help }) {
	const pairing = usePairing(form, onPaired);
	const people = usePeople();
	const [text, setText] = useState$1("");
	const anyone = Boolean(form.accept_any);
	const allow = anyone ? [] : form.allow || [];
	const verified = new Map((pairing.paired || []).map((p) => [p.sender_id, p]));
	const channels = mixed ? [] : allow.filter((x) => isChannel(x));
	const listed = mixed ? allow : allow.filter((x) => !isChannel(x));
	const onlyVerified = [...verified.keys()].filter((x) => !allow.includes(x));
	const rows = [...listed, ...onlyVerified];
	const setAllow = (next) => setForm({
		...form,
		allow: next,
		allow_trust: trustAfter(form, next, isChannel)
	});
	const add = (raw) => {
		const v = String(raw).trim();
		if (v && !allow.includes(v)) setAllow([...allow, v]);
		setText("");
	};
	const remove = (id) => {
		setAllow(allow.filter((x) => x !== id));
		if (verified.has(id)) pairing.remove(id);
	};
	const canPost = (form.caps || []).includes("talkback.channels");
	const showPlace = (id) => {
		const row = document.getElementById(`cn-place-${id}`);
		row?.scrollIntoView?.({ block: "center" });
		row?.querySelector("select")?.focus();
	};
	const setLevel = (entry, level) => setForm({
		...form,
		allow_trust: {
			...form.allow_trust || {},
			[entry]: level
		}
	});
	const verifyDisabled = pairing.busy || pairing.full || !pairing.saved;
	const verifyHint = !pairing.saved ? s("pair.needSave") : pairing.full ? s("pair.full") : s("pair.startHelp");
	const personRow = (id) => {
		const p = verified.get(id);
		const entry = mixed && !onlyVerified.includes(id);
		return /* @__PURE__ */ jsxs("li", {
			className: `cn-who__row${entry ? " cn-who__row--mixed" : ""}`,
			"data-testid": "connector-person-row",
			"data-id": id,
			"data-verified": p ? "true" : "false",
			children: [
				/* @__PURE__ */ jsx(Who, {
					id,
					name: nameOf(people, id) || chatNames.get(id) || ""
				}),
				/* @__PURE__ */ jsxs("span", {
					className: "cn-who__badges",
					children: [/* @__PURE__ */ jsx("span", {
						className: `cn-badge${p ? " cn-badge--ok" : ""}`,
						"data-testid": "connector-person-badge",
						children: p ? s("who.verified") : s("who.listed")
					}), p && /* @__PURE__ */ jsx("span", {
						className: "cn-muted cn-who__ends",
						children: s("pair.expires", { time: time(p.expires_at) })
					})]
				}),
				entry && /* @__PURE__ */ jsx(LevelSelect, {
					entry: id,
					level: trustOf(form, id),
					onChange: (v) => setLevel(id, v),
					t: s
				}),
				/* @__PURE__ */ jsxs("span", {
					className: "cn-who__actions",
					children: [!p && /* @__PURE__ */ jsx("button", {
						type: "button",
						className: "dk-btn dk-btn--secondary dk-btn--sm",
						"data-testid": "connector-verify",
						disabled: verifyDisabled,
						"aria-label": s("who.verifyPerson", { name: nameOf(people, id) || id }),
						onClick: pairing.start,
						children: s("who.verify")
					}), /* @__PURE__ */ jsx("button", {
						type: "button",
						className: "dk-btn dk-btn--secondary dk-btn--sm",
						"aria-label": s("who.removePerson", { name: nameOf(people, id) || id }),
						onClick: () => remove(id),
						children: s("who.remove")
					})]
				})
			]
		}, id);
	};
	return /* @__PURE__ */ jsxs("fieldset", {
		className: "cn-group",
		"data-testid": "connector-who",
		tabIndex: -1,
		children: [
			/* @__PURE__ */ jsx("legend", { children: s("who.title") }),
			/* @__PURE__ */ jsx(RadioCards, {
				name: "who",
				legend: s("who.title"),
				value: anyone,
				onChange: (any) => {
					setForm({
						...form,
						accept_any: any
					});
					if (!any) setConfirmed(false);
				},
				options: [{
					value: false,
					label: s("who.onlyChosen")
				}, {
					value: true,
					label: s("who.anyone")
				}]
			}),
			anyone && /* @__PURE__ */ jsxs(Notice, {
				tone: "warn",
				role: "alert",
				testId: "anyone-warning",
				children: [/* @__PURE__ */ jsx("p", {
					className: "cn-notice__text",
					children: t("anyoneWarning")
				}), /* @__PURE__ */ jsx(Check, {
					checked: confirmed,
					onChange: setConfirmed,
					children: t("anyoneConfirm")
				})]
			}),
			/* @__PURE__ */ jsxs("div", {
				className: "cn-sub",
				"data-testid": "connector-pairing",
				children: [
					/* @__PURE__ */ jsx("h3", {
						className: "cn-sub__title",
						children: mixed ? s("who.peopleAndChannels") : s("who.people")
					}),
					/* @__PURE__ */ jsx(PairingNotices, {
						p: pairing,
						s
					}),
					rows.length === 0 ? /* @__PURE__ */ jsx("p", {
						className: "cn-muted",
						children: anyone ? s("pair.none") : s("who.peopleNone")
					}) : /* @__PURE__ */ jsx("ul", {
						className: "cn-who__list",
						"aria-label": mixed ? s("who.peopleAndChannels") : s("who.people"),
						"data-testid": "connector-who-people",
						children: rows.map(personRow)
					}),
					/* @__PURE__ */ jsxs("div", {
						className: "cn-who__verify",
						children: [/* @__PURE__ */ jsx("button", {
							type: "button",
							className: "dk-btn dk-btn--secondary",
							"data-testid": "connector-pair-start",
							disabled: verifyDisabled,
							onClick: pairing.start,
							children: s("pair.start")
						}), /* @__PURE__ */ jsx("p", {
							className: "dk-hint",
							children: verifyHint
						})]
					})
				]
			}),
			!anyone && channels.length > 0 && /* @__PURE__ */ jsxs("div", {
				className: "cn-sub",
				"data-testid": "connector-who-channels",
				children: [
					/* @__PURE__ */ jsx("h3", {
						className: "cn-sub__title",
						children: s("who.channels")
					}),
					/* @__PURE__ */ jsx("ul", {
						className: "cn-who__list",
						"aria-label": s("who.channels"),
						children: channels.map((id) => /* @__PURE__ */ jsxs("li", {
							className: "cn-who__row",
							"data-testid": "connector-trust-row",
							"data-channel": id,
							"data-level": trustOf(form, id),
							children: [
								/* @__PURE__ */ jsx(Who, {
									id,
									name: chatNames.get(id) || ""
								}),
								/* @__PURE__ */ jsx(LevelSelect, {
									entry: id,
									level: trustOf(form, id),
									onChange: (v) => setLevel(id, v),
									t: s
								}),
								/* @__PURE__ */ jsx("span", {
									className: "cn-who__actions",
									children: /* @__PURE__ */ jsx("button", {
										type: "button",
										className: "dk-btn dk-btn--secondary dk-btn--sm",
										"aria-label": s("who.removeChannel", { name: chatNames.get(id) || id }),
										onClick: () => setAllow(allow.filter((x) => x !== id)),
										children: s("who.remove")
									})
								}),
								canPost && /* @__PURE__ */ jsx(PostStatus, {
									form,
									id,
									name: chatNames.get(id) || id,
									s,
									onAdd: () => setForm(withPlace(form, id, chatNames.get(id) || "")),
									onShow: () => showPlace(id)
								})
							]
						}, id))
					}),
					/* @__PURE__ */ jsx("p", {
						className: "dk-hint",
						"data-testid": "connector-who-channels-note",
						children: s("who.channelsNote")
					})
				]
			}),
			!anyone && /* @__PURE__ */ jsxs("div", {
				"data-testid": "connector-allow",
				children: [/* @__PURE__ */ jsx(Field, {
					label: s("who.add"),
					hint: help,
					children: (p) => /* @__PURE__ */ jsxs("div", {
						className: "cn-add",
						children: [/* @__PURE__ */ jsx("input", {
							...p,
							className: "dk-input",
							value: text,
							placeholder: hint,
							onChange: (e) => setText(e.target.value),
							onKeyDown: (e) => {
								if (e.key === "Enter" || e.key === ",") {
									e.preventDefault();
									add(text);
								}
							}
						}), /* @__PURE__ */ jsx("button", {
							type: "button",
							className: "dk-btn dk-btn--secondary",
							onClick: () => add(text),
							disabled: !text.trim(),
							children: s("add")
						})]
					})
				}), recent.length > 0 && /* @__PURE__ */ jsxs("div", {
					className: "cn-who__recent",
					"data-testid": "connector-recent",
					children: [/* @__PURE__ */ jsx("p", {
						className: "dk-hint",
						children: s("who.recent")
					}), /* @__PURE__ */ jsx("ul", {
						className: "cn-chips",
						"aria-label": s("who.recent"),
						children: recent.map((r) => /* @__PURE__ */ jsx("li", { children: /* @__PURE__ */ jsxs("button", {
							type: "button",
							className: "dk-chip dk-chip--sm cn-who__chip",
							"data-testid": "connector-recent-chip",
							"data-id": r.id,
							"aria-label": s("who.addPerson", { name: r.name || r.id }),
							onClick: () => add(r.id),
							children: [/* @__PURE__ */ jsx(Icon, { name: "plus" }), /* @__PURE__ */ jsx("span", { children: r.name ? `${r.name} · ${r.id}` : r.id })]
						}) }, r.id))
					})]
				})]
			})
		]
	});
}
var init_WhoFields = __esmMin((() => {
	init_react();
	init_Icon();
	init_controls();
	init_connector();
	init_people();
	init_Person();
	init_pairing();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/AccessMatrix.jsx
function viaText(d, s) {
	if (!d?.allowed || !d.via) return "";
	if (d.via.startsWith("role:")) return s("can.via.role", { role: d.via.slice(5) });
	if ([
		"paired",
		"allowlist",
		"channel"
	].includes(d.via)) return s(`can.via.${d.via}`);
	if (d.via === "agent-connection") return s("can.via.agentConnection");
	return "";
}
function Word({ state, s }) {
	return /* @__PURE__ */ jsxs("span", {
		className: "cn-mx__word",
		children: [/* @__PURE__ */ jsx(Icon, { name: ICON[state] || "minus" }), /* @__PURE__ */ jsx("span", { children: s(`matrix.state.${state}`) })]
	});
}
function Cell({ row, col, cell, s, picked, onPick, children, describedBy, active }) {
	const { state, decision } = cell;
	const id = `connector-matrix-cell-${row.key}-${col.id}`;
	return /* @__PURE__ */ jsxs("td", {
		className: `cn-mx__cell cn-mx__cell--${state}`,
		"data-col": col.id,
		"data-state": state,
		"data-active": active ? "true" : void 0,
		children: [children, decision ? /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "cn-mx__btn",
			"data-testid": id,
			"data-state": state,
			"aria-pressed": picked,
			"aria-describedby": describedBy,
			onClick: onPick,
			children: /* @__PURE__ */ jsx(Word, {
				state,
				s
			})
		}) : /* @__PURE__ */ jsx("span", {
			className: "cn-mx__static",
			"data-testid": id,
			"data-state": state,
			children: /* @__PURE__ */ jsx(Word, {
				state,
				s
			})
		})]
	});
}
function usePhone() {
	const [phone, setPhone] = useState$1(() => typeof window !== "undefined" && window.matchMedia ? window.matchMedia(PHONE).matches : false);
	useEffect$1(() => {
		if (typeof window === "undefined" || !window.matchMedia) return void 0;
		const q = window.matchMedia(PHONE);
		const on = () => setPhone(q.matches);
		on();
		q.addEventListener?.("change", on);
		return () => q.removeEventListener?.("change", on);
	}, []);
	return phone;
}
function AccessMatrix({ form, setForm, kindInfo, capabilities, preview, dirty, s, ctx, agent, paired = [], onReset }) {
	const view = preview.view;
	const phone = usePhone();
	const columns = matrixColumns(form, view, kindInfo?.roles);
	const rows = matrixRows(view, matrixCaps(capabilities), form, columns);
	const [picked, setPicked] = useState$1(null);
	const [open, setOpen] = useState$1(() => /* @__PURE__ */ new Set());
	const kinds = columns.filter((c) => c.id !== "on");
	const [mobile, setMobile] = useState$1("");
	const shown = kinds.some((c) => c.id === mobile) ? mobile : kinds[0]?.id || "";
	const loading = preview.status === "loading";
	const held = agentHeld(agent);
	const grantable = grantableFor(kindInfo, form.caps);
	const grantableKind = (cap) => (kindInfo?.permissions || []).some((p) => p.name === cap && !p.sensitive);
	const colLabel = (c) => c.role ? s("can.sender.role", { title: c.title }) : s(`matrix.col.${c.id}`);
	const rowTitle = (r) => r.parent ? s("matrix.toolRow", {
		addon: r.addon,
		tool: r.tool
	}) : r.cap === "tools.write" ? s("matrix.row.tools") : sentenceCase(r.title);
	const capOf = (name) => capabilities.find((c) => c.name === name);
	const selRow = picked && rows.find((r) => r.key === picked.row);
	const d = (selRow?.cells[picked.col])?.decision;
	const toggle = (key) => setOpen((o) => {
		const n = new Set(o);
		if (n.has(key)) n.delete(key);
		else n.add(key);
		return n;
	});
	const verifiedCol = columns.find((c) => c.id === "paired");
	const nobodyVerified = Boolean(verifiedCol) && !hasPairing(paired);
	return /* @__PURE__ */ jsxs("section", {
		className: "cn-mx",
		"data-testid": "connector-matrix",
		"aria-busy": loading ? "true" : void 0,
		"aria-labelledby": "cn-mx-title",
		children: [
			/* @__PURE__ */ jsx("h3", {
				id: "cn-mx-title",
				className: "cn-sub__title",
				children: s("matrix.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				"data-testid": "connector-matrix-note",
				children: s("matrix.note")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				"data-testid": "connector-rule",
				children: s("perm.rule")
			}),
			nobodyVerified && /* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				"data-testid": "connector-matrix-nobody-verified",
				children: s("matrix.nobodyVerified")
			}),
			/* @__PURE__ */ jsx("div", {
				className: "cn-mx__tools",
				children: /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "cn-link cn-link--text",
					"data-testid": "connector-usual",
					onClick: onReset,
					children: s("matrix.reset")
				})
			}),
			dirty && /* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				"data-testid": "connector-can-dirty",
				children: s(form.id ? "can.fromForm" : "can.fromFormNew")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "cn-muted cn-can__live",
				role: "status",
				"aria-live": "polite",
				"data-testid": "connector-can-status",
				children: loading ? s(view ? "can.stale" : "can.loading") : ""
			}),
			preview.status === "error" && /* @__PURE__ */ jsx(FixNotice, {
				severity: "error",
				title: s("can.errorTitle"),
				reason: preview.error,
				testId: "connector-can-error",
				fix: {
					label: s("can.retry"),
					onClick: preview.reload,
					testId: "connector-can-retry"
				}
			}),
			kinds.length > 0 && /* @__PURE__ */ jsxs("div", {
				className: "dk-field cn-mx__pick",
				children: [/* @__PURE__ */ jsx("label", {
					className: "dk-label",
					htmlFor: "cn-mx-sender",
					children: s("matrix.pick")
				}), /* @__PURE__ */ jsx(Select, {
					id: "cn-mx-sender",
					"data-testid": "connector-matrix-sender",
					value: shown,
					onChange: (e) => setMobile(e.target.value),
					children: kinds.map((c) => /* @__PURE__ */ jsx("option", {
						value: c.id,
						children: colLabel(c)
					}, c.id))
				})]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "cn-matrix__wrap",
				children: /* @__PURE__ */ jsxs("table", {
					className: "cn-matrix cn-mx__table",
					"aria-label": s("matrix.title"),
					"data-dim": loading ? "true" : void 0,
					children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsxs("tr", { children: [/* @__PURE__ */ jsx("th", {
						scope: "col",
						children: /* @__PURE__ */ jsx("span", {
							className: "cn-vh",
							children: s("matrix.capability")
						})
					}), columns.map((c) => /* @__PURE__ */ jsx("th", {
						scope: "col",
						id: `cn-mx-col-${c.id}`,
						"data-col": c.id,
						"data-active": c.id === shown ? "true" : void 0,
						children: colLabel(c)
					}, c.id))] }) }), /* @__PURE__ */ jsx("tbody", { children: rows.flatMap((r) => {
						const cap = r.parent ? null : capOf(r.cap);
						const on = (form.caps || []).includes(r.cap);
						const lacks = Boolean(cap) && Boolean(form.agent_id) && held !== null && !agentHas(held, r.cap);
						const expanded = open.has(r.key);
						const out = [/* @__PURE__ */ jsxs("tr", {
							className: r.parent ? "cn-mx__sub" : void 0,
							"data-testid": `connector-matrix-row-${r.key}`,
							children: [/* @__PURE__ */ jsxs("th", {
								scope: "row",
								children: [
									/* @__PURE__ */ jsx("span", {
										className: "cn-mx__title",
										id: `cn-mx-row-${r.key}`,
										children: rowTitle(r)
									}),
									cap?.sensitive && /* @__PURE__ */ jsx("span", {
										className: "cn-badge cn-badge--warn",
										"data-testid": `connector-cap-sensitive-${r.cap}`,
										children: s("perm.sensitive")
									}),
									cap && /* @__PURE__ */ jsx("button", {
										type: "button",
										className: "cn-hint__more cn-mx__more",
										"aria-expanded": expanded,
										"data-testid": `connector-matrix-more-${r.key}`,
										onClick: () => toggle(r.key),
										children: expanded ? s("matrix.less") : s("matrix.more")
									})
								]
							}), columns.map((c) => {
								const active = c.id === shown;
								if (c.id === "on") return /* @__PURE__ */ jsx("td", {
									className: "cn-mx__cell cn-mx__cell--on",
									"data-col": "on",
									"data-testid": cap ? `connector-cap-${r.cap}` : void 0,
									"data-lacks": lacks ? "true" : void 0,
									children: cap ? /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Switch, {
										checked: on,
										label: `${s("matrix.col.on")}: ${rowTitle(r)}`,
										testId: `connector-cap-switch-${r.cap}`,
										disabled: lacks && !on,
										describedBy: lacks ? `cn-lacks-${r.cap}` : void 0,
										onChange: (v) => setForm(setCap(form, r.cap, v))
									}), lacks && /* @__PURE__ */ jsx("span", {
										className: "cn-mx__why",
										id: `cn-lacks-${r.cap}`,
										"data-testid": `connector-cap-lacks-${r.cap}`,
										children: s("perm.agentLacks")
									})] }) : /* @__PURE__ */ jsx("span", {
										className: "cn-mx__static",
										"aria-hidden": "true"
									})
								}, c.id);
								const edit = c.role && cap && grantableKind(r.cap);
								return /* @__PURE__ */ jsx(Cell, {
									row: r,
									col: c,
									cell: r.cells[c.id],
									s,
									describedBy: `cn-mx-row-${r.key} cn-mx-col-${c.id}`,
									active,
									picked: picked?.row === r.key && picked?.col === c.id,
									onPick: () => setPicked(picked?.row === r.key && picked?.col === c.id ? null : {
										row: r.key,
										col: c.id
									}),
									children: edit && /* @__PURE__ */ jsx("input", {
										type: "checkbox",
										className: "dk-check cn-mx__grant",
										"data-testid": `connector-grant-${c.role}-${r.cap}`,
										"aria-label": s("perm.roleCap", {
											role: c.title,
											cap: rowTitle(r)
										}),
										disabled: !grantable.includes(r.cap),
										checked: roleHas(form, c.role, r.cap),
										onChange: (e) => setForm(setGrant(form, c.role, r.cap, e.target.checked, capabilities))
									})
								}, c.id);
							})]
						}, r.key)];
						if (cap && expanded) out.push(/* @__PURE__ */ jsx("tr", {
							className: "cn-mx__disclosure",
							"data-testid": `connector-matrix-disclosure-${r.key}`,
							children: /* @__PURE__ */ jsxs("td", {
								colSpan: phone ? Math.min(3, columns.length + 1) : columns.length + 1,
								children: [
									/* @__PURE__ */ jsxs(Hint, { children: [cap.description, cap.sensitive ? ` ${s("perm.sensitiveHelp")}` : ""] }),
									r.cap === "triggers.change" && form.approval && /* @__PURE__ */ jsx("p", {
										className: "cn-cap__effect",
										"data-testid": "connector-cap-effect-triggers.change",
										children: changeEffect(form.approval, s)
									}),
									r.cap === "triggers.propose" && form.approval && /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("p", {
										className: "cn-cap__effect",
										"data-testid": "connector-cap-effect-triggers.propose",
										children: approvalEffect(form.approval, s)
									}), /* @__PURE__ */ jsx(ApprovalOptions, {
										form,
										setForm,
										s,
										off: !on,
										held
									})] })
								]
							})
						}, `${r.key}:more`));
						return out;
					}) })]
				})
			}),
			/* @__PURE__ */ jsx("div", {
				className: "cn-mx__detail",
				"data-testid": "connector-matrix-detail",
				role: "region",
				"aria-live": "polite",
				"aria-label": s("matrix.detail.label"),
				children: !d ? /* @__PURE__ */ jsx("p", {
					className: "cn-muted",
					children: s("matrix.detail.none")
				}) : /* @__PURE__ */ jsxs("div", {
					"data-testid": `connector-can-${selRow.cap}`,
					"data-allowed": d.allowed ? "true" : "false",
					className: "cn-mx__detail-body",
					children: [
						/* @__PURE__ */ jsx("p", {
							className: "cn-mx__detail-title",
							children: s("matrix.detail.title", {
								capability: rowTitle(selRow),
								who: colLabel(columns.find((c) => c.id === picked.col))
							})
						}),
						d.allowed ? /* @__PURE__ */ jsx("p", {
							"data-testid": "connector-matrix-message",
							children: viaText(d, s) ? sentenceCase(viaText(d, s)) : s("can.allowed")
						}) : /* @__PURE__ */ jsx("p", {
							"data-testid": "connector-matrix-message",
							children: d.message || d.reason || s("can.noMessage")
						}),
						!d.allowed && remainingChecks(d.then_check).length > 0 && /* @__PURE__ */ jsx("p", {
							className: "cn-muted",
							children: s("can.then", { list: remainingChecks(d.then_check).map((x) => s(`can.then.${x}`)).join(", ") })
						}),
						!d.allowed && d.fix && /* @__PURE__ */ jsx("div", {
							className: "cn-can__fix",
							children: /* @__PURE__ */ jsx(FixButton, {
								fix: d.fix,
								ctx,
								s
							})
						})
					]
				})
			})
		]
	});
}
var ICON, PHONE;
var init_AccessMatrix = __esmMin((() => {
	init_react();
	init_Icon();
	init_controls();
	init_accessHooks();
	init_access();
	init_connector();
	init_matrix();
	init_ApprovalFields();
	init_jsx_runtime();
	ICON = {
		yes: "check-circle",
		asks: "help-circle",
		no: "close",
		waiting: "clock",
		off: "minus",
		unknown: "minus"
	};
	PHONE = "(max-width: 640px)";
}));

//#endregion
//#region addons/internal/connector-ui/src/LoopSwitches.jsx
/**
* @param {object} props
* @param {object} props.form          the form of the binding
* @param {Function} props.setForm
* @param {object[]} props.capabilities the host's list of capabilities
* @param {Function} props.s            the translation function with the defaults
*/
function LoopSwitches({ form, setForm, capabilities, s }) {
	const caps = loopCaps(capabilities);
	if (caps.length === 0) return null;
	return /* @__PURE__ */ jsxs("section", {
		className: "cn-sub cn-loops",
		"data-testid": "connector-loops",
		"aria-labelledby": "cn-loops-title",
		children: [
			/* @__PURE__ */ jsx("h4", {
				className: "cn-sub__title",
				id: "cn-loops-title",
				children: s("loops.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				children: s("loops.help")
			}),
			/* @__PURE__ */ jsx("ul", {
				className: "cn-loops__list",
				children: caps.map((c) => {
					const on = (form.caps || []).includes(c.name);
					const desc = `cn-loop-desc-${c.name.replace(".", "-")}`;
					return /* @__PURE__ */ jsxs("li", {
						className: "cn-loops__row",
						"data-testid": `connector-loop-${c.name}`,
						"data-on": on ? "true" : "false",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "cn-loops__words",
							children: [/* @__PURE__ */ jsxs("span", {
								className: "cn-loops__title",
								children: [c.title, c.sensitive && /* @__PURE__ */ jsx("span", {
									className: "cn-badge cn-badge--warn",
									"data-testid": `connector-loop-sensitive-${c.name}`,
									children: s("perm.sensitive")
								})]
							}), /* @__PURE__ */ jsx("p", {
								className: "dk-hint",
								id: desc,
								children: c.description
							})]
						}), /* @__PURE__ */ jsx(Switch, {
							checked: on,
							label: c.title,
							testId: `connector-loop-switch-${c.name}`,
							describedBy: desc,
							onChange: (v) => setForm(setCap(form, c.name, v))
						})]
					}, c.name);
				})
			})
		]
	});
}
var init_LoopSwitches = __esmMin((() => {
	init_controls();
	init_connector();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/PermissionFields.jsx
function Channels({ form, setForm, s, chatNames, onSwitchOn, listening = [], hearsAll = false }) {
	const list = form.channels || [];
	const problem = channelsProblem(list);
	const set = (i, patch) => setForm({
		...form,
		channels: list.map((c, j) => j === i ? {
			...c,
			...patch
		} : c)
	});
	const on = (form.caps || []).includes("talkback.channels");
	const offered = offeredPlaces(form, listening);
	const full = list.length >= 10;
	const addBlank = () => setForm({
		...form,
		channels: [...list, {
			id: "",
			label: "",
			approved: false
		}]
	});
	const pick = (v) => {
		if (v === OTHER$1) addBlank();
		else if (v) setForm(withPlace(form, v, chatNames?.get(v) || ""));
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "cn-sub",
		"data-testid": "connector-channels",
		children: [
			/* @__PURE__ */ jsx("h3", {
				className: "cn-sub__title",
				children: s("perm.channelsTitle")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "dk-hint",
				children: s("perm.channelsHelp", { max: 10 })
			}),
			!on ? /* @__PURE__ */ jsxs("p", {
				className: "cn-muted",
				children: [
					s("perm.channelsOff"),
					" ",
					/* @__PURE__ */ jsx("button", {
						type: "button",
						className: "cn-link cn-link--text",
						"data-testid": "connector-channels-switch",
						onClick: onSwitchOn,
						children: s("perm.channelsSwitch")
					})
				]
			}) : /* @__PURE__ */ jsxs(Fragment, { children: [
				/* @__PURE__ */ jsx("ul", {
					className: "cn-channels",
					"aria-label": s("perm.channelsTitle"),
					children: list.map((c, i) => /* @__PURE__ */ jsxs("li", {
						className: "cn-channel",
						id: c.id ? `cn-place-${c.id}` : void 0,
						"data-testid": "connector-channel",
						"data-id": c.id,
						"data-approved": c.approved ? "true" : "false",
						children: [
							/* @__PURE__ */ jsx("div", {
								className: "cn-channel__cell",
								"data-label": s("perm.channelLabel"),
								children: /* @__PURE__ */ jsx(TextInput, {
									maxLength: 60,
									value: c.label,
									"data-testid": "connector-channel-label",
									"aria-label": s("perm.channelLabel"),
									placeholder: chatNames?.get(c.id) || "",
									onChange: (e) => set(i, { label: e.target.value })
								})
							}),
							/* @__PURE__ */ jsx("div", {
								className: "cn-channel__cell",
								"data-label": s("perm.channelId"),
								children: /* @__PURE__ */ jsx(TextInput, {
									mono: true,
									maxLength: 64,
									value: c.id,
									"data-testid": "connector-channel-id",
									"aria-label": s("perm.channelId"),
									onChange: (e) => set(i, { id: e.target.value })
								})
							}),
							/* @__PURE__ */ jsx("div", {
								className: "cn-channel__cell cn-channel__cell--who",
								"data-label": s("perm.channelWho"),
								children: /* @__PURE__ */ jsxs(Select, {
									"data-testid": "connector-channel-approved",
									"aria-label": s("perm.channelWhoFor", { id: c.label || c.id || "" }),
									value: postValueOf(c),
									onChange: (e) => set(i, { approved: e.target.value === "any" }),
									children: [/* @__PURE__ */ jsx("option", {
										value: "any",
										children: s("perm.channelWho.any")
									}), /* @__PURE__ */ jsx("option", {
										value: POST_VERIFIED,
										children: s("perm.channelWho.verified")
									})]
								})
							}),
							/* @__PURE__ */ jsxs("button", {
								type: "button",
								className: "dk-btn dk-btn--secondary dk-btn--sm",
								"aria-label": s("perm.channelRemove", { id: c.label || c.id || "" }),
								onClick: () => setForm({
									...form,
									channels: list.filter((_, j) => j !== i)
								}),
								children: [
									/* @__PURE__ */ jsx(Icon, { name: "close" }),
									" ",
									s("perm.remove")
								]
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "cn-channel__notes",
								children: [/* @__PURE__ */ jsx("p", {
									className: "dk-hint",
									"data-testid": "connector-channel-hint",
									children: c.approved ? s("perm.channelHint.any") : s("perm.channelHint.verified")
								}), c.id && !hearsAll && !listening.includes(c.id) && /* @__PURE__ */ jsx("p", {
									className: "dk-hint",
									"data-testid": "connector-channel-nolisten",
									children: s("perm.channelNoListen")
								})]
							})
						]
					}, i))
				}),
				problem && /* @__PURE__ */ jsx("p", {
					className: "dk-field-error",
					role: "alert",
					"data-testid": "connector-channel-problem",
					children: s(`perm.channelProblem.${problem}`, { max: problem === "id" ? 64 : problem === "label" ? 60 : 10 })
				}),
				/* @__PURE__ */ jsx("div", { children: offered.length > 0 && !full ? /* @__PURE__ */ jsxs(Select, {
					"data-testid": "connector-channel-pick",
					"aria-label": s("perm.channelAdd"),
					value: "",
					onChange: (e) => pick(e.target.value),
					children: [
						/* @__PURE__ */ jsx("option", {
							value: "",
							children: s("perm.channelAdd")
						}),
						offered.map((id) => /* @__PURE__ */ jsx("option", {
							value: id,
							children: chatNames?.get(id) ? `${chatNames.get(id)} (${id})` : id
						}, id)),
						/* @__PURE__ */ jsx("option", {
							value: OTHER$1,
							children: s("perm.channelPickOther")
						})
					]
				}) : /* @__PURE__ */ jsxs("button", {
					type: "button",
					className: "dk-btn dk-btn--secondary",
					disabled: full,
					"data-testid": "connector-channel-add",
					onClick: addBlank,
					children: [
						/* @__PURE__ */ jsx(Icon, { name: "plus" }),
						" ",
						full ? s("perm.channelFull") : s("perm.channelAdd")
					]
				}) })
			] })
		]
	});
}
/**
* @param {object} props
* @param {object} props.form       the form of the binding
* @param {Function} props.setForm
* @param {Function} props.s        the translation function with the defaults
* @param {Map} [props.chatNames]   chat ID -> name, from the sender log
* @param {Function} props.onSwitchOn  takes the person to the switch of "Post to other channels"
* @param {string[]} [props.listening]  the IDs of the channels of the listening list (see listeningChannels)
* @param {boolean} [props.hearsAll]    the bot listens to everyone, or the list cannot tell channels from people:
*                                      no place is said to be outside the listening list
*/
function PermissionFields({ form, setForm, s, chatNames, onSwitchOn, listening = [], hearsAll = false }) {
	return /* @__PURE__ */ jsx("div", {
		className: "cn-places",
		"data-testid": "connector-permissions",
		children: /* @__PURE__ */ jsx(Channels, {
			form,
			setForm,
			s,
			chatNames,
			onSwitchOn,
			listening,
			hearsAll
		})
	});
}
var POST_ANY, POST_VERIFIED, postValueOf, OTHER$1;
var init_PermissionFields = __esmMin((() => {
	init_controls();
	init_Icon();
	init_connector();
	init_jsx_runtime();
	POST_ANY = "any";
	POST_VERIFIED = "verified";
	postValueOf = (c) => c.approved ? "any" : POST_VERIFIED;
	OTHER$1 = "__other__";
}));

//#endregion
//#region addons/internal/connector-ui/src/NotifyField.jsx
/**
* @param {object} props
* @param {object} props.form
* @param {Function} props.setForm
* @param {{people: Array, channels: Array}} props.known  from knownTargets
* @param {string} props.label
* @param {string} props.hint
* @param {string} props.inputMode  the input mode of the raw ID
* @param {Function} props.s        the shared words
*/
function NotifyField({ form, setForm, known, label, hint, inputMode = "text", s }) {
	const value = form.notify_chat || "";
	const ids = new Set([...known.people, ...known.channels].map((x) => x.id));
	const unknown = value !== "" && !ids.has(value);
	const [typing, setTyping] = useState$1(false);
	const choice = typing ? OTHER : value;
	return /* @__PURE__ */ jsx(Field, {
		label,
		hint,
		optional: true,
		children: (p) => /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs(Select, {
			...p,
			"data-testid": "connector-notify",
			value: choice,
			onChange: (e) => {
				if (e.target.value === OTHER) {
					setTyping(true);
					return;
				}
				setTyping(false);
				setForm({
					...form,
					notify_chat: e.target.value
				});
			},
			children: [
				/* @__PURE__ */ jsx("option", {
					value: "",
					children: s("notify.none")
				}),
				known.people.length > 0 && /* @__PURE__ */ jsx("optgroup", {
					label: s("notify.people"),
					children: known.people.map((x) => /* @__PURE__ */ jsx("option", {
						value: x.id,
						children: labelOf(x)
					}, x.id))
				}),
				known.channels.length > 0 && /* @__PURE__ */ jsx("optgroup", {
					label: s("notify.channels"),
					children: known.channels.map((x) => /* @__PURE__ */ jsx("option", {
						value: x.id,
						children: labelOf(x)
					}, x.id))
				}),
				unknown && !typing && /* @__PURE__ */ jsx("option", {
					value,
					children: s("notify.saved", { id: value })
				}),
				/* @__PURE__ */ jsx("option", {
					value: OTHER,
					children: s("notify.other")
				})
			]
		}), typing && /* @__PURE__ */ jsx(TextInput, {
			mono: true,
			inputMode,
			"data-testid": "connector-notify-other",
			"aria-label": s("notify.otherLabel"),
			value,
			onChange: (e) => setForm({
				...form,
				notify_chat: e.target.value
			})
		})] })
	});
}
var OTHER, labelOf;
var init_NotifyField = __esmMin((() => {
	init_react();
	init_controls();
	init_jsx_runtime();
	OTHER = "\0other";
	labelOf = (x) => x.name ? `${x.name} · ${x.id}` : x.id;
}));

//#endregion
//#region addons/internal/connector-ui/src/connection.js
function attentionOf(c, check, { credentialsOnly = false } = {}) {
	if (!c) return null;
	if (c.active === false) return {
		cause: "inactive",
		reason: c.reason || ""
	};
	if (c.has_token === false && !credentialsOnly) return {
		cause: "noToken",
		reason: ""
	};
	const other = c.enabled !== false ? duplicateOther(c) : null;
	if (other) return {
		cause: "duplicate",
		reason: other.name || ""
	};
	if (check && check.ok === false) return looksLikeTokenFailure(check.reason) ? {
		cause: "tokenRejected",
		reason: check.reason || ""
	} : {
		cause: "testFailed",
		reason: check.reason || ""
	};
	return null;
}
function connectionState(c, check, { messaging = true } = {}) {
	const attention = attentionOf(c, check, { credentialsOnly: !messaging || Boolean(c?.credentials_only) });
	if (attention?.cause === "inactive") return {
		state: "attention",
		attention
	};
	if (messaging && !c.credentials_only && c.enabled === false) return {
		state: "off",
		attention: null
	};
	if (attention) return {
		state: "attention",
		attention
	};
	return {
		state: messaging && !c.credentials_only ? "running" : "ready",
		attention: null
	};
}
function fixOf(attention) {
	if (!attention) return null;
	if (attention.cause === "noToken" || attention.cause === "tokenRejected") return "token";
	if (attention.cause === "duplicate") return "duplicate";
	return null;
}
function storage() {
	try {
		return typeof window !== "undefined" ? window.localStorage : null;
	} catch {
		return null;
	}
}
function readChecks(store = storage()) {
	try {
		const raw = store?.getItem(CHECKS_KEY);
		const data = raw ? JSON.parse(raw) : {};
		if (!data || typeof data !== "object" || Array.isArray(data)) return {};
		return Object.fromEntries(Object.entries(data).filter(([, v]) => v && typeof v === "object" && typeof v.ok === "boolean"));
	} catch {
		return {};
	}
}
function writeChecks(checks, store = storage()) {
	try {
		const entries = Object.entries(checks).sort((a, b) => (b[1].at || 0) - (a[1].at || 0)).slice(0, MAX_CHECKS);
		store?.setItem(CHECKS_KEY, JSON.stringify(Object.fromEntries(entries)));
	} catch {}
}
function checkRecord({ ok, text = "", reason = "" }, now = Date.now()) {
	return ok ? {
		ok: true,
		text,
		at: now
	} : {
		ok: false,
		reason,
		at: now
	};
}
function dropCheck(checks, id) {
	const { [id]: _gone, ...rest } = checks;
	return rest;
}
function presetOf(form, capabilities, agent) {
	const loop = new Set(loopCaps(capabilities).map((c) => c.name));
	const caps = (form?.caps || []).filter((x) => !loop.has(x));
	if (caps.length === 0 && (form?.grants || []).length === 0) return "answer";
	const usual = usualFor(capabilities, agentHeld(agent)).caps.filter((x) => !loop.has(x));
	return sameSet(caps, usual) && (form?.grants || []).every((g) => g.caps.every((x) => usual.includes(x))) ? "standard" : "custom";
}
function applyPreset(form, preset, capabilities, agent) {
	if (preset === "answer") return {
		...form,
		caps: [],
		grants: []
	};
	if (preset === "standard") return withUsualCaps(form, capabilities, agentHeld(agent));
	return form;
}
function standardTitles(capabilities, agent) {
	const caps = usualFor(capabilities, agentHeld(agent)).caps;
	return matrixCaps(capabilities).filter((c) => caps.includes(c.name)).map((c) => c.title);
}
var TOKEN_REASON, looksLikeTokenFailure, CHECKS_KEY, MAX_CHECKS, sameSet;
var init_connection = __esmMin((() => {
	init_connector();
	TOKEN_REASON = /token|unauthori[sz]ed|not authori[sz]ed|forbidden|credential|api key|\b40[13]\b|invalid_auth|refused|rejected/i;
	looksLikeTokenFailure = (reason) => TOKEN_REASON.test(String(reason || ""));
	CHECKS_KEY = "localai.connector-checks.v1";
	MAX_CHECKS = 200;
	sameSet = (a, b) => a.length === b.length && a.every((x) => b.includes(x));
}));

//#endregion
//#region addons/internal/connector-ui/src/ConnectionSheet.jsx
function Section({ id, title, children }) {
	return /* @__PURE__ */ jsxs("section", {
		className: "cn-sheet__section",
		"aria-labelledby": id,
		"data-testid": `connector-section-${id.replace("cn-sec-", "")}`,
		children: [/* @__PURE__ */ jsx("h3", {
			className: "cn-sheet__label",
			id,
			children: title
		}), children]
	});
}
function Permissions({ p }) {
	const { form, setForm, capabilities, agent, preset, setPreset, s } = p;
	const titles = standardTitles(capabilities, agent);
	const options = [
		{
			value: "answer",
			label: s("conn.preset.answer"),
			description: s("conn.preset.answerHelp")
		},
		{
			value: "standard",
			label: s("conn.preset.standard"),
			description: titles.length ? s("conn.preset.standardHelp", { list: titles.join(", ") }) : s("conn.preset.standardNone")
		},
		{
			value: "custom",
			label: s("conn.preset.custom"),
			description: s("conn.preset.customHelp")
		}
	];
	const choose = (value) => {
		setPreset(value);
		if (value !== "custom") setForm(applyPreset(form, value, capabilities, agent));
	};
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(RadioCards, {
			name: "cn-preset",
			legend: s("conn.preset.label"),
			value: preset,
			options,
			onChange: choose,
			testId: "connector-preset",
			columns: 3
		}),
		/* @__PURE__ */ jsx("p", {
			className: "dk-hint",
			"data-testid": "connector-preset-note",
			children: s("conn.preset.note")
		}),
		preset === "custom" && /* @__PURE__ */ jsx(AccessMatrix, {
			form,
			setForm: (f) => {
				setPreset("custom");
				setForm(f);
			},
			kindInfo: p.kindInfo,
			capabilities,
			preview: p.preview,
			dirty: p.dirty,
			s,
			ctx: p.fixCtx,
			agent,
			paired: p.pairedList || form.paired || [],
			onReset: () => {
				setPreset("custom");
				setForm(applyPreset(form, "standard", capabilities, agent));
			}
		}),
		/* @__PURE__ */ jsx(LoopSwitches, {
			form,
			setForm,
			capabilities,
			s
		})
	] });
}
function ConnectionSheet({ p }) {
	const { t, s, form, setForm, messaging, capabilities, kindInfo, agents, agentOptional, toolOnly, TokenFields, ExtraFields, savedItem, busy, error, fixedAgent } = p;
	const editing = Boolean(form.id);
	const agent = agents.find((a) => a.id === form.agent_id);
	const bodyRef = useRef(null);
	const failRef = useRef(null);
	const [moreOpen, setMoreOpen] = useState$1(false);
	const [checkOpen, setCheckOpen] = useState$1(Boolean(p.openCheck));
	useEffect$1(() => {
		const id = requestAnimationFrame(() => {
			const form = bodyRef.current;
			((p.focusToken ? form?.querySelector("input[type=\"password\"]") : null) || form?.querySelector("input:not([type=\"radio\"]):not([type=\"checkbox\"])"))?.focus();
		});
		return () => cancelAnimationFrame(id);
	}, [p.focusToken]);
	useEffect$1(() => {
		if (!p.scrollToPermissions) return;
		const id = setTimeout(() => document.querySelector("[data-testid=\"connector-section-may\"]")?.scrollIntoView?.({ block: "start" }), 80);
		return () => clearTimeout(id);
	}, [p.scrollToPermissions]);
	useEffect$1(() => {
		if (p.testFail) failRef.current?.focus();
	}, [p.testFail]);
	const submitDisabled = busy || !p.canSubmit;
	const footer = /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("button", {
		type: "button",
		className: "dk-btn dk-btn--ghost",
		"data-testid": "connector-cancel",
		onClick: p.onClose,
		children: t("cancel")
	}), /* @__PURE__ */ jsx("button", {
		type: "submit",
		form: "cn-sheet-form",
		className: "dk-btn dk-btn--primary",
		"data-testid": "connector-save",
		"aria-busy": busy ? "true" : void 0,
		disabled: submitDisabled,
		children: busy ? p.testStep ? s("conn.pane.testing") : s("conn.sheet.saving") : s("conn.sheet.saveAndTest")
	})] });
	return /* @__PURE__ */ jsx(SideSheet_default, {
		wide: true,
		title: editing ? t("edit") : t("new"),
		description: editing ? s("conn.sheet.editDesc") : s("conn.sheet.addDesc"),
		onClose: p.onClose,
		closeLabel: s("conn.sheet.close"),
		testId: "connector-sheet",
		labelId: "connector-sheet-title",
		footer,
		children: /* @__PURE__ */ jsx(AddonScope, { children: /* @__PURE__ */ jsxs("form", {
			id: "cn-sheet-form",
			ref: bodyRef,
			className: "cn-sheet",
			onSubmit: p.onSubmit,
			"aria-label": editing ? t("edit") : t("new"),
			"data-testid": "connector-form",
			children: [
				error && /* @__PURE__ */ jsx(Notice, {
					tone: "error",
					role: "alert",
					testId: "connector-sheet-error",
					children: error
				}),
				!toolOnly && savedItem?.agent_id && /* @__PURE__ */ jsx("p", {
					className: "cn-muted cn-agentlink",
					children: /* @__PURE__ */ jsx("a", {
						href: p.agentHref,
						target: p.dirty ? "_blank" : void 0,
						rel: p.dirty ? "noopener noreferrer" : void 0,
						"data-testid": "connector-agent-link",
						children: s("agentLink", { name: p.agentName(savedItem.agent_id) })
					})
				}),
				p.sameBot,
				/* @__PURE__ */ jsxs(Section, {
					id: "cn-sec-connection",
					title: s("conn.sheet.connection"),
					children: [
						messaging && capabilities.length > 0 && /* @__PURE__ */ jsx(ReadinessList, {
							s,
							ctx: p.fixCtx,
							rowsInput: p.readyInput,
							isNew: !editing
						}),
						/* @__PURE__ */ jsx(Field, {
							label: t("name"),
							children: (f) => /* @__PURE__ */ jsx(TextInput, {
								...f,
								value: form.name,
								required: true,
								maxLength: 80,
								onChange: (e) => setForm({
									...form,
									name: e.target.value
								})
							})
						}),
						/* @__PURE__ */ jsx(TokenFields, {
							form,
							setForm,
							t
						}),
						toolOnly ? null : fixedAgent ? /* @__PURE__ */ jsxs("div", {
							className: "dk-field",
							"data-testid": "connector-agent-fixed",
							children: [/* @__PURE__ */ jsx("span", {
								className: "dk-label",
								children: t("agent")
							}), /* @__PURE__ */ jsx("p", {
								className: "cn-fixed",
								children: s("conn.sheet.agentFixed", { name: p.agentName(form.agent_id) })
							})]
						}) : /* @__PURE__ */ jsx(Field, {
							label: t("agent"),
							hint: agentOptional ? s("agentOptionalHint") : void 0,
							optional: agentOptional,
							children: (f) => /* @__PURE__ */ jsxs(Select, {
								...f,
								"data-testid": "connector-agent",
								"aria-label": t("agent"),
								value: form.agent_id,
								required: !agentOptional,
								onChange: (e) => setForm(p.withAgent(form, e.target.value)),
								children: [/* @__PURE__ */ jsx("option", {
									value: "",
									children: agentOptional ? s("agentCredentialsOnly") : t("agentNone")
								}), agents.map((a) => /* @__PURE__ */ jsx("option", {
									value: a.id,
									disabled: !a.model,
									children: a.model ? a.name : t("agentNoModel", { name: a.name })
								}, a.id))]
							})
						}),
						ExtraFields && /* @__PURE__ */ jsx(ExtraFields, {
							form,
							setForm,
							t
						})
					]
				}),
				messaging && /* @__PURE__ */ jsx(Section, {
					id: "cn-sec-who",
					title: s("conn.sheet.who"),
					children: /* @__PURE__ */ jsx(WhoFields, {
						form,
						setForm,
						t,
						s,
						confirmed: p.confirmed,
						setConfirmed: p.setConfirmed,
						isChannel: p.isChannelEntry,
						mixed: p.mixedList,
						onPaired: p.pairedChanged,
						recent: recentPeople(p.senderLog, form.allow),
						chatNames: chatNamesFrom(p.senderLog),
						hint: p.lists[0]?.hint ? t(p.lists[0].hint) : void 0,
						help: p.lists[0]?.help ? t(p.lists[0].help) : void 0
					}, form.id || "new")
				}),
				messaging && /* @__PURE__ */ jsxs(Section, {
					id: "cn-sec-may",
					title: s("conn.sheet.may"),
					children: [
						capabilities.length > 0 && /* @__PURE__ */ jsx(Permissions, { p: {
							...p,
							agent,
							s
						} }),
						capabilities.length === 0 && /* @__PURE__ */ jsx(ApprovalOptions, {
							form,
							setForm,
							s
						}),
						/* @__PURE__ */ jsxs("details", {
							className: "cn-more",
							"data-testid": "connector-replies-more",
							open: moreOpen,
							onToggle: (e) => setMoreOpen(e.currentTarget.open),
							children: [/* @__PURE__ */ jsx("summary", { children: s("conn.sheet.replies") }), /* @__PURE__ */ jsx("div", {
								className: "cn-more__body",
								children: /* @__PURE__ */ jsx(AnswerFields, {
									form,
									setForm,
									t,
									kindInfo,
									places: capabilities.length > 0 && /* @__PURE__ */ jsx(PermissionFields, {
										form,
										setForm,
										s,
										chatNames: chatNamesFrom(p.senderLog),
										listening: listeningChannels(form, p.isChannelEntry, p.mixedList),
										hearsAll: Boolean(form.accept_any) || p.mixedList,
										onSwitchOn: () => {
											p.setPreset("custom");
											setTimeout(() => jumpTo(["[data-testid=\"connector-cap-switch-talkback.channels\"]", "[data-testid=\"connector-matrix\"]"]), 60);
										}
									}),
									notify: /* @__PURE__ */ jsx(NotifyField, {
										form,
										setForm,
										s,
										label: s("notify.label"),
										hint: t("notifyHelp"),
										inputMode: p.notifyMode,
										known: knownTargets({
											form,
											senders: p.senderLog,
											isChannel: p.isChannelEntry
										})
									}),
									sizes: /* @__PURE__ */ jsx(FilesFields, {
										form,
										setForm,
										kind: p.kindFiles,
										saved: form.files,
										s
									})
								}, form.id || "new")
							})]
						}),
						capabilities.length > 0 && /* @__PURE__ */ jsxs("details", {
							className: "cn-more",
							"data-testid": "connector-check-more",
							open: checkOpen,
							onToggle: (e) => setCheckOpen(e.currentTarget.open),
							children: [/* @__PURE__ */ jsx("summary", { children: s("conn.sheet.check") }), /* @__PURE__ */ jsx("div", {
								className: "cn-more__body",
								children: /* @__PURE__ */ jsx(AccessView, {
									binding: form,
									capabilities,
									s,
									version: p.accessVersion,
									setForm,
									preview: p.preview,
									kindInfo,
									ctx: p.fixCtx,
									paired: p.pairedList || form.paired || [],
									isChannel: p.isChannelEntry,
									mixed: p.mixedList,
									chatNames: chatNamesFrom(p.senderLog),
									senders: p.senderLog,
									onAllowed: p.onAllowed
								})
							})]
						})
					]
				}),
				p.dupAsk,
				p.testFail && /* @__PURE__ */ jsx("div", {
					className: "cn-sheet__fail",
					ref: failRef,
					tabIndex: -1,
					"data-testid": "connector-test-failed",
					children: /* @__PURE__ */ jsxs(Notice, {
						tone: "error",
						role: "alert",
						children: [
							/* @__PURE__ */ jsx("strong", {
								className: "ui-callout__title",
								children: s("conn.sheet.testFailed")
							}),
							/* @__PURE__ */ jsx("span", {
								className: "cn-sheet__fail-reason",
								children: p.testFail.reason || s("conn.sheet.testFailedNoReason")
							}),
							/* @__PURE__ */ jsx("span", {
								className: "cn-row__actions",
								children: /* @__PURE__ */ jsx("button", {
									type: "button",
									className: "dk-btn dk-btn--secondary dk-btn--sm",
									"data-testid": "connector-test-again",
									disabled: busy,
									"aria-busy": busy ? "true" : void 0,
									onClick: p.onTestAgain,
									children: busy ? s("conn.pane.testing") : s("conn.sheet.testAgain")
								})
							})
						]
					})
				}),
				/* @__PURE__ */ jsx("span", {
					className: "cn-vh",
					role: "status",
					children: busy && p.testStep ? s("conn.pane.testing") : ""
				})
			]
		}) })
	});
}
var init_ConnectionSheet = __esmMin((() => {
	init_react();
	init_SideSheet();
	init_ConnectionPane();
	init_AnswerFields();
	init_AccessView();
	init_ReadinessList();
	init_ApprovalFields();
	init_FilesFields();
	init_WhoFields();
	init_AccessMatrix();
	init_LoopSwitches();
	init_PermissionFields();
	init_NotifyField();
	init_controls();
	init_accessHooks();
	init_connection();
	init_people();
	init_connector();
	init_jsx_runtime();
}));

//#endregion
//#region addons/internal/connector-ui/src/share.js
function shareAvailable(sdk, listing) {
	return Boolean(listing && listing.sharing === true && sdk && sdk.ui && typeof sdk.ui.ConnectionShareDialog === "function");
}
function sharedOfKind(listing, kind) {
	return (Array.isArray(listing?.shared) ? listing.shared : []).filter((c) => c && typeof c.id === "string" && c.kind === kind);
}
var init_share = __esmMin((() => {}));

//#endregion
//#region addons/internal/connector-ui/src/login.js
function loginPlan({ login, canAdd, sdk, kindInfo, kindsReady }) {
	const sheetAdd = Boolean(canAdd) && !login;
	if (!login || !canAdd) return {
		show: "none",
		sheetAdd
	};
	if (typeof sdk?.ui?.ConnectionLogin !== "function") return {
		show: kindsReady ? "oldHost" : "waiting",
		sheetAdd
	};
	return {
		show: kindInfo ? "host" : "waiting",
		sheetAdd
	};
}
var init_login = __esmMin((() => {}));

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.it.json
var connector_it_default = {
	"answer.title": "Dove scrive e come risponde",
	"answer.replyLabel": "Mentre l'agente lavora",
	"answer.reply.off": "Sta scrivendo, poi la risposta",
	"answer.reply.progress": "Avanzamento: gli strumenti che usa",
	"answer.reply.stream": "In diretta: la risposta mentre viene scritta",
	"answer.reply.reasoning": "Ragionamento: il ragionamento del modello, poi la risposta",
	"answer.replyHelp": "Avanzamento e In diretta mostrano un solo messaggio di lavoro, che la risposta poi sostituisce. Su una piattaforma con le bozze, In diretta mostra a una chat privata una bozza, seguita dalla risposta. Una risposta lunga continua in nuovi messaggi.",
	"answer.replyReasoningHelp": "Ragionamento mostra il ragionamento del modello, mentre lo scrive, a ogni mittente di questo collegamento. Usalo solo dove va bene.",
	"answer.conversationLabel": "Conversazioni",
	"answer.conversationHelp": "Invia /new (o !new) nell'app per iniziare una nuova chat.",
	"answer.conversation.sender": "Una chat per persona",
	"answer.conversation.chat": "Una chat per gruppo o canale",
	"answer.conversation.window": "Per persona, nuova dopo una pausa",
	"answer.conversation.thread": "Nuova chat per messaggio; le risposte proseguono",
	"answer.window": "Pausa, in minuti",
	"answer.windowRange": "Usa un numero intero da 1 a {{max}}.",
	"answer.languageLabel": "Lingua di risposta",
	"answer.languageHelp": "Le note che il bot scrive da solo, come conferme e rifiuti. Le risposte del modello seguono la lingua della conversazione.",
	"answer.language.auto": "Automatica (la lingua della tua interfaccia, altrimenti quella di chi scrive)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Invia i file creati dall'agente",
	add: "Aggiungi",
	more: "Altro",
	less: "Meno",
	"answer.filesHelp": "Dopo la risposta, fino a 5 file. Programmi e script non vengono inviati. Il limite di dimensione è in Dimensione dei file e lingua delle risposte.",
	"answer.summary": "Risponde: {{reply}} · {{conversation}}",
	"answer.short.off": "sta scrivendo",
	"answer.short.progress": "avanzamento",
	"answer.short.stream": "risposta in diretta",
	"answer.short.reasoning": "ragionamento in diretta",
	"answer.short.sender": "una chat per persona",
	"answer.short.chat": "una chat per gruppo",
	"answer.short.window": "nuova chat dopo {{count}} min",
	"answer.short.thread": "una chat per messaggio",
	"approval.title": "Timer e trigger dalla chat",
	"approval.help": "Quando l'agente imposta qualcosa che parte più tardi («tra 10 minuti», «ogni giorno»), ogni esecuzione è un'esecuzione del modello.",
	"approval.mode.ask": "Chiede prima: il bot lo propone nella chat e la persona risponde sì o no",
	"approval.mode.auto": "Parte subito: viene impostato e alla persona viene spiegato come annullarlo",
	"approval.mode.auto_readonly": "Parte subito se le esecuzioni si limitano a leggere e riferire; altrimenti chiede prima",
	"approval.limitsHelp": "Questi limiti definiscono cosa viene impostato senza chiedere. Lascia vuoto un campo per usare il valore predefinito. Oltre un limite si chiede sempre.",
	"approval.max_pending": "Numero massimo di timer e trigger contemporanei",
	"approval.min_gap_minutes": "Minuti minimi tra le esecuzioni di un trigger ricorrente",
	"approval.max_runs_per_day": "Numero massimo di esecuzioni al giorno, in totale",
	"approval.max_lifetime_days": "Durata massima, in giorni",
	"approval.invalid": "Usa un numero intero da 1 a {{max}}, oppure lascia vuoto.",
	"approval.default": "Predefinito: {{value}}.",
	"approval.summary": "Trigger: {{mode}}",
	"approval.effect": "Proposte: {{mode}}",
	"approval.effectChange": "Modifiche ed eliminazioni: {{mode}}",
	"approval.limits": "Limiti",
	"approval.acts.title": "Le esecuzioni possono agire",
	"approval.acts.help": "Disattivato: le esecuzioni di un trigger creato da questa chat si limitano a leggere e riferire. Attivato: possono fare anche ciò che spunti qui sotto, e solo ciò che l'agente ha.",
	"approval.acts.modes": "Chiede prima: decidi sempre tu. Parte subito: solo se sei una persona verificata e ogni azione è spuntata qui.",
	"approval.acts.act.files": "Scrivere file nelle cartelle dell'agente",
	"approval.acts.act.files.effect": "Un'esecuzione può creare e modificare i file che l'agente conserva.",
	"approval.acts.act.addons": "Usare le azioni dei componenti aggiuntivi dell'agente",
	"approval.acts.act.addons.effect": "Un'esecuzione può usare ciò che fanno i componenti aggiuntivi dell'agente, comandi compresi.",
	"approval.acts.act.send": "Inviare messaggi oltre al punto in cui riferisce",
	"approval.acts.act.send.effect": "Un'esecuzione può scrivere da sola ad altre chat e canali.",
	"approval.acts.act.spend": "Usare strumenti a pagamento o esterni e la rete",
	"approval.acts.act.spend.effect": "Un'esecuzione può chiamare servizi esterni a LocalAI, che possono costare denaro.",
	"approval.acts.lacks": "L'agente non ha questo permesso.",
	"approval.acts.sensitive": "Sensibile",
	"approval.effectActs": ", le esecuzioni possono: {{acts}}",
	"approval.actShort.act.files": "scrivere file",
	"approval.actShort.act.addons": "usare i componenti aggiuntivi",
	"approval.actShort.act.send": "inviare messaggi",
	"approval.actShort.act.spend": "usare strumenti a pagamento o esterni",
	"approval.short.ask": "chiede prima",
	"approval.short.auto": "parte subito",
	"approval.short.auto_readonly": "parte subito se in sola lettura",
	"files.title": "File",
	"files.help": "Lascia vuoto un campo per usare il limite del componente aggiuntivo. Il tuo limite può solo essere più basso.",
	"files.receiveLabel": "File più grande che legge, in MiB",
	"files.sendLabel": "File più grande che invia, in MiB",
	"files.invalid": "Usa un numero maggiore di 0.",
	"files.tooHigh": "Il componente aggiuntivo consente al massimo {{max}} qui.",
	"files.now": "Ora: {{limit}} ({{layer}}).",
	"files.receiveHelp": "I file che le persone inviano al bot. Un file più grande viene rifiutato e il bot dice quale limite ha raggiunto.",
	"files.sendHelp": "I file che l'agente crea e il bot rimanda indietro. Un file più grande non viene inviato e il bot dice quale limite ha raggiunto.",
	"files.addon.off": "Questo componente aggiuntivo non sposta file in questa direzione, quindi non c'è nulla da impostare.",
	"files.addon.declared": "Il componente aggiuntivo dichiara fino a {{max}}.",
	"files.addon.open": "Il componente aggiuntivo non dichiara alcun limite, quindi vale quello della piattaforma.",
	"files.host": "Nessun bot può spostare un file più grande di {{max}}. Lo imposta un amministratore nelle impostazioni.",
	"files.layer.owner": "limite impostato per questo bot",
	"files.layer.addon": "limite del componente aggiuntivo",
	"files.layer.host": "limite della piattaforma",
	"perm.agentLacks": "L'agente non ha questo permesso.",
	"perm.rule": "Le persone in elenco possono usare i permessi spuntati. Quelli sensibili richiedono anche una persona verificata.",
	"perm.sensitive": "Solo persone verificate",
	"perm.sensitiveHelp": "Sensibile. Non viene mai dato a un ruolo. Può usarlo solo una persona verificata, e ogni uso viene registrato.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Dove può pubblicare",
	"perm.channelsHelp": "Luoghi in cui l'agente può pubblicare quando una persona in elenco lo chiede, oltre alla chat in cui risponde. Non decide chi il bot ascolta: vedi Canali in cui il bot ascolta. Al massimo {{max}}.",
	"perm.channelsOff": "Attiva «Pubblica negli altri canali» qui sopra per scegliere i luoghi in cui può pubblicare.",
	"perm.channelId": "ID del canale",
	"perm.channelLabel": "Nome",
	"perm.channelAdd": "Aggiungi un luogo",
	"perm.channelRemove": "Rimuovi il luogo {{id}}",
	"perm.remove": "Rimuovi",
	"perm.channelFull": "L'elenco è pieno.",
	"perm.channelProblem.id": "Ogni luogo richiede un ID da 1 a {{max}} byte, senza spazi.",
	"perm.channelProblem.label": "Un nome ha al massimo {{max}} caratteri.",
	"perm.channelProblem.repeat": "Un luogo è presente due volte.",
	"perm.channelProblem.count": "Al massimo {{max}} luoghi.",
	"perm.triggersNeed": "Attiva Proponi trigger per usarlo.",
	"pair.start": "Verifica una persona",
	"pair.startHelp": "Crea un codice. Invialo al bot come messaggio diretto dall'account da verificare, entro dieci minuti. Il codice vale una sola volta.",
	"pair.needSave": "Salva prima questo bot, poi verifica una persona.",
	"pair.codeTitle": "Il tuo codice di verifica",
	"pair.codeHelp": "Invia questo codice al bot come messaggio diretto dall'account da verificare. Viene mostrato solo ora, vale una sola volta e scade alle {{time}}.",
	"pair.codeGone": "Il codice è scaduto. Creane uno nuovo se la persona non è ancora verificata.",
	"pair.done": "Verificato: {{sender}}.",
	"pair.dismiss": "Nascondi il codice",
	"pair.none": "Nessuno è verificato.",
	"pair.expires": "termina {{time}}",
	"pair.full": "Tre persone sono verificate. Rimuovine una per verificarne un'altra.",
	"access.title": "Verifica",
	"access.needSave": "Salva prima questo bot per vedere chi ha rifiutato di recente.",
	"access.refresh": "Aggiorna",
	"access.who": "mittente {{senders}}",
	"can.sender.role": "Ruolo: {{title}}",
	"can.fromForm": "Calcolato dal modulo così com'è ora. Salva per mantenere queste impostazioni.",
	"can.fromFormNew": "Non ancora salvato. Calcolato dal modulo così com'è ora.",
	"can.loading": "Controllo di cosa può fare questo bot",
	"can.stale": "Aggiornamento",
	"can.errorTitle": "Non è stato possibile controllare cosa può fare questo bot",
	"can.retry": "Riprova",
	"can.allowed": "Consentito",
	"can.via.paired": "perché questa persona è verificata",
	"can.via.allowlist": "perché questa persona è in elenco",
	"can.via.agentConnection": "perché questa persona è verificata e l'agente è collegato al componente",
	"can.via.role": "tramite il ruolo {{role}}",
	"can.then": "Non ancora controllati: {{list}}.",
	"can.then.server": "le impostazioni del server",
	"can.then.tools": "l'interruttore Strumenti dell'agente",
	"can.then.agent": "i permessi dell'agente",
	"can.then.connection": "i permessi di questa connessione",
	"can.then.sender": "chi sta scrivendo",
	"can.then.approval": "come vengono confermate le proposte",
	"can.noMessage": "Non consentito.",
	"fix.open_connection": "Mostra l'impostazione",
	"fix.open_agent": "Apri l'agente",
	"fix.open_server_setting": "Apri le impostazioni",
	"fix.pair_sender": "Verifica una persona",
	"fix.add_person": "Aggiungi una persona",
	"fix.save": "Mantieni queste modifiche",
	"fix.token": "Incolla il token",
	"fix.tokenNew": "Incolla un nuovo token",
	"fix.agent": "Scegli un agente",
	"fix.usual": "Scegli i permessi",
	"fix.turnOn": "Attiva",
	"fix.newTab": "(si apre in una nuova scheda)",
	"fix.askAdmin": "Chiedi a un amministratore",
	"ready.title": "Stato",
	"ready.checkingSummary": "Controllo di cosa farà il modulo.",
	"ready.allGood": "Tutto il necessario è a posto.",
	"ready.showAll": "Mostra tutti e {{count}}",
	"ready.showProblems": "Mostra solo ciò che richiede attenzione",
	"ready.checking": "Controllo in corso.",
	"ready.unchecked": "Non è stato possibile controllarlo. Vedi «Cosa può fare questo bot» qui sotto.",
	"ready.row.token": "Token",
	"ready.row.agent": "Agente",
	"ready.row.who": "Chi può usarlo",
	"ready.row.permissions": "Permessi",
	"ready.row.addons": "Strumenti dei componenti",
	"ready.row.triggers": "Trigger",
	"ready.row.files": "File",
	"ready.row.notify": "Notifiche",
	"ready.state.ok": "OK",
	"ready.state.attention": "Richiede attenzione",
	"ready.state.off": "Disattivato",
	"ready.state.after_save": "Dopo il salvataggio",
	"ready.state.broken": "Non funziona",
	"ready.state.checking": "Controllo",
	"ready.state.unknown": "Sconosciuto",
	"ready.token.missing": "Incolla il token del bot. Senza, non si riceve nulla.",
	"ready.token.newTyped": "Il token viene verificato con la piattaforma al salvataggio.",
	"ready.token.typed": "Il nuovo token viene verificato con la piattaforma al salvataggio.",
	"ready.token.failed": "La piattaforma ha rifiutato il token: {{reason}}",
	"ready.token.checked": "La piattaforma ha accettato il token. {{bot}}",
	"ready.token.saved": "Un token è salvato. La piattaforma lo ha accettato al salvataggio.",
	"ready.agent.none": "Scegli l'agente che risponde.",
	"ready.agent.credentialsOnly": "Nessun agente. Questa connessione conserva solo le credenziali e non risponde ad alcun messaggio.",
	"ready.agent.gone": "L'agente scelto non è più nel tuo elenco. Scegline un altro.",
	"ready.agent.noModel": "{{name}} non ha un modello, quindi non può rispondere. Assegnagliene uno.",
	"ready.agent.ok": "{{name}} risponde, con il modello {{model}}.",
	"ready.agent.okUnknown": "È stato scelto un agente.",
	"ready.who.anyone": "Chiunque possa scrivere al bot può usarlo.",
	"ready.who.nobody": "Nessuno è ancora in elenco, quindi il bot ignora ogni messaggio. Aggiungi una persona.",
	"ready.who.channelsOnly": "Nell'elenco ci sono solo canali. Le persone in un canale possono chattare, ma usano i permessi selezionati solo dove il canale è impostato su Lascia chiedere azioni a tutti qui.",
	"ready.who.listed_one": "{{count}} persona o chat è in elenco.",
	"ready.who.listed_other": "{{count}} persone o chat sono in elenco.",
	"ready.who.mixed": "{{count}} voci sono in elenco, persone e canali.",
	"ready.perm.none": "Nessun permesso è attivo. I mittenti possono chattare, e nient'altro.",
	"ready.perm.noneSaved": "Nessun permesso è attivo, quindi file, memoria, trigger e pubblicazioni sono disattivati.",
	"ready.perm.onlyOwnRows": "Gli altri permessi sono disattivati. Trigger e file sono qui sotto.",
	"ready.perm.ok_one": "{{count}} permesso è attivo e un mittente può usarlo.",
	"ready.perm.ok_other": "{{count}} permessi sono attivi e un mittente può usarli.",
	"ready.perm.dead_one": "Nessuno può usare {{names}}. {{message}}",
	"ready.perm.dead_other": "Nessuno può usare {{count}} dei permessi attivi: {{names}}. Il primo: {{message}}",
	"ready.addons.off": "L'agente ha gli strumenti {{addon}} {{tools}}, ma non può usarli in questa chat finché non attivi \"{{permission}}\".",
	"ready.addons.blocked": "L'agente ha gli strumenti {{addon}} {{tools}}, ma sono trattenuti. {{message}}",
	"ready.addons.ok": "L'agente può usare gli strumenti {{addon}} {{tools}} in questa chat.",
	"ready.addons.paired": "Le persone verificate possono usare gli strumenti di scrittura {{addon}} {{tools}} in questa chat, perché l'agente è collegato a {{connection}} (modalità di scrittura: {{mode}}). Le persone in elenco non verificate hanno bisogno di \"{{permission}}\".",
	"ready.addons.removed": "Hai disattivato \"{{permission}}\", quindi nessuno può usare gli strumenti di scrittura {{addon}} {{tools}} in questa chat, nemmeno le persone verificate. Attivalo per riaverli; li ottengono anche le persone in elenco non verificate.",
	"ready.addons.modeOff": "L'agente ha gli strumenti di scrittura {{addon}} {{tools}}, ma sono trattenuti perché la modalità di scrittura di {{connection}} è disattivata. Cambia la modalità di scrittura su quel collegamento.",
	"ready.addons.mode.auto": "parte subito",
	"ready.addons.mode.propose": "chiede prima",
	"ready.triggers.off": "L'agente non può impostare promemoria o attività pianificate qui.",
	"ready.triggers.blocked": "I trigger sono attivi, ma non si possono usare. {{message}}",
	"ready.triggers.ok.ask": "L'agente può proporre trigger. Confermi tu ciascuno prima che parta.",
	"ready.triggers.ok.auto": "L'agente può proporre trigger. Partono subito, senza chiedertelo.",
	"ready.triggers.ok.auto_readonly": "L'agente può proporre trigger. Un trigger che si limita a leggere parte subito; gli altri li confermi tu.",
	"ready.files.offReceive": "I mittenti non possono inviare file all'agente.",
	"ready.files.offBoth": "I mittenti non possono inviare file all'agente, e il bot non ne rimanda indietro.",
	"ready.files.blocked": "La ricezione dei file è attiva, ma non si può usare. {{message}}",
	"ready.files.ok": "I mittenti possono inviare file all'agente, e il bot può rimandarne indietro.",
	"ready.files.okReceive": "I mittenti possono inviare file all'agente. Il bot non ne rimanda indietro.",
	"ready.notify.off": "Nessuna chat riceve avvisi da questo bot.",
	"ready.notify.ok": "Gli avvisi vanno alla chat {{chat}}.",
	dismiss: "Chiudi",
	credentialsOnly: "Solo credenziali",
	agentCredentialsOnly: "Nessun agente (solo credenziali)",
	agentOptionalHint: "Facoltativo. Senza un agente questa connessione conserva solo il token, l'elenco dei repository e la modalità di scrittura per le tue chat. Non risponde ad alcun messaggio. Scegli un agente per farla restare in ascolto.",
	"sender.line_one": "{{name}} · {{count}} messaggio · {{id}}",
	"sender.line_other": "{{name}} · {{count}} messaggi · {{id}}",
	"ready.blocker.nobodyLetIn": "Nessuno è ancora ammesso.",
	"ready.blocker.nobodyPaired": "Serve una persona verificata, e nessuno è ancora verificato.",
	optional: "facoltativo",
	"approvals.title": "Strumenti che partono subito",
	"approvals.help": "Alcuni strumenti di questo add-on possono partire senza una scheda di conferma, ma solo se il proprietario lo ha scelto nella pagina dell'add-on. Ogni altro strumento e ogni altro mittente viene comunque interpellato.",
	"approvals.state.asks": "Chiede prima",
	"approvals.state.runs": "Parte subito",
	"approvals.state.idle": "Impostato per partire subito, ora non fa nulla",
	"approvals.state.other": "Chiede ancora prima a questo mittente",
	"approvals.line.asks": "Una scheda attende il tuo OK.",
	"approvals.line.runs": "Per le chat del proprietario e per le persone verificate. Tutti gli altri vengono comunque interpellati.",
	"approvals.line.idle": "La modalità di scrittura di questa connessione è Sola lettura, quindi nessuno strumento di scrittura parte.",
	"approvals.line.other": "Solo il proprietario e una persona verificata saltano la scheda. Questo tipo di mittente viene interpellato.",
	"dup.text": "Questo bot è collegato anche come {{name}}. Entrambe le connessioni risponderanno allo stesso messaggio.",
	"dup.turnOff": "Disattiva questa",
	"dup.openOther": "Apri {{name}}",
	"dup.saveAnyway": "Salva comunque",
	"dup.goBack": "Indietro",
	"dup.confirmHelp": "Salva comunque solo se vuoi ricevere due risposte a ogni messaggio.",
	"access.noteSave.title": "Note",
	"access.noteSave.now": "Salva le note subito e avvisa, con Annulla",
	"access.noteSave.ask": "Le note di questo tipo di mittente aspettano il proprietario",
	"trust.answer": "Solo risposta",
	"trust.act": "Lascia chiedere azioni a tutti qui",
	"ready.row.channelTrust": "Canali in cui il bot ascolta",
	"ready.row.postTo": "Dove può pubblicare",
	"ready.channelTrust.act": "Le persone in {{channels}} possono chiedere azioni quotidiane. Quelle sensibili richiedono comunque una persona verificata.",
	"ready.channelTrust.answer": "Le persone in {{channels}} non possono usare azioni: impostalo su Lascia chiedere azioni a tutti qui.",
	"ready.channelTrust.noCaps": "Nessun permesso è selezionato, quindi file e altre azioni sono rifiutati anche dove tutti possono chiedere.",
	"fix.trust": "Imposta il canale",
	"can.via.channel": "Chiunque in questo canale può chiederlo perché il canale è impostato su Lascia chiedere azioni a tutti qui",
	"ready.postTo_one": "Il bot può pubblicare in 1 altro luogo quando una persona in elenco lo chiede. Questo non rende affidabili le persone al suo interno.",
	"ready.postTo_other": "Il bot può pubblicare in {{count}} altri luoghi quando una persona in elenco lo chiede. Questo non rende affidabili le persone al loro interno.",
	"access.toolsTitle": "Chiamate agli strumenti degli add-on",
	"access.toolsHelp": "Le ultime chiamate agli strumenti degli add-on che hanno usato questa connessione o sono arrivate da questo bot, dalla più recente, al massimo 20. Contengono nomi di strumenti e motivi, mai ciò che è stato chiesto o risposto. Si azzerano al riavvio del server.",
	"access.toolsNone": "Nessuna chiamata ancora.",
	"access.outcome.ok": "riuscita",
	"access.outcome.held": "in attesa",
	"access.outcome.denied": "negata",
	"access.outcome.error": "fallita",
	"ready.addons.confirmChat": "Una persona verificata può confermare nella chat le scritture di {{addon}}: il bot le scrive lì e risponde sì o no.",
	"access.outcome.confirmed": "confermata",
	"access.outcome.cancelled": "annullata",
	"access.outcome.expired": "scaduta",
	"access.askedBy": "richiesta da {{sender}}",
	"access.chat": "in {{chat}}",
	"sender.chat": "in {{chat}}",
	"sender.reason.not_listed": "non è una persona in elenco",
	"sender.reason.not_addressed": "il messaggio non nominava il bot",
	"ready.notReady": "Non ancora pronto.",
	"ready.fixCount_one": "{{count}} cosa da sistemare",
	"ready.fixCount_other": "{{count}} cose da sistemare",
	"ready.quiet_one": "{{count}} cosa da impostare",
	"ready.quiet_other": "{{count}} cose da impostare",
	"ready.quietDone": "Non resta nulla da impostare",
	"matrix.title": "Chi può fare cosa",
	"loops.title": "Attese e timer",
	"loops.help": "Cosa può fare l'agente più tardi in questa chat da solo. Appartengono al bot: un ruolo non li riceve mai.",
	"matrix.note": "Gli interruttori e le caselle dei ruoli sono tuoi da impostare. Ogni altra cella è calcolata dalle tue impostazioni attuali, con lo stesso controllo che l'host esegue a ogni messaggio.",
	"matrix.capability": "Permesso",
	"matrix.pick": "Tipo di mittente",
	"matrix.col.on": "Attivo per questo bot",
	"matrix.col.paired": "Persona verificata",
	"matrix.col.listed": "Persona in elenco",
	"matrix.col.channel_acts": "Canale: tutti agiscono",
	"matrix.col.channel_member": "Canale: solo risposta",
	"matrix.col.anyone": "Chiunque",
	"matrix.state.yes": "Sì",
	"matrix.state.asks": "Chiede prima",
	"matrix.state.no": "No",
	"matrix.state.waiting": "In attesa di una persona",
	"matrix.state.off": "Spento",
	"matrix.state.unknown": "Non noto",
	"matrix.row.tools": "Modificare dati nei servizi collegati",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Perché una cella dice No o Disattivato",
	"matrix.detail.none": "Scegli una cella per leggere il motivo.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Ripristina l'insieme abituale",
	"matrix.more": "Dettagli",
	"matrix.less": "Nascondi i dettagli",
	"matrix.nobodyVerified": "Nessuno è ancora verificato.",
	"who.title": "Chi può parlare con il bot",
	"who.onlyChosen": "Solo le persone che scelgo io",
	"who.anyone": "Chiunque possa scrivergli",
	"who.people": "Persone",
	"who.peopleAndChannels": "Persone e canali",
	"who.peopleNone": "Nessuno è ancora in elenco. Aggiungi una persona qui sotto.",
	"who.channels": "Canali",
	"who.channelsNote": "Le persone in un canale possono agire solo dentro quel canale, mai in un messaggio diretto.",
	"who.add": "Aggiungi una persona o un canale",
	"who.recent": "Persone che hanno scritto di recente al bot. Fai clic per aggiungerle.",
	"who.addPerson": "Aggiungi {{name}}",
	"who.verified": "Verificata",
	"who.listed": "In elenco",
	"who.verify": "Verifica",
	"who.verifyPerson": "Verifica {{name}}",
	"who.remove": "Rimuovi",
	"who.removePerson": "Rimuovi {{name}}",
	"who.removeChannel": "Rimuovi {{name}}",
	"who.levelFor": "Cosa possono fare le persone in {{channel}}",
	"answer.more": "Dimensione dei file e lingua delle risposte",
	"perm.channelsSwitch": "Vai all'interruttore",
	"perm.channelWho": "Chi può farlo scrivere",
	"perm.channelWhoFor": "Chi può far scrivere il bot in {{id}}",
	"perm.channelWho.any": "Quando lo chiede una persona consentita",
	"perm.channelWho.verified": "Solo quando lo chiede una persona verificata",
	"notify.label": "Invia promemoria e risultati delle esecuzioni a",
	"notify.none": "Da nessuna parte",
	"notify.people": "Persone",
	"notify.channels": "Canali",
	"notify.saved": "{{id}} (ID salvato)",
	"notify.other": "Un altro ID...",
	"notify.otherLabel": "ID della chat",
	"try.title": "Provalo",
	"try.help": "Scegli chi scrive, dove e cosa chiede. Esegue il controllo che l'host fa a ogni messaggio, sul modulo com'è ora.",
	"try.noone": "Aggiungi prima una persona. Poi potrai provare cosa può fare.",
	"try.whoLabel": "Chi",
	"try.placeLabel": "Dove",
	"try.actionLabel": "Cosa chiedono",
	"try.someoneIn": "Qualcuno in {{channel}}",
	"try.anyone": "Chiunque",
	"try.role": "Qualcuno con il ruolo {{role}}",
	"try.dm": "Messaggio diretto",
	"try.where.dm": "in un messaggio diretto",
	"try.where.channel": "in {{channel}}",
	"try.is.paired": "{{who}} è una persona verificata e scrive {{where}}.",
	"try.is.listed": "{{who}} è una persona in elenco e scrive {{where}}.",
	"try.is.channelActs": "Qualcuno in {{channel}}, dove tutti possono chiedere azioni.",
	"try.is.channelAnswers": "Qualcuno in {{channel}}, dove si ricevono solo risposte.",
	"try.is.anyone": "Chiunque possa scrivere al bot viene accettato.",
	"try.is.role": "Una persona con il ruolo {{role}} viene accettata.",
	"try.verdict.allowed": "Consentito.",
	"try.verdict.asks": "Consentito, ma chiede prima.",
	"try.verdict.refused": "Rifiutato.",
	"try.loading": "Controllo in corso...",
	"try.error": "Il controllo non ha risposto. Usa Riprova nella tabella sopra.",
	"try.unknown": "L'host non ha dato risposta per questo tipo di mittente.",
	"try.note": "Non viene inviato nulla alla piattaforma e non viene salvato nulla.",
	"refusals.title": "Rifiuti recenti",
	"refusals.help": "Cosa ha rifiutato il bot da quando il server è partito, dal più recente. Contiene ID, nomi e chat, mai il testo dei messaggi. Questo registro è solo in memoria: dopo il riavvio del server è vuoto.",
	"refusals.none": "Nessun rifiuto da quando il server è partito.",
	"refusals.refused": "rifiutato",
	"refusals.action": "ha chiesto: {{action}}",
	"refusals.talk": "ha scritto al bot",
	"refusals.allow": "Consenti {{name}}",
	"refusals.act": "Consenti ai membri di {{channel}} di agire",
	"perm.channelPickOther": "Altro: scrivi un ID",
	"perm.channelHint.verified": "Le esecuzioni programmate non possono scrivere qui. Scegli \"Quando una persona consentita lo chiede\" per permetterlo.",
	"perm.channelHint.any": "Le esecuzioni programmate possono scrivere qui.",
	"perm.channelNoListen": "Il bot non ascolta in questo canale, quindi ci scriverà soltanto.",
	"who.post.none": "Il bot non può scrivere qui.",
	"who.post.add": "Lascia scrivere qui anche il bot",
	"who.post.addFor": "Lascia scrivere anche in {{name}} il bot",
	"who.post.verified": "Scrive qui solo quando lo chiede una persona verificata.",
	"who.post.any": "Scrive qui quando lo chiede una persona consentita.",
	"who.post.show": "Mostra il posto",
	"who.post.showFor": "Mostra il posto di {{name}}",
	agentLink: "Apri l'agente {{name}}",
	"saved.created": "Connessione aggiunta.",
	"saved.nothing": "Salvato. Nessuna modifica.",
	"saved.changed": "Salvato. Modificato: {{what}}.",
	"saved.part.name": "nome",
	"saved.part.agent": "agente",
	"saved.part.who": "chi accetta",
	"saved.part.permissions": "permessi",
	"saved.part.approval": "approvazione e azioni dei trigger",
	"saved.part.files": "impostazioni dei file",
	"saved.part.notify": "notifiche",
	"saved.dropped.title": "Questa connessione non permette più queste azioni, quindi le esecuzioni di questi trigger le perdono:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "Attiva",
	"conn.state.off": "Spenta",
	"conn.state.attention": "Richiede attenzione",
	"conn.state.ready": "Pronta",
	"conn.row.open": "{{name}}: {{state}}. Mostra i dettagli",
	"conn.row.menu": "Altre azioni per {{name}}",
	"conn.row.testNamed": "Prova {{name}}",
	"conn.fix.token": "Correggi il token",
	"conn.reason.noToken": "Nessun token salvato.",
	"conn.reason.duplicate": "Risponde allo stesso bot di {{name}}.",
	"conn.reason.testFailed": "L'ultima prova non è riuscita: {{reason}}",
	"conn.kv.service": "Servizio",
	"conn.kv.accepts": "Accetta",
	"conn.kv.replies": "Risposte",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Salvato",
	"conn.kv.notSaved": "Non salvato",
	"conn.kv.agents": "Agenti",
	"usedBy.count_one": "Usata da {{count}} agente",
	"usedBy.count_other": "Usata da {{count}} agenti",
	"usedBy.none": "Non usata da nessun agente",
	"conn.pane.lastTest": "Ultima prova",
	"conn.pane.never": "Non ancora provata in questo browser.",
	"conn.pane.passed": "Riuscita {{when}}.",
	"conn.pane.failed": "Non riuscita {{when}}.",
	"conn.pane.connection": "Connessione",
	"conn.pane.remove": "Rimuovi",
	"conn.pane.test": "Prova la connessione",
	"conn.pane.testing": "Prova in corso...",
	"conn.sheet.addDesc": "Dai un nome, aggiungi il token e scegli l'agente che risponde.",
	"conn.sheet.editDesc": "Le modifiche valgono quando salvi. Un token salvato non viene mai mostrato di nuovo.",
	"conn.sheet.connection": "Connessione",
	"conn.sheet.who": "Chi può scriverle",
	"conn.sheet.may": "Cosa può fare",
	"conn.sheet.replies": "Risposte, file e luoghi",
	"conn.sheet.check": "Controlla cosa farà",
	"conn.sheet.saveAndTest": "Salva e prova",
	"conn.sheet.saving": "Salvataggio...",
	"conn.sheet.testFailed": "La connessione è salvata, ma la prova non è riuscita.",
	"conn.sheet.testFailedNoReason": "Nessun motivo indicato.",
	"conn.sheet.testAgain": "Prova di nuovo",
	"conn.sheet.close": "Chiudi",
	"conn.sheet.agentFixed": "Risponde con l'agente {{name}}",
	"conn.preset.label": "Permessi",
	"conn.preset.answer": "Solo risposte",
	"conn.preset.answerHelp": "Risponde ai messaggi. Questa connessione non aggiunge alcun permesso proprio.",
	"conn.preset.standard": "Standard",
	"conn.preset.standardHelp": "L'insieme abituale che l'agente possiede: {{list}}.",
	"conn.preset.standardNone": "L'insieme abituale. Questo agente non ne possiede nulla.",
	"conn.preset.custom": "Personalizzato",
	"conn.preset.customHelp": "Scegli ogni permesso e chi può usarlo.",
	"conn.preset.note": "Un'opzione predefinita non attiva mai un permesso sensibile. Usa Personalizzato per quelli. Le connessioni ai componenti aggiuntivi che l'agente possiede hanno regole proprie: le persone verificate possono comunque usare i loro strumenti di scrittura. Cambiale nell'agente, in \"Cosa può usare\".",
	"conn.discard.title": "Scartare le modifiche?",
	"conn.discard.message": "Hai modificato questa connessione e non l'hai salvata.",
	"conn.discard.confirm": "Scarta le modifiche",
	"share.label": "Condividi",
	"share.button": "Condividi {{name}}",
	"share.intro": "Le persone che aggiungi possono usare questa connessione nelle proprie chat e nei propri agenti. Ne vedono il nome e lo stato, mai il token o le impostazioni. I messaggi al bot arrivano sempre al tuo agente.",
	"share.roleUse": "Può usare",
	"share.roleUseHelp": "Può usarla nelle sue chat e nei suoi agenti. Non può vedere il token, modificarla o condividerla.",
	"shared.title": "Condivisi con te",
	"shared.text": "Altre persone ti permettono di usare queste connessioni nelle tue chat e nei tuoi agenti. Solo chi le possiede può modificarle.",
	"shared.on": "In ascolto",
	"shared.off": "Spenta",
	"shared.by": "Condivisa da {{name}}",
	loginNeedsHost: "Questa versione di LocalAI non può eseguire l’accesso da questa pagina. Aggiorna LocalAI per connetterti qui."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.fr.json
var connector_fr_default = {
	"answer.title": "Où il publie et comment il répond",
	"answer.replyLabel": "Pendant que l’agent travaille",
	"answer.reply.off": "Saisie en cours, puis la réponse",
	"answer.reply.progress": "Progression : les outils utilisés",
	"answer.reply.stream": "En direct : la réponse à mesure qu’elle s’écrit",
	"answer.reply.reasoning": "Réflexion : la réflexion du modèle, puis la réponse",
	"answer.replyHelp": "Progression et En direct affichent un seul message de travail, que la réponse remplace. Sur une plateforme avec brouillons, En direct montre un brouillon dans un chat privé, puis la réponse le suit. Une longue réponse continue dans de nouveaux messages.",
	"answer.replyReasoningHelp": "Réflexion montre la réflexion du modèle, au fil de son écriture, à chaque expéditeur de cette liaison. À n’utiliser que là où c’est acceptable.",
	"answer.conversationLabel": "Conversations",
	"answer.conversationHelp": "Envoyez /new (ou !new) dans l’application pour démarrer un nouveau chat.",
	"answer.conversation.sender": "Un chat par personne",
	"answer.conversation.chat": "Un chat par groupe ou canal",
	"answer.conversation.window": "Par personne, nouveau après un temps d’inactivité",
	"answer.conversation.thread": "Nouveau chat à chaque message ; les réponses suivent",
	"answer.window": "Temps d’inactivité, en minutes",
	"answer.windowRange": "Saisissez un nombre entier de 1 à {{max}}.",
	"answer.languageLabel": "Langue des réponses",
	"answer.languageHelp": "Les messages que le bot écrit lui-même, comme les confirmations et les refus. Les réponses du modèle suivent la langue de la conversation.",
	"answer.language.auto": "Automatique (la langue de votre interface, sinon celle de l'expéditeur)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Envoyer les fichiers créés par l’agent",
	add: "Ajouter",
	more: "Plus",
	less: "Moins",
	"answer.filesHelp": "Après la réponse, jusqu’à 5 fichiers. Les programmes et les scripts ne sont pas envoyés. La limite de taille se règle sous Taille des fichiers et langue des réponses.",
	"answer.summary": "Réponses : {{reply}} · {{conversation}}",
	"answer.short.off": "saisie en cours",
	"answer.short.progress": "progression",
	"answer.short.stream": "réponse en direct",
	"answer.short.reasoning": "réflexion visible",
	"answer.short.sender": "un chat par personne",
	"answer.short.chat": "un chat par groupe",
	"answer.short.window": "nouveau chat après {{count}} min",
	"answer.short.thread": "un chat par message",
	"approval.title": "Minuteurs et déclencheurs depuis le chat",
	"approval.help": "Quand l’agent met en place quelque chose qui s’exécute plus tard (« dans 10 minutes », « chaque jour »), chaque exécution est un appel au modèle.",
	"approval.mode.ask": "Demande d’abord : le bot le propose dans le chat et la personne répond oui ou non",
	"approval.mode.auto": "S’exécute tout de suite : il est mis en place et la personne est informée de la façon de l’annuler",
	"approval.mode.auto_readonly": "S’exécute tout de suite si les exécutions se contentent de lire et de rapporter ; sinon demande d’abord",
	"approval.limitsHelp": "Ces limites bornent ce qui est mis en place sans demander. Laissez un champ vide pour sa valeur par défaut. Tout ce qui dépasse une limite est soumis à confirmation.",
	"approval.max_pending": "Nombre maximal de minuteurs et de déclencheurs à la fois",
	"approval.min_gap_minutes": "Nombre minimal de minutes entre deux exécutions d’un déclencheur récurrent",
	"approval.max_runs_per_day": "Nombre maximal d’exécutions par jour, au total",
	"approval.max_lifetime_days": "Durée de vie maximale, en jours",
	"approval.invalid": "Saisissez un nombre entier de 1 à {{max}}, ou laissez vide.",
	"approval.default": "Par défaut : {{value}}.",
	"approval.summary": "Déclencheurs : {{mode}}",
	"approval.effect": "Propositions : {{mode}}",
	"approval.effectChange": "Modifications et suppressions : {{mode}}",
	"approval.limits": "Limites",
	"approval.acts.title": "Les exécutions peuvent agir",
	"approval.acts.help": "Désactivé : les exécutions d’un déclencheur créé depuis ce chat se contentent de lire et de rapporter. Activé : elles peuvent aussi faire ce que vous cochez ci-dessous, et seulement ce dont l’agent dispose.",
	"approval.acts.modes": "Demande d’abord : vous décidez toujours. S’exécute tout de suite : seulement si vous êtes une personne vérifiée et que chaque action est cochée ici.",
	"approval.acts.act.files": "Écrire des fichiers dans les dossiers de l’agent",
	"approval.acts.act.files.effect": "Une exécution peut créer et modifier les fichiers que garde l’agent.",
	"approval.acts.act.addons": "Utiliser les actions des add-ons de l’agent",
	"approval.acts.act.addons.effect": "Une exécution peut utiliser ce que font les add-ons de l’agent, y compris des commandes.",
	"approval.acts.act.send": "Envoyer des messages au-delà de l’endroit où elle rapporte",
	"approval.acts.act.send.effect": "Une exécution peut écrire seule dans d’autres chats et canaux.",
	"approval.acts.act.spend": "Utiliser des outils payants ou externes et le réseau",
	"approval.acts.act.spend.effect": "Une exécution peut appeler des services extérieurs à LocalAI, ce qui peut coûter de l’argent.",
	"approval.acts.lacks": "L’agent ne dispose pas de ceci.",
	"approval.acts.sensitive": "Sensible",
	"approval.effectActs": ", les exécutions peuvent : {{acts}}",
	"approval.actShort.act.files": "écrire des fichiers",
	"approval.actShort.act.addons": "utiliser des add-ons",
	"approval.actShort.act.send": "envoyer des messages",
	"approval.actShort.act.spend": "utiliser des outils payants ou externes",
	"approval.short.ask": "demande d’abord",
	"approval.short.auto": "s’exécute tout de suite",
	"approval.short.auto_readonly": "s’exécute tout de suite si lecture seule",
	"files.title": "Fichiers",
	"files.help": "Laissez un champ vide pour utiliser la limite de l’add-on. Votre limite ne peut être que plus basse.",
	"files.receiveLabel": "Plus gros fichier qu’il lit, en Mio",
	"files.sendLabel": "Plus gros fichier qu’il envoie, en Mio",
	"files.invalid": "Saisissez un nombre supérieur à 0.",
	"files.tooHigh": "L’add-on autorise au plus {{max}} ici.",
	"files.now": "Actuellement : {{limit}} ({{layer}}).",
	"files.receiveHelp": "Les fichiers que les gens envoient au bot. Un fichier plus gros est refusé, et le bot indique la limite atteinte.",
	"files.sendHelp": "Les fichiers que l’agent crée et que le bot renvoie. Un fichier plus gros n’est pas envoyé, et le bot indique la limite atteinte.",
	"files.addon.off": "Cet add-on ne transfère pas de fichiers dans ce sens, il n’y a donc rien à régler.",
	"files.addon.declared": "L’add-on déclare jusqu’à {{max}}.",
	"files.addon.open": "L’add-on ne déclare aucune limite, c’est donc celle de la plateforme qui s’applique.",
	"files.host": "Aucun bot ne peut transférer un fichier de plus de {{max}}. Un administrateur règle cela dans les paramètres.",
	"files.layer.owner": "limite définie pour ce bot",
	"files.layer.addon": "limite de l’add-on",
	"files.layer.host": "limite de la plateforme",
	"perm.agentLacks": "L’agent ne dispose pas de ceci.",
	"perm.rule": "Les personnes de la liste peuvent utiliser les autorisations cochées. Les autorisations sensibles exigent en plus une personne vérifiée.",
	"perm.sensitive": "Personnes vérifiées uniquement",
	"perm.sensitiveHelp": "Sensible. Jamais accordée à un rôle. Seule une personne vérifiée peut l’utiliser, et chaque usage est consigné.",
	"perm.roleCap": "{{role}} : {{cap}}",
	"perm.channelsTitle": "Lieu où le bot peut publier",
	"perm.channelsHelp": "Lieux où l’agent peut publier à la demande d’une personne de la liste, en plus du chat où il répond. Cela ne décide pas qui le bot écoute : voir Canaux où le bot écoute. Au plus {{max}}.",
	"perm.channelsOff": "Activez « Publier dans d’autres canaux » plus haut pour choisir les lieux où le bot peut publier.",
	"perm.channelId": "ID du canal",
	"perm.channelLabel": "Nom",
	"perm.channelAdd": "Ajouter un lieu",
	"perm.channelRemove": "Retirer le lieu {{id}}",
	"perm.remove": "Retirer",
	"perm.channelFull": "La liste est pleine.",
	"perm.channelProblem.id": "Chaque lieu exige un ID de 1 à {{max}} octets, sans espace.",
	"perm.channelProblem.label": "Un nom compte au plus {{max}} caractères.",
	"perm.channelProblem.repeat": "Un lieu figure deux fois dans la liste.",
	"perm.channelProblem.count": "Au plus {{max}} lieux.",
	"perm.triggersNeed": "Activez Proposer des déclencheurs pour l’utiliser.",
	"pair.start": "Vérifier une personne",
	"pair.startHelp": "Génère un code. Envoyez-le au bot en message privé depuis le compte à vérifier, dans les dix minutes. Le code ne sert qu’une fois.",
	"pair.needSave": "Enregistrez d’abord ce bot, puis vérifiez une personne.",
	"pair.codeTitle": "Votre code de vérification",
	"pair.codeHelp": "Envoyez ce code au bot en message privé depuis le compte à vérifier. Il n’est affiché que maintenant, ne sert qu’une fois et expire à {{time}}.",
	"pair.codeGone": "Le code a expiré. Générez-en un nouveau si la personne n’est pas encore vérifiée.",
	"pair.done": "Vérifié : {{sender}}.",
	"pair.dismiss": "Masquer le code",
	"pair.none": "Personne n’est vérifiée.",
	"pair.expires": "fin {{time}}",
	"pair.full": "Trois personnes sont vérifiées. Retirez-en une pour en vérifier une autre.",
	"access.title": "Vérifier",
	"access.needSave": "Enregistrez d'abord ce bot pour voir qui il a refusé récemment.",
	"access.refresh": "Actualiser",
	"access.who": "expéditeur {{senders}}",
	"can.sender.role": "Rôle : {{title}}",
	"can.fromForm": "Calculé d’après le formulaire tel qu’il est maintenant. Enregistrez pour conserver ces réglages.",
	"can.fromFormNew": "Pas encore enregistré. Calculé d’après le formulaire tel qu’il est maintenant.",
	"can.loading": "Vérification de ce que ce bot peut faire",
	"can.stale": "Mise à jour",
	"can.errorTitle": "Impossible de vérifier ce que ce bot peut faire",
	"can.retry": "Réessayer",
	"can.allowed": "Autorisé",
	"can.via.paired": "parce que cette personne est vérifiée",
	"can.via.allowlist": "parce que cette personne figure dans la liste",
	"can.via.agentConnection": "parce que cette personne est vérifiée et que l’agent est connecté au module",
	"can.via.role": "via le rôle {{role}}",
	"can.then": "Pas encore vérifié : {{list}}.",
	"can.then.server": "les paramètres du serveur",
	"can.then.tools": "le commutateur Outils de l’agent",
	"can.then.agent": "les autorisations de l’agent",
	"can.then.connection": "les autorisations de cette connexion",
	"can.then.sender": "qui envoie",
	"can.then.approval": "la façon dont les propositions sont confirmées",
	"can.noMessage": "Non autorisé.",
	"fix.open_connection": "Afficher le réglage",
	"fix.open_agent": "Ouvrir l’agent",
	"fix.open_server_setting": "Ouvrir les paramètres",
	"fix.pair_sender": "Vérifier une personne",
	"fix.add_person": "Ajouter une personne",
	"fix.save": "Garder ces modifications",
	"fix.token": "Coller le jeton",
	"fix.tokenNew": "Coller un nouveau jeton",
	"fix.agent": "Choisir un agent",
	"fix.usual": "Choisir des autorisations",
	"fix.turnOn": "Activer",
	"fix.newTab": "(s’ouvre dans un nouvel onglet)",
	"fix.askAdmin": "Demander à un administrateur",
	"ready.title": "État",
	"ready.checkingSummary": "Vérification de ce que fera le formulaire.",
	"ready.allGood": "Tout le nécessaire est en place.",
	"ready.showAll": "Tout afficher ({{count}})",
	"ready.showProblems": "Afficher seulement ce qui demande attention",
	"ready.checking": "Vérification.",
	"ready.unchecked": "Impossible de le vérifier. Voir « Ce que ce bot peut faire » ci-dessous.",
	"ready.row.token": "Jeton",
	"ready.row.agent": "Agent",
	"ready.row.who": "Qui peut l’utiliser",
	"ready.row.permissions": "Autorisations",
	"ready.row.addons": "Outils des modules",
	"ready.row.triggers": "Déclencheurs",
	"ready.row.files": "Fichiers",
	"ready.row.notify": "Notifications",
	"ready.state.ok": "OK",
	"ready.state.attention": "À vérifier",
	"ready.state.off": "Désactivé",
	"ready.state.after_save": "Après l’enregistrement",
	"ready.state.broken": "Ne fonctionne pas",
	"ready.state.checking": "Vérification",
	"ready.state.unknown": "Inconnu",
	"ready.token.missing": "Collez le jeton du bot. Sans lui, rien n’est reçu.",
	"ready.token.newTyped": "Le jeton est vérifié auprès de la plateforme à l’enregistrement.",
	"ready.token.typed": "Le nouveau jeton est vérifié auprès de la plateforme à l’enregistrement.",
	"ready.token.failed": "La plateforme a refusé le jeton : {{reason}}",
	"ready.token.checked": "La plateforme a accepté le jeton. {{bot}}",
	"ready.token.saved": "Un jeton est enregistré. La plateforme l’a accepté à l’enregistrement.",
	"ready.agent.none": "Choisissez l’agent qui répond.",
	"ready.agent.credentialsOnly": "Aucun agent. Cette connexion ne garde que les identifiants et ne répond à aucun message.",
	"ready.agent.gone": "L’agent choisi n’est plus dans votre liste. Choisissez-en un autre.",
	"ready.agent.noModel": "{{name}} n’a pas de modèle et ne peut donc pas répondre. Donnez-lui-en un.",
	"ready.agent.ok": "{{name}} répond, avec le modèle {{model}}.",
	"ready.agent.okUnknown": "Un agent est choisi.",
	"ready.who.anyone": "Toute personne pouvant écrire au bot peut l’utiliser.",
	"ready.who.nobody": "Personne n’est encore dans la liste, le bot ignore donc tous les messages. Ajoutez une personne.",
	"ready.who.channelsOnly": "Seuls des canaux figurent dans la liste. Les personnes d’un canal peuvent discuter, mais n’utilisent les permissions cochées que là où le canal est réglé sur Laisser tout le monde ici demander des actions.",
	"ready.who.listed_one": "{{count}} personne ou chat figure dans la liste.",
	"ready.who.listed_other": "{{count}} personnes ou chats figurent dans la liste.",
	"ready.who.mixed": "{{count}} entrées figurent dans la liste : personnes et canaux.",
	"ready.perm.none": "Aucune autorisation n’est activée. Les expéditeurs peuvent discuter, rien de plus.",
	"ready.perm.noneSaved": "Aucune autorisation n’est activée : fichiers, mémoire, déclencheurs et publications sont donc désactivés.",
	"ready.perm.onlyOwnRows": "Les autres autorisations sont désactivées. Les déclencheurs et les fichiers se trouvent plus bas.",
	"ready.perm.ok_one": "{{count}} autorisation est activée et un expéditeur peut l’utiliser.",
	"ready.perm.ok_other": "{{count}} autorisations sont activées et un expéditeur peut les utiliser.",
	"ready.perm.dead_one": "Personne ne peut utiliser {{names}}. {{message}}",
	"ready.perm.dead_other": "Personne ne peut utiliser {{count}} des autorisations activées : {{names}}. La première : {{message}}",
	"ready.addons.off": "L'agent a les outils {{addon}} {{tools}}, mais il ne peut pas les utiliser dans ce chat tant que vous n'activez pas \"{{permission}}\".",
	"ready.addons.blocked": "L'agent a les outils {{addon}} {{tools}}, mais ils sont retenus. {{message}}",
	"ready.addons.ok": "L'agent peut utiliser les outils {{addon}} {{tools}} dans ce chat.",
	"ready.addons.paired": "Les personnes vérifiées peuvent utiliser les outils d’écriture de {{addon}} ({{tools}}) dans ce chat, car l’agent est connecté à {{connection}} (mode d’écriture : {{mode}}). Les personnes de la liste qui ne sont pas vérifiées ont besoin de « {{permission}} ».",
	"ready.addons.removed": "Vous avez désactivé « {{permission}} » : personne ne peut donc utiliser les outils d’écriture de {{addon}} ({{tools}}) dans ce chat, pas même les personnes vérifiées. Activez-le pour les rétablir ; les personnes de la liste qui ne sont pas vérifiées les obtiennent aussi.",
	"ready.addons.modeOff": "L'agent a les outils d'écriture de {{addon}} ({{tools}}), mais ils sont retenus car le mode d'écriture de {{connection}} est désactivé. Changez le mode d'écriture de cette liaison.",
	"ready.addons.mode.auto": "s’exécute tout de suite",
	"ready.addons.mode.propose": "demande d’abord",
	"ready.triggers.off": "L’agent ne peut pas créer de rappels ni de tâches planifiées ici.",
	"ready.triggers.blocked": "Les déclencheurs sont activés, mais ils ne peuvent pas être utilisés. {{message}}",
	"ready.triggers.ok.ask": "L’agent peut proposer des déclencheurs. Vous confirmez chacun avant son démarrage.",
	"ready.triggers.ok.auto": "L’agent peut proposer des déclencheurs. Ils démarrent tout de suite, sans vous demander.",
	"ready.triggers.ok.auto_readonly": "L’agent peut proposer des déclencheurs. Un déclencheur qui ne fait que lire démarre tout de suite ; vous confirmez tous les autres.",
	"ready.files.offReceive": "Les expéditeurs ne peuvent pas envoyer de fichiers à l’agent.",
	"ready.files.offBoth": "Les expéditeurs ne peuvent pas envoyer de fichiers à l’agent, et le bot n’en renvoie aucun.",
	"ready.files.blocked": "La réception de fichiers est activée, mais elle ne peut pas être utilisée. {{message}}",
	"ready.files.ok": "Les expéditeurs peuvent envoyer des fichiers à l’agent, et le bot peut en renvoyer.",
	"ready.files.okReceive": "Les expéditeurs peuvent envoyer des fichiers à l’agent. Le bot n’en renvoie aucun.",
	"ready.notify.off": "Aucun chat ne reçoit d’avis de ce bot.",
	"ready.notify.ok": "Les avis vont au chat {{chat}}.",
	dismiss: "Ignorer",
	credentialsOnly: "Identifiants uniquement",
	agentCredentialsOnly: "Aucun agent (identifiants uniquement)",
	agentOptionalHint: "Facultatif. Sans agent, cette connexion ne garde que le jeton, la liste des dépôts et le mode d’écriture pour vos chats. Elle ne répond à aucun message. Choisissez un agent pour qu’elle écoute.",
	"sender.line_one": "{{name}} · {{count}} message · {{id}}",
	"sender.line_other": "{{name}} · {{count}} messages · {{id}}",
	"ready.blocker.nobodyLetIn": "Personne n’est encore admis.",
	"ready.blocker.nobodyPaired": "Il faut une personne vérifiée, et personne n’est encore vérifiée.",
	optional: "facultatif",
	"approvals.title": "Outils qui s’exécutent tout de suite",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "Demande d’abord",
	"approvals.state.runs": "S’exécute tout de suite",
	"approvals.state.idle": "Réglé pour s’exécuter tout de suite, sans effet pour l’instant",
	"approvals.state.other": "Demande toujours d’abord à cet expéditeur",
	"approvals.line.asks": "Une fiche attend votre accord.",
	"approvals.line.runs": "Pour les conversations du propriétaire et pour les personnes vérifiées. Les autres doivent toujours confirmer.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "Seuls le propriétaire et une personne vérifiée passent sans la fiche. Ce type d’expéditeur doit confirmer.",
	"dup.text": "Ce bot est aussi connecté sous le nom {{name}}. Les deux connexions répondront au même message.",
	"dup.turnOff": "Désactiver celle-ci",
	"dup.openOther": "Ouvrir {{name}}",
	"dup.saveAnyway": "Enregistrer quand même",
	"dup.goBack": "Retour",
	"dup.confirmHelp": "N'enregistrez quand même que si vous voulez recevoir deux réponses à chaque message.",
	"access.noteSave.title": "Notes",
	"access.noteSave.now": "Enregistre les notes aussitôt et prévient, avec Annuler",
	"access.noteSave.ask": "Les notes de ce type d'expéditeur attendent le propriétaire",
	"trust.answer": "Répondre seulement",
	"trust.act": "Laisser tout le monde ici demander des actions",
	"ready.row.channelTrust": "Canaux où le bot écoute",
	"ready.row.postTo": "Lieu où le bot peut publier",
	"ready.channelTrust.act": "Les personnes de {{channels}} peuvent demander des actions courantes. Les actions sensibles exigent toujours une personne vérifiée.",
	"ready.channelTrust.answer": "Les personnes de {{channels}} ne peuvent pas utiliser d’actions : réglez-le sur Laisser tout le monde ici demander des actions.",
	"ready.channelTrust.noCaps": "Rien n’est coché dans les permissions : les fichiers et autres actions sont refusés même là où tout le monde peut demander.",
	"fix.trust": "Régler le canal",
	"can.via.channel": "Tout le monde dans ce canal peut le demander, car le canal est réglé sur Laisser tout le monde ici demander des actions",
	"ready.postTo_one": "Le bot peut publier dans 1 autre lieu à la demande d’une personne de la liste. Cela ne rend pas fiables les personnes qui s’y trouvent.",
	"ready.postTo_other": "Le bot peut publier dans {{count}} autres lieux à la demande d’une personne de la liste. Cela ne rend pas fiables les personnes qui s’y trouvent.",
	"access.toolsTitle": "Appels aux outils des add-ons",
	"access.toolsHelp": "Les derniers appels aux outils des add-ons qui ont utilisé cette connexion ou sont venus par ce bot, du plus récent au plus ancien, 20 au maximum. Ils contiennent des noms d'outils et des motifs, jamais ce qui a été demandé ou répondu. Ils sont remis à zéro au redémarrage du serveur.",
	"access.toolsNone": "Aucun appel pour l'instant.",
	"access.outcome.ok": "réussi",
	"access.outcome.held": "en attente",
	"access.outcome.denied": "refusé",
	"access.outcome.error": "échoué",
	"ready.addons.confirmChat": "Une personne vérifiée peut confirmer dans le chat les écritures de {{addon}} : le bot écrit chacune là et elle répond oui ou non.",
	"access.outcome.confirmed": "confirmée",
	"access.outcome.cancelled": "annulée",
	"access.outcome.expired": "expirée",
	"access.askedBy": "demandée par {{sender}}",
	"access.chat": "dans {{chat}}",
	"sender.chat": "dans {{chat}}",
	"sender.reason.not_listed": "pas une personne de la liste",
	"sender.reason.not_addressed": "le message ne nommait pas le bot",
	"ready.notReady": "Pas encore prêt.",
	"ready.fixCount_one": "{{count}} point à corriger",
	"ready.fixCount_other": "{{count}} points à corriger",
	"ready.quiet_one": "{{count}} point à régler",
	"ready.quiet_other": "{{count}} points à régler",
	"ready.quietDone": "Rien à régler",
	"matrix.title": "Qui peut faire quoi",
	"loops.title": "Attentes et minuteries",
	"loops.help": "Ce que l'agent peut faire plus tard dans cette conversation, de lui-même. Cela appartient au bot : un rôle ne le reçoit jamais.",
	"matrix.note": "Les interrupteurs et les cases des rôles sont à vous de régler. Toutes les autres cellules sont calculées à partir de vos réglages actuels, par la même vérification que l'hôte fait à chaque message.",
	"matrix.capability": "Autorisation",
	"matrix.pick": "Type d’expéditeur",
	"matrix.col.on": "Activé pour ce bot",
	"matrix.col.paired": "Personne vérifiée",
	"matrix.col.listed": "Personne de la liste",
	"matrix.col.channel_acts": "Canal : tout le monde agit",
	"matrix.col.channel_member": "Canal : répondre seulement",
	"matrix.col.anyone": "N’importe qui",
	"matrix.state.yes": "Oui",
	"matrix.state.asks": "Demande d’abord",
	"matrix.state.no": "Non",
	"matrix.state.waiting": "En attente d’une personne",
	"matrix.state.off": "Désactivé",
	"matrix.state.unknown": "Inconnu",
	"matrix.row.tools": "Modifier des données dans d’autres services",
	"matrix.toolRow": "{{addon}} : {{tool}}",
	"matrix.detail.label": "Pourquoi une case dit Non ou Désactivé",
	"matrix.detail.none": "Choisissez une cellule pour lire la raison.",
	"matrix.detail.title": "{{capability}} : {{who}}",
	"matrix.reset": "Revenir à l'ensemble habituel",
	"matrix.more": "Détails",
	"matrix.less": "Masquer les détails",
	"matrix.nobodyVerified": "Personne n'est encore vérifié.",
	"who.title": "Qui peut parler au bot",
	"who.onlyChosen": "Seulement les personnes que je choisis",
	"who.anyone": "Toute personne qui peut lui écrire",
	"who.people": "Personnes",
	"who.peopleAndChannels": "Personnes et canaux",
	"who.peopleNone": "Personne n'est encore sur la liste. Ajoutez une personne ci-dessous.",
	"who.channels": "Canaux",
	"who.channelsNote": "Les personnes d'un canal ne peuvent agir que dans ce canal, jamais dans un message direct.",
	"who.add": "Ajouter une personne ou un canal",
	"who.recent": "Personnes qui ont écrit récemment au bot. Cliquez pour les ajouter.",
	"who.addPerson": "Ajouter {{name}}",
	"who.verified": "Vérifiée",
	"who.listed": "Sur la liste",
	"who.verify": "Vérifier",
	"who.verifyPerson": "Vérifier {{name}}",
	"who.remove": "Retirer",
	"who.removePerson": "Retirer {{name}}",
	"who.removeChannel": "Retirer {{name}}",
	"who.levelFor": "Ce que les personnes de {{channel}} peuvent faire",
	"answer.more": "Taille des fichiers et langue des réponses",
	"perm.channelsSwitch": "Aller à l'interrupteur",
	"perm.channelWho": "Qui peut le faire publier",
	"perm.channelWhoFor": "Qui peut faire publier le bot dans {{id}}",
	"perm.channelWho.any": "Quand une personne autorisée le demande",
	"perm.channelWho.verified": "Seulement quand une personne vérifiée le demande",
	"notify.label": "Envoyer mes rappels et les résultats d'exécution à",
	"notify.none": "Nulle part",
	"notify.people": "Personnes",
	"notify.channels": "Canaux",
	"notify.saved": "{{id}} (ID enregistré)",
	"notify.other": "Un autre ID...",
	"notify.otherLabel": "ID du chat",
	"try.title": "Essayer",
	"try.help": "Choisissez qui écrit, où, et ce qu'il demande. C'est le contrôle que l'hôte fait pour chaque message, sur le formulaire tel qu'il est maintenant.",
	"try.noone": "Ajoutez d'abord une personne. Vous pourrez ensuite essayer ce qu'elle peut faire.",
	"try.whoLabel": "Qui",
	"try.placeLabel": "Où",
	"try.actionLabel": "Ce qu'ils demandent",
	"try.someoneIn": "Quelqu'un dans {{channel}}",
	"try.anyone": "N'importe qui",
	"try.role": "Quelqu'un avec le rôle {{role}}",
	"try.dm": "Message privé",
	"try.where.dm": "dans un message privé",
	"try.where.channel": "dans {{channel}}",
	"try.is.paired": "{{who}} est une personne vérifiée et écrit {{where}}.",
	"try.is.listed": "{{who}} est une personne de la liste et écrit {{where}}.",
	"try.is.channelActs": "Quelqu'un dans {{channel}}, où tout le monde peut demander des actions.",
	"try.is.channelAnswers": "Quelqu'un dans {{channel}}, où l'on ne reçoit que des réponses.",
	"try.is.anyone": "Toute personne qui peut écrire au bot est acceptée.",
	"try.is.role": "Une personne avec le rôle {{role}} est acceptée.",
	"try.verdict.allowed": "Autorisé.",
	"try.verdict.asks": "Autorisé, mais il demande d'abord.",
	"try.verdict.refused": "Refusé.",
	"try.loading": "Vérification...",
	"try.error": "Le contrôle n'a pas répondu. Utilisez Réessayer dans le tableau ci-dessus.",
	"try.unknown": "L'hôte n'a pas donné de réponse pour ce type d'expéditeur.",
	"try.note": "Rien n'est envoyé à la plateforme et rien n'est enregistré.",
	"refusals.title": "Refus récents",
	"refusals.help": "Ce que le bot a refusé depuis le démarrage du serveur, le plus récent d'abord. Il contient des ID, des noms et des chats, jamais le texte des messages. Ce journal est gardé en mémoire seulement : il est vide après le redémarrage du serveur.",
	"refusals.none": "Rien n'a été refusé depuis le démarrage du serveur.",
	"refusals.refused": "refusé",
	"refusals.action": "a demandé : {{action}}",
	"refusals.talk": "a écrit au bot",
	"refusals.allow": "Autoriser {{name}}",
	"refusals.act": "Laisser les membres de {{channel}} agir",
	"perm.channelPickOther": "Autre : saisir un ID",
	"perm.channelHint.verified": "Les exécutions planifiées ne peuvent pas publier ici. Choisissez \"Quand une personne autorisée le demande\" pour le leur permettre.",
	"perm.channelHint.any": "Les exécutions planifiées peuvent publier ici.",
	"perm.channelNoListen": "Le bot n'écoute pas dans ce canal, il y publiera seulement.",
	"who.post.none": "Le bot ne peut pas publier ici.",
	"who.post.add": "Laisser aussi le bot publier ici",
	"who.post.addFor": "Laisser aussi le bot publier dans {{name}}",
	"who.post.verified": "Publie ici seulement quand une personne vérifiée le demande.",
	"who.post.any": "Publie ici quand une personne autorisée le demande.",
	"who.post.show": "Afficher le lieu",
	"who.post.showFor": "Afficher le lieu de {{name}}",
	agentLink: "Ouvrir l'agent {{name}}",
	"saved.created": "Connexion ajoutée.",
	"saved.nothing": "Enregistré. Rien n'a changé.",
	"saved.changed": "Enregistré. Modifié : {{what}}.",
	"saved.part.name": "nom",
	"saved.part.agent": "agent",
	"saved.part.who": "qui elle accepte",
	"saved.part.permissions": "permissions",
	"saved.part.approval": "approbation et actions des déclencheurs",
	"saved.part.files": "réglages des fichiers",
	"saved.part.notify": "notifications",
	"saved.dropped.title": "Cette connexion n'autorise plus ces actions, donc les exécutions de ces déclencheurs les perdent :",
	"saved.dropped.item": "{{name}} : {{acts}}",
	"conn.state.running": "Active",
	"conn.state.off": "Désactivée",
	"conn.state.attention": "Demande votre attention",
	"conn.state.ready": "Prête",
	"conn.row.open": "{{name}} : {{state}}. Afficher les détails",
	"conn.row.menu": "Autres actions pour {{name}}",
	"conn.row.testNamed": "Tester {{name}}",
	"conn.fix.token": "Corriger le jeton",
	"conn.reason.noToken": "Aucun jeton n'est enregistré.",
	"conn.reason.duplicate": "Répond au même bot que {{name}}.",
	"conn.reason.testFailed": "Le dernier test a échoué : {{reason}}",
	"conn.kv.service": "Service",
	"conn.kv.accepts": "Accepte",
	"conn.kv.replies": "Réponses",
	"conn.kv.token": "Jeton",
	"conn.kv.saved": "Enregistré",
	"conn.kv.notSaved": "Non enregistré",
	"conn.kv.agents": "Agents",
	"usedBy.count_one": "Utilisée par {{count}} agent",
	"usedBy.count_other": "Utilisée par {{count}} agents",
	"usedBy.none": "Utilisée par aucun agent",
	"conn.pane.lastTest": "Dernier test",
	"conn.pane.never": "Pas encore testée dans ce navigateur.",
	"conn.pane.passed": "Réussi {{when}}.",
	"conn.pane.failed": "Échoué {{when}}.",
	"conn.pane.connection": "Connexion",
	"conn.pane.remove": "Retirer",
	"conn.pane.test": "Tester la connexion",
	"conn.pane.testing": "Test en cours...",
	"conn.sheet.addDesc": "Donnez-lui un nom, ajoutez son jeton et choisissez l'agent qui répond.",
	"conn.sheet.editDesc": "Les changements s'appliquent à l'enregistrement. Un jeton enregistré n'est jamais réaffiché.",
	"conn.sheet.connection": "Connexion",
	"conn.sheet.who": "Qui peut lui parler",
	"conn.sheet.may": "Ce qu'elle peut faire",
	"conn.sheet.replies": "Réponses, fichiers et lieux",
	"conn.sheet.check": "Vérifier ce qu'elle fera",
	"conn.sheet.saveAndTest": "Enregistrer et tester",
	"conn.sheet.saving": "Enregistrement...",
	"conn.sheet.testFailed": "La connexion est enregistrée, mais le test a échoué.",
	"conn.sheet.testFailedNoReason": "Aucune raison n’a été donnée.",
	"conn.sheet.testAgain": "Tester à nouveau",
	"conn.sheet.close": "Fermer",
	"conn.sheet.agentFixed": "Répond avec l'agent {{name}}",
	"conn.preset.label": "Permissions",
	"conn.preset.answer": "Répondre seulement",
	"conn.preset.answerHelp": "Elle répond aux messages. Cette connexion n'ajoute aucune permission propre.",
	"conn.preset.standard": "Standard",
	"conn.preset.standardHelp": "L'ensemble habituel que l'agent possède : {{list}}.",
	"conn.preset.standardNone": "L'ensemble habituel. Cet agent n'en possède aucun.",
	"conn.preset.custom": "Personnalisé",
	"conn.preset.customHelp": "Choisissez chaque permission et qui peut l'utiliser.",
	"conn.preset.note": "Un préréglage n'active jamais une permission sensible. Utilisez Personnalisé pour celles-ci. Les connexions de modules complémentaires que l'agent possède ont leurs propres règles : les personnes vérifiées peuvent toujours utiliser leurs outils d'écriture. Changez cela dans l'agent, sous « Ce qu'il peut utiliser ».",
	"conn.discard.title": "Abandonner les modifications ?",
	"conn.discard.message": "Vous avez modifié cette connexion sans l'enregistrer.",
	"conn.discard.confirm": "Abandonner les modifications",
	"share.label": "Partager",
	"share.button": "Partager {{name}}",
	"share.intro": "Les personnes que vous ajoutez peuvent utiliser cette connexion dans leurs propres conversations et agents. Elles voient son nom et son état, jamais son jeton ni ses réglages. Les messages adressés au bot arrivent toujours à votre agent.",
	"share.roleUse": "Peut utiliser",
	"share.roleUseHelp": "Peut l'utiliser dans ses conversations et ses agents. Ne peut ni voir le jeton, ni la modifier, ni la partager.",
	"shared.title": "Partagées avec vous",
	"shared.text": "D'autres personnes vous permettent d'utiliser ces connexions dans vos conversations et vos agents. Seul leur propriétaire peut les modifier.",
	"shared.on": "À l'écoute",
	"shared.off": "Désactivée",
	"shared.by": "Partagée par {{name}}",
	loginNeedsHost: "Cette version de LocalAI ne peut pas ouvrir la connexion depuis cette page. Mettez LocalAI à jour pour vous connecter ici."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.es.json
var connector_es_default = {
	"answer.title": "Dónde publica y cómo responde",
	"answer.replyLabel": "Mientras el agente trabaja",
	"answer.reply.off": "Escribiendo, y luego la respuesta",
	"answer.reply.progress": "Progreso: las herramientas que usa",
	"answer.reply.stream": "En vivo: la respuesta mientras se escribe",
	"answer.reply.reasoning": "Razonamiento: el razonamiento del modelo, luego la respuesta",
	"answer.replyHelp": "Progreso y En vivo muestran un solo mensaje de trabajo, y la respuesta lo reemplaza. En una plataforma con borradores, En vivo muestra un borrador en un chat privado y la respuesta va después. Una respuesta larga sigue en mensajes nuevos.",
	"answer.replyReasoningHelp": "Razonamiento muestra el razonamiento del modelo, mientras lo escribe, a cada remitente de este enlace. Úsalo solo donde no haya problema.",
	"answer.conversationLabel": "Conversaciones",
	"answer.conversationHelp": "Envía /new (o !new) en la aplicación para empezar un chat nuevo.",
	"answer.conversation.sender": "Un chat por persona",
	"answer.conversation.chat": "Un chat por grupo o canal",
	"answer.conversation.window": "Por persona, nuevo tras un rato de silencio",
	"answer.conversation.thread": "Un chat nuevo por mensaje; las respuestas siguen en él",
	"answer.window": "Tiempo de silencio, en minutos",
	"answer.windowRange": "Usa un número entero del 1 al {{max}}.",
	"answer.languageLabel": "Idioma de las respuestas",
	"answer.languageHelp": "Las notas que el bot escribe por sí mismo, como confirmaciones y rechazos. Las respuestas del modelo siguen el idioma de la conversación.",
	"answer.language.auto": "Automático (el idioma de tu interfaz, si no el del remitente)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Enviar los archivos que crea el agente",
	add: "Añadir",
	more: "Más",
	less: "Menos",
	"answer.filesHelp": "Tras la respuesta, hasta 5 archivos. No se envían programas ni scripts. El límite de tamaño está en Tamaño de archivos e idioma de respuesta.",
	"answer.summary": "Respuestas: {{reply}} · {{conversation}}",
	"answer.short.off": "escribiendo",
	"answer.short.progress": "progreso",
	"answer.short.stream": "respuesta en vivo",
	"answer.short.reasoning": "razonamiento visible",
	"answer.short.sender": "un chat por persona",
	"answer.short.chat": "un chat por grupo",
	"answer.short.window": "chat nuevo tras {{count}} min",
	"answer.short.thread": "un chat por mensaje",
	"approval.title": "Temporizadores y disparadores desde el chat",
	"approval.help": "Cuando el agente prepara algo que se ejecuta más tarde («en 10 minutos», «cada día»), cada ejecución usa el modelo una vez.",
	"approval.mode.ask": "Pregunta antes: el bot lo propone en el chat y la persona responde sí o no",
	"approval.mode.auto": "Se ejecuta al instante: se configura y se le dice a la persona cómo cancelarlo",
	"approval.mode.auto_readonly": "Se ejecuta al instante si las ejecuciones solo leen e informan; si no, pregunta antes",
	"approval.limitsHelp": "Estos límites acotan lo que se prepara sin preguntar. Deja un campo vacío para usar su valor por defecto. Lo que pase de un límite se pregunta.",
	"approval.max_pending": "Máximo de temporizadores y disparadores a la vez",
	"approval.min_gap_minutes": "Mínimo de minutos entre ejecuciones de un disparador recurrente",
	"approval.max_runs_per_day": "Máximo de ejecuciones al día, en total",
	"approval.max_lifetime_days": "Duración máxima, en días",
	"approval.invalid": "Usa un número entero del 1 al {{max}}, o déjalo vacío.",
	"approval.default": "Por defecto: {{value}}.",
	"approval.summary": "Disparadores: {{mode}}",
	"approval.effect": "Propuestas: {{mode}}",
	"approval.effectChange": "Cambios y borrados: {{mode}}",
	"approval.limits": "Límites",
	"approval.acts.title": "Las ejecuciones pueden actuar",
	"approval.acts.help": "Desactivado: las ejecuciones de un disparador creado desde este chat solo leen e informan. Activado: también pueden hacer lo que marques abajo, y solo lo que el agente tiene.",
	"approval.acts.modes": "Pregunta antes: decides tú siempre. Se ejecuta al instante: solo cuando eres una persona verificada y cada acción está marcada aquí.",
	"approval.acts.act.files": "Escribir archivos en las carpetas del agente",
	"approval.acts.act.files.effect": "Una ejecución puede crear y cambiar archivos que guarda el agente.",
	"approval.acts.act.addons": "Usar las acciones de los complementos del agente",
	"approval.acts.act.addons.effect": "Una ejecución puede usar lo que hacen los complementos del agente, incluidos los comandos.",
	"approval.acts.act.send": "Enviar mensajes más allá de donde informa",
	"approval.acts.act.send.effect": "Una ejecución puede escribir por su cuenta en otros chats y canales.",
	"approval.acts.act.spend": "Usar herramientas de pago o externas y la red",
	"approval.acts.act.spend.effect": "Una ejecución puede llamar a servicios fuera de LocalAI, que pueden costar dinero.",
	"approval.acts.lacks": "El agente no tiene esto.",
	"approval.acts.sensitive": "Sensible",
	"approval.effectActs": ", las ejecuciones pueden: {{acts}}",
	"approval.actShort.act.files": "escribir archivos",
	"approval.actShort.act.addons": "usar complementos",
	"approval.actShort.act.send": "enviar mensajes",
	"approval.actShort.act.spend": "usar herramientas de pago o externas",
	"approval.short.ask": "pregunta antes",
	"approval.short.auto": "se ejecuta al instante",
	"approval.short.auto_readonly": "se ejecuta al instante si solo lee",
	"files.title": "Archivos",
	"files.help": "Deja un campo vacío para usar el límite del complemento. Tu límite solo puede ser menor que ese.",
	"files.receiveLabel": "Archivo más grande que lee, en MiB",
	"files.sendLabel": "Archivo más grande que envía, en MiB",
	"files.invalid": "Usa un número mayor que 0.",
	"files.tooHigh": "El complemento permite como máximo {{max}} aquí.",
	"files.now": "Ahora: {{limit}} ({{layer}}).",
	"files.receiveHelp": "Archivos que las personas envían al bot. Un archivo más grande se rechaza, y el bot dice qué límite alcanzó.",
	"files.sendHelp": "Archivos que crea el agente y que el bot devuelve. Un archivo más grande no se envía, y el bot dice qué límite alcanzó.",
	"files.addon.off": "Este complemento no mueve archivos en este sentido, así que no hay nada que ajustar.",
	"files.addon.declared": "El complemento declara hasta {{max}}.",
	"files.addon.open": "El complemento no declara ningún límite, así que se aplica el de la plataforma.",
	"files.host": "Ningún bot puede mover un archivo de más de {{max}}. Un administrador lo fija en la configuración.",
	"files.layer.owner": "límite fijado para este bot",
	"files.layer.addon": "límite del complemento",
	"files.layer.host": "límite de la plataforma",
	"perm.agentLacks": "El agente no tiene esto.",
	"perm.rule": "Las personas de la lista pueden usar los permisos marcados. Los sensibles exigen además una persona verificada.",
	"perm.sensitive": "Solo personas verificadas",
	"perm.sensitiveHelp": "Sensible. Nunca se da a un rol. Solo puede usarlo una persona verificada, y cada uso queda registrado.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Lugar donde el bot puede publicar",
	"perm.channelsHelp": "Lugares donde el agente puede publicar cuando una persona de la lista lo pide, además del chat en el que responde. No decide a quién escucha el bot: mira Canales donde el bot escucha. Máximo {{max}}.",
	"perm.channelsOff": "Activa «Publicar en otros canales» arriba para elegir los lugares donde el bot puede publicar.",
	"perm.channelId": "ID del canal",
	"perm.channelLabel": "Nombre",
	"perm.channelAdd": "Añadir un lugar",
	"perm.channelRemove": "Quitar el lugar {{id}}",
	"perm.remove": "Quitar",
	"perm.channelFull": "La lista está llena.",
	"perm.channelProblem.id": "Cada lugar necesita un ID de 1 a {{max}} bytes, sin espacios.",
	"perm.channelProblem.label": "Un nombre tiene como máximo {{max}} caracteres.",
	"perm.channelProblem.repeat": "Un lugar aparece dos veces.",
	"perm.channelProblem.count": "Máximo {{max}} lugares.",
	"perm.triggersNeed": "Activa Proponer disparadores para usar esto.",
	"pair.start": "Verificar a una persona",
	"pair.startHelp": "Genera un código. Envíalo al bot como mensaje directo desde la cuenta que quieres verificar, en un plazo de diez minutos. El código sirve una sola vez.",
	"pair.needSave": "Guarda primero este bot y luego verifica a una persona.",
	"pair.codeTitle": "Tu código de verificación",
	"pair.codeHelp": "Envía este código al bot como mensaje directo desde la cuenta que quieres verificar. Solo se muestra ahora, sirve una vez y caduca a las {{time}}.",
	"pair.codeGone": "El código caducó. Genera uno nuevo si la persona aún no está verificada.",
	"pair.done": "Verificado: {{sender}}.",
	"pair.dismiss": "Ocultar el código",
	"pair.none": "Nadie está verificado.",
	"pair.expires": "termina {{time}}",
	"pair.full": "Ya hay tres personas verificadas. Quita una para verificar otra.",
	"access.title": "Compruébalo",
	"access.needSave": "Guarda primero este bot para ver a quién rechazó hace poco.",
	"access.refresh": "Actualizar",
	"access.who": "remitente {{senders}}",
	"can.sender.role": "Rol: {{title}}",
	"can.fromForm": "Calculado a partir del formulario tal como está ahora. Guarda para conservar estos ajustes.",
	"can.fromFormNew": "Aún sin guardar. Calculado a partir del formulario tal como está ahora.",
	"can.loading": "Comprobando qué puede hacer este bot",
	"can.stale": "Actualizando",
	"can.errorTitle": "No se pudo comprobar qué puede hacer este bot",
	"can.retry": "Reintentar",
	"can.allowed": "Permitido",
	"can.via.paired": "porque esta persona está verificada",
	"can.via.allowlist": "porque esta persona está en la lista",
	"can.via.agentConnection": "porque esta persona está verificada y el agente está conectado a la app",
	"can.via.role": "mediante el rol {{role}}",
	"can.then": "Aún sin comprobar: {{list}}.",
	"can.then.server": "la configuración del servidor",
	"can.then.tools": "el interruptor Herramientas del agente",
	"can.then.agent": "los permisos del agente",
	"can.then.connection": "los permisos de esta conexión",
	"can.then.sender": "quién envía",
	"can.then.approval": "cómo se confirman las propuestas",
	"can.noMessage": "No permitido.",
	"fix.open_connection": "Mostrar el ajuste",
	"fix.open_agent": "Abrir el agente",
	"fix.open_server_setting": "Abrir Configuración",
	"fix.pair_sender": "Verificar a una persona",
	"fix.add_person": "Añadir una persona",
	"fix.save": "Conservar estos cambios",
	"fix.token": "Pega el token",
	"fix.tokenNew": "Pega un token nuevo",
	"fix.agent": "Elige un agente",
	"fix.usual": "Elige permisos",
	"fix.turnOn": "Activar",
	"fix.newTab": "(se abre en una pestaña nueva)",
	"fix.askAdmin": "Pregunta a un administrador",
	"ready.title": "Estado",
	"ready.checkingSummary": "Comprobando lo que hará el formulario.",
	"ready.allGood": "Todo lo necesario está en su sitio.",
	"ready.showAll": "Mostrar los {{count}}",
	"ready.showProblems": "Mostrar solo lo que necesita atención",
	"ready.checking": "Comprobando.",
	"ready.unchecked": "No se pudo comprobar esto. Mira «Qué puede hacer este bot» más abajo.",
	"ready.row.token": "Token",
	"ready.row.agent": "Agente",
	"ready.row.who": "Quién puede usarlo",
	"ready.row.permissions": "Permisos",
	"ready.row.addons": "Herramientas de complementos",
	"ready.row.triggers": "Disparadores",
	"ready.row.files": "Archivos",
	"ready.row.notify": "Notificaciones",
	"ready.state.ok": "OK",
	"ready.state.attention": "Necesita atención",
	"ready.state.off": "Desactivado",
	"ready.state.after_save": "Tras guardar",
	"ready.state.broken": "No funciona",
	"ready.state.checking": "Comprobando",
	"ready.state.unknown": "Desconocido",
	"ready.token.missing": "Pega el token del bot. Sin él no se recibe nada.",
	"ready.token.newTyped": "El token se comprueba con la plataforma al guardar.",
	"ready.token.typed": "El token nuevo se comprueba con la plataforma al guardar.",
	"ready.token.failed": "La plataforma rechazó el token: {{reason}}",
	"ready.token.checked": "La plataforma aceptó el token. {{bot}}",
	"ready.token.saved": "Hay un token guardado. La plataforma lo aceptó al guardarlo.",
	"ready.agent.none": "Elige el agente que responde.",
	"ready.agent.credentialsOnly": "Sin agente. Esta conexión solo guarda las credenciales y no responde a ningún mensaje.",
	"ready.agent.gone": "El agente elegido ya no está en tu lista. Elige otro.",
	"ready.agent.noModel": "{{name}} no tiene modelo, así que no puede responder. Dale uno.",
	"ready.agent.ok": "{{name}} responde, con el modelo {{model}}.",
	"ready.agent.okUnknown": "Hay un agente elegido.",
	"ready.who.anyone": "Cualquiera que pueda escribir al bot puede usarlo.",
	"ready.who.nobody": "Aún no hay nadie en la lista, así que el bot ignora todos los mensajes. Añade una persona.",
	"ready.who.channelsOnly": "Solo hay canales en la lista. Las personas de un canal pueden chatear, pero usan los permisos marcados solo donde el canal está en Dejar que todos aquí pidan acciones.",
	"ready.who.listed_one": "Hay {{count}} persona o chat en la lista.",
	"ready.who.listed_other": "Hay {{count}} personas o chats en la lista.",
	"ready.who.mixed": "Hay {{count}} entradas en la lista: personas y canales.",
	"ready.perm.none": "No hay ningún permiso activado. Los remitentes pueden chatear, y nada más.",
	"ready.perm.noneSaved": "No hay ningún permiso activado, así que archivos, memoria, disparadores y publicaciones están desactivados.",
	"ready.perm.onlyOwnRows": "Los demás permisos están desactivados. Los disparadores y los archivos están más abajo.",
	"ready.perm.ok_one": "{{count}} permiso está activado y un remitente puede usarlo.",
	"ready.perm.ok_other": "{{count}} permisos están activados y un remitente puede usarlos.",
	"ready.perm.dead_one": "Nadie puede usar {{names}}. {{message}}",
	"ready.perm.dead_other": "Nadie puede usar {{count}} de los permisos activados: {{names}}. El primero: {{message}}",
	"ready.addons.off": "El agente tiene las herramientas de {{addon}} {{tools}}, pero no puede usarlas en este chat hasta que actives \"{{permission}}\".",
	"ready.addons.blocked": "El agente tiene las herramientas de {{addon}} {{tools}}, pero están retenidas. {{message}}",
	"ready.addons.ok": "El agente puede usar las herramientas de {{addon}} {{tools}} en este chat.",
	"ready.addons.paired": "Las personas verificadas pueden usar las herramientas de escritura de {{addon}} ({{tools}}) en este chat, porque el agente está conectado a {{connection}} (modo de escritura: {{mode}}). Las personas de la lista que no están verificadas necesitan \"{{permission}}\".",
	"ready.addons.removed": "Desactivaste \"{{permission}}\", así que nadie puede usar las herramientas de escritura de {{addon}} ({{tools}}) en este chat, ni siquiera las personas verificadas. Actívalo para recuperarlas; también las obtienen las personas de la lista que no están verificadas.",
	"ready.addons.modeOff": "El agente tiene las herramientas de escritura de {{addon}} ({{tools}}), pero están retenidas porque el modo de escritura de {{connection}} está desactivado. Cambia el modo de escritura en esa conexión.",
	"ready.addons.mode.auto": "se ejecuta al instante",
	"ready.addons.mode.propose": "pregunta antes",
	"ready.triggers.off": "El agente no puede crear recordatorios ni tareas programadas aquí.",
	"ready.triggers.blocked": "Los disparadores están activados y no se pueden usar. {{message}}",
	"ready.triggers.ok.ask": "El agente puede proponer disparadores. Tú confirmas cada uno antes de que empiece.",
	"ready.triggers.ok.auto": "El agente puede proponer disparadores. Empiezan al instante, sin preguntarte.",
	"ready.triggers.ok.auto_readonly": "El agente puede proponer disparadores. Uno que solo lee empieza al instante; confirmas cualquier otro.",
	"ready.files.offReceive": "Los remitentes no pueden enviar archivos al agente.",
	"ready.files.offBoth": "Los remitentes no pueden enviar archivos al agente, y el bot no devuelve ninguno.",
	"ready.files.blocked": "La recepción de archivos está activada y no se puede usar. {{message}}",
	"ready.files.ok": "Los remitentes pueden enviar archivos al agente, y el bot puede devolver archivos.",
	"ready.files.okReceive": "Los remitentes pueden enviar archivos al agente. El bot no devuelve ninguno.",
	"ready.notify.off": "Ningún chat recibe avisos de este bot.",
	"ready.notify.ok": "Los avisos van al chat {{chat}}.",
	dismiss: "Descartar",
	credentialsOnly: "Solo credenciales",
	agentCredentialsOnly: "Sin agente (solo credenciales)",
	agentOptionalHint: "Opcional. Sin agente, esta conexión solo guarda el token, la lista de repositorios y el modo de escritura para tus chats. No responde a ningún mensaje. Elige un agente para que escuche.",
	"sender.line_one": "{{name}} · {{count}} mensaje · {{id}}",
	"sender.line_other": "{{name}} · {{count}} mensajes · {{id}}",
	"ready.blocker.nobodyLetIn": "Aún no se deja entrar a nadie.",
	"ready.blocker.nobodyPaired": "Esto necesita una persona verificada, y aún no hay nadie verificado.",
	optional: "opcional",
	"approvals.title": "Herramientas que se ejecutan al instante",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "Pregunta antes",
	"approvals.state.runs": "Se ejecuta al instante",
	"approvals.state.idle": "Configurada para ejecutarse al instante, no hace nada ahora",
	"approvals.state.other": "Sigue preguntando antes a este remitente",
	"approvals.line.asks": "Una tarjeta está esperando tu confirmación.",
	"approvals.line.runs": "Para los chats del propietario y para las personas verificadas. A los demás se les sigue preguntando.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "Solo el propietario y una persona verificada se saltan la tarjeta. A este tipo de remitente se le pregunta.",
	"dup.text": "Este bot también está conectado como {{name}}. Ambas conexiones responderán al mismo mensaje.",
	"dup.turnOff": "Desactivar esta",
	"dup.openOther": "Abrir {{name}}",
	"dup.saveAnyway": "Guardar de todos modos",
	"dup.goBack": "Volver",
	"dup.confirmHelp": "Guarda de todos modos solo si quieres recibir dos respuestas a cada mensaje.",
	"access.noteSave.title": "Notas",
	"access.noteSave.now": "Guarda las notas al momento y avisa, con Deshacer",
	"access.noteSave.ask": "Las notas de este tipo de remitente esperan al propietario",
	"trust.answer": "Solo responder",
	"trust.act": "Dejar que todos aquí pidan acciones",
	"ready.row.channelTrust": "Canales donde el bot escucha",
	"ready.row.postTo": "Lugar donde el bot puede publicar",
	"ready.channelTrust.act": "Las personas de {{channels}} pueden pedir acciones habituales. Las sensibles siguen necesitando una persona verificada.",
	"ready.channelTrust.answer": "Las personas de {{channels}} no pueden usar acciones: ponlo en Dejar que todos aquí pidan acciones.",
	"ready.channelTrust.noCaps": "No hay nada marcado en permisos, así que los archivos y otras acciones se rechazan incluso donde todos pueden pedir.",
	"fix.trust": "Configurar el canal",
	"can.via.channel": "Todos en este canal pueden pedirlo porque el canal está en Dejar que todos aquí pidan acciones",
	"ready.postTo_one": "El bot puede publicar en 1 lugar más cuando una persona de la lista lo pide. Eso no da confianza a las personas que hay en él.",
	"ready.postTo_other": "El bot puede publicar en {{count}} lugares más cuando una persona de la lista lo pide. Eso no da confianza a las personas que hay en ellos.",
	"access.toolsTitle": "Llamadas a herramientas de complementos",
	"access.toolsHelp": "Las últimas llamadas a herramientas de complementos que usaron esta conexión o llegaron por este bot, las más recientes primero, como máximo 20. Contienen nombres de herramientas y motivos, nunca lo que se pidió o respondió. Se reinician al reiniciar el servidor.",
	"access.toolsNone": "Aún no hay llamadas.",
	"access.outcome.ok": "correcta",
	"access.outcome.held": "retenida",
	"access.outcome.denied": "denegada",
	"access.outcome.error": "fallida",
	"ready.addons.confirmChat": "Una persona verificada puede confirmar en el chat las escrituras de {{addon}}: el bot escribe cada una allí y responde sí o no.",
	"access.outcome.confirmed": "confirmada",
	"access.outcome.cancelled": "cancelada",
	"access.outcome.expired": "caducada",
	"access.askedBy": "pedida por {{sender}}",
	"access.chat": "en {{chat}}",
	"sender.chat": "en {{chat}}",
	"sender.reason.not_listed": "no es una persona de la lista",
	"sender.reason.not_addressed": "el mensaje no nombraba al bot",
	"ready.notReady": "Todavía no está listo.",
	"ready.fixCount_one": "{{count}} cosa por corregir",
	"ready.fixCount_other": "{{count}} cosas por corregir",
	"ready.quiet_one": "{{count}} cosa por configurar",
	"ready.quiet_other": "{{count}} cosas por configurar",
	"ready.quietDone": "No queda nada por configurar",
	"matrix.title": "Quién puede hacer qué",
	"loops.title": "Esperas y temporizadores",
	"loops.help": "Lo que el agente puede hacer más tarde en este chat por sí solo. Pertenecen al bot: un rol nunca los recibe.",
	"matrix.note": "Los interruptores y las casillas de los roles los ajustas tú. Cada otra celda se calcula a partir de tus ajustes actuales, con la misma comprobación que el host hace en cada mensaje.",
	"matrix.capability": "Permiso",
	"matrix.pick": "Tipo de remitente",
	"matrix.col.on": "Activado para este bot",
	"matrix.col.paired": "Persona verificada",
	"matrix.col.listed": "Persona de la lista",
	"matrix.col.channel_acts": "Canal: todos actúan",
	"matrix.col.channel_member": "Canal: solo responder",
	"matrix.col.anyone": "Cualquiera",
	"matrix.state.yes": "Sí",
	"matrix.state.asks": "Pregunta antes",
	"matrix.state.no": "No",
	"matrix.state.waiting": "Esperando a una persona",
	"matrix.state.off": "Desactivado",
	"matrix.state.unknown": "No se sabe",
	"matrix.row.tools": "Cambiar cosas en servicios conectados",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Por qué una celda dice No o Desactivado",
	"matrix.detail.none": "Elige una celda para leer el motivo.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Restablecer el conjunto habitual",
	"matrix.more": "Detalles",
	"matrix.less": "Ocultar los detalles",
	"matrix.nobodyVerified": "Todavía nadie está verificado.",
	"who.title": "Quién puede hablar con el bot",
	"who.onlyChosen": "Solo las personas que yo elija",
	"who.anyone": "Cualquiera que pueda escribirle",
	"who.people": "Personas",
	"who.peopleAndChannels": "Personas y canales",
	"who.peopleNone": "Todavía no hay nadie en la lista. Añade una persona abajo.",
	"who.channels": "Canales",
	"who.channelsNote": "Las personas de un canal solo pueden actuar dentro de ese canal, nunca en un mensaje directo.",
	"who.add": "Añadir una persona o un canal",
	"who.recent": "Personas que escribieron al bot hace poco. Haz clic para añadirlas.",
	"who.addPerson": "Añadir {{name}}",
	"who.verified": "Verificada",
	"who.listed": "En la lista",
	"who.verify": "Verificar",
	"who.verifyPerson": "Verificar a {{name}}",
	"who.remove": "Quitar",
	"who.removePerson": "Quitar a {{name}}",
	"who.removeChannel": "Quitar {{name}}",
	"who.levelFor": "Qué pueden hacer las personas en {{channel}}",
	"answer.more": "Tamaño de archivos e idioma de respuesta",
	"perm.channelsSwitch": "Ir al interruptor",
	"perm.channelWho": "Quién puede hacer que publique",
	"perm.channelWhoFor": "Quién puede hacer que el bot publique en {{id}}",
	"perm.channelWho.any": "Cuando lo pide cualquier persona permitida",
	"perm.channelWho.verified": "Solo cuando lo pide una persona verificada",
	"notify.label": "Enviar mis recordatorios y resultados de ejecución a",
	"notify.none": "A ningún sitio",
	"notify.people": "Personas",
	"notify.channels": "Canales",
	"notify.saved": "{{id}} (ID guardado)",
	"notify.other": "Otro ID...",
	"notify.otherLabel": "ID del chat",
	"try.title": "Pruébalo",
	"try.help": "Elige quién escribe, dónde y qué pide. Ejecuta la comprobación que hace el host con cada mensaje, sobre el formulario tal como está ahora.",
	"try.noone": "Añade primero a una persona. Luego podrás probar qué puede hacer.",
	"try.whoLabel": "Quién",
	"try.placeLabel": "Dónde",
	"try.actionLabel": "Qué piden",
	"try.someoneIn": "Alguien en {{channel}}",
	"try.anyone": "Cualquiera",
	"try.role": "Alguien con el rol {{role}}",
	"try.dm": "Mensaje directo",
	"try.where.dm": "en un mensaje directo",
	"try.where.channel": "en {{channel}}",
	"try.is.paired": "{{who}} es una persona verificada y escribe {{where}}.",
	"try.is.listed": "{{who}} es una persona de la lista y escribe {{where}}.",
	"try.is.channelActs": "Alguien en {{channel}}, donde todos pueden pedir acciones.",
	"try.is.channelAnswers": "Alguien en {{channel}}, donde solo se reciben respuestas.",
	"try.is.anyone": "Se acepta a cualquiera que pueda escribir al bot.",
	"try.is.role": "Se acepta a una persona con el rol {{role}}.",
	"try.verdict.allowed": "Permitido.",
	"try.verdict.asks": "Permitido, pero pregunta primero.",
	"try.verdict.refused": "Rechazado.",
	"try.loading": "Comprobando...",
	"try.error": "La comprobación no respondió. Usa Reintentar en la tabla de arriba.",
	"try.unknown": "El host no dio respuesta para este tipo de remitente.",
	"try.note": "No se envía nada a la plataforma y no se guarda nada.",
	"refusals.title": "Rechazos recientes",
	"refusals.help": "Lo que el bot rechazó desde que arrancó el servidor, lo más reciente primero. Contiene ID, nombres y chats, nunca el texto de los mensajes. Este registro solo está en memoria: queda vacío cuando el servidor se reinicia.",
	"refusals.none": "Nada rechazado desde que arrancó el servidor.",
	"refusals.refused": "rechazado",
	"refusals.action": "pidió: {{action}}",
	"refusals.talk": "escribió al bot",
	"refusals.allow": "Permitir a {{name}}",
	"refusals.act": "Permitir que los miembros de {{channel}} actúen",
	"perm.channelPickOther": "Otro: escribir un ID",
	"perm.channelHint.verified": "Las ejecuciones programadas no pueden publicar aquí. Elige \"Cuando cualquier persona permitida lo pide\" para permitírselo.",
	"perm.channelHint.any": "Las ejecuciones programadas pueden publicar aquí.",
	"perm.channelNoListen": "El bot no escucha en este canal, así que solo publicará allí.",
	"who.post.none": "El bot no puede publicar aquí.",
	"who.post.add": "Que el bot también publique aquí",
	"who.post.addFor": "Que el bot también publique en {{name}}",
	"who.post.verified": "Publica aquí solo cuando lo pide una persona verificada.",
	"who.post.any": "Publica aquí cuando lo pide cualquier persona permitida.",
	"who.post.show": "Mostrar el lugar",
	"who.post.showFor": "Mostrar el lugar de {{name}}",
	agentLink: "Abrir el agente {{name}}",
	"saved.created": "Conexión añadida.",
	"saved.nothing": "Guardado. Sin cambios.",
	"saved.changed": "Guardado. Cambiado: {{what}}.",
	"saved.part.name": "nombre",
	"saved.part.agent": "agente",
	"saved.part.who": "a quién acepta",
	"saved.part.permissions": "permisos",
	"saved.part.approval": "aprobación y acciones de los triggers",
	"saved.part.files": "ajustes de archivos",
	"saved.part.notify": "notificaciones",
	"saved.dropped.title": "Esta conexión ya no permite estas acciones, así que las ejecuciones de estos triggers las pierden:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "En marcha",
	"conn.state.off": "Apagada",
	"conn.state.attention": "Requiere atención",
	"conn.state.ready": "Lista",
	"conn.row.open": "{{name}}: {{state}}. Mostrar detalles",
	"conn.row.menu": "Más acciones para {{name}}",
	"conn.row.testNamed": "Probar {{name}}",
	"conn.fix.token": "Corregir el token",
	"conn.reason.noToken": "No hay ningún token guardado.",
	"conn.reason.duplicate": "Responde con el mismo bot que {{name}}.",
	"conn.reason.testFailed": "La última prueba falló: {{reason}}",
	"conn.kv.service": "Servicio",
	"conn.kv.accepts": "Acepta",
	"conn.kv.replies": "Respuestas",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Guardado",
	"conn.kv.notSaved": "Sin guardar",
	"conn.kv.agents": "Agentes",
	"usedBy.count_one": "Usada por {{count}} agente",
	"usedBy.count_other": "Usada por {{count}} agentes",
	"usedBy.none": "Ningún agente la usa",
	"conn.pane.lastTest": "Última prueba",
	"conn.pane.never": "Aún no se ha probado en este navegador.",
	"conn.pane.passed": "Superada {{when}}.",
	"conn.pane.failed": "Fallida {{when}}.",
	"conn.pane.connection": "Conexión",
	"conn.pane.remove": "Quitar",
	"conn.pane.test": "Probar la conexión",
	"conn.pane.testing": "Probando...",
	"conn.sheet.addDesc": "Ponle un nombre, añade su token y elige el agente que responde.",
	"conn.sheet.editDesc": "Los cambios se aplican al guardar. Un token guardado nunca se vuelve a mostrar.",
	"conn.sheet.connection": "Conexión",
	"conn.sheet.who": "Quién puede hablarle",
	"conn.sheet.may": "Qué puede hacer",
	"conn.sheet.replies": "Respuestas, archivos y lugares",
	"conn.sheet.check": "Comprobar qué hará",
	"conn.sheet.saveAndTest": "Guardar y probar",
	"conn.sheet.saving": "Guardando...",
	"conn.sheet.testFailed": "La conexión está guardada, pero la prueba falló.",
	"conn.sheet.testFailedNoReason": "No se indicó ningún motivo.",
	"conn.sheet.testAgain": "Probar de nuevo",
	"conn.sheet.close": "Cerrar",
	"conn.sheet.agentFixed": "Responde con el agente {{name}}",
	"conn.preset.label": "Permisos",
	"conn.preset.answer": "Solo responder",
	"conn.preset.answerHelp": "Responde a los mensajes. Esta conexión no añade ningún permiso propio.",
	"conn.preset.standard": "Estándar",
	"conn.preset.standardHelp": "El conjunto habitual que tiene el agente: {{list}}.",
	"conn.preset.standardNone": "El conjunto habitual. Este agente no tiene ninguno.",
	"conn.preset.custom": "Personalizado",
	"conn.preset.customHelp": "Elige cada permiso y quién puede usarlo.",
	"conn.preset.note": "Un ajuste predefinido nunca activa un permiso sensible. Usa Personalizado para esos. Las conexiones de complementos que tiene el agente tienen sus propias reglas: las personas verificadas aún pueden usar sus herramientas de escritura. Cámbialo en el agente, en \"Qué puede usar\".",
	"conn.discard.title": "¿Descartar los cambios?",
	"conn.discard.message": "Has cambiado esta conexión y no la has guardado.",
	"conn.discard.confirm": "Descartar cambios",
	"share.label": "Compartir",
	"share.button": "Compartir {{name}}",
	"share.intro": "Las personas que añadas pueden usar esta conexión en sus propios chats y agentes. Ven su nombre y su estado, nunca su token ni sus ajustes. Los mensajes al bot siguen llegando a tu agente.",
	"share.roleUse": "Puede usar",
	"share.roleUseHelp": "Puede usarla en sus chats y agentes. No puede ver el token, cambiarla ni compartirla.",
	"shared.title": "Compartidas contigo",
	"shared.text": "Otras personas te dejan usar estas conexiones en tus chats y agentes. Solo su propietario puede cambiarlas.",
	"shared.on": "Escuchando",
	"shared.off": "Apagada",
	"shared.by": "Compartida por {{name}}",
	loginNeedsHost: "Esta versión de LocalAI no puede iniciar sesión desde esta página. Actualiza LocalAI para conectar aquí."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.de.json
var connector_de_default = {
	"answer.title": "Wo es schreibt und wie es antwortet",
	"answer.replyLabel": "Während der Agent arbeitet",
	"answer.reply.off": "Schreibanzeige, dann die Antwort",
	"answer.reply.progress": "Fortschritt: die genutzten Werkzeuge",
	"answer.reply.stream": "Live: die Antwort beim Schreiben",
	"answer.reply.reasoning": "Denken: die Gedanken des Modells, dann die Antwort",
	"answer.replyHelp": "Fortschritt und Live zeigen eine Arbeitsnachricht, die die Antwort am Ende ersetzt. Auf einer Plattform mit Entwürfen zeigt Live in einem privaten Chat stattdessen einen Entwurf, danach folgt die Antwort. Eine lange Antwort geht in neuen Nachrichten weiter.",
	"answer.replyReasoningHelp": "Denken zeigt jedem Absender dieser Anbindung die Gedanken des Modells, während sie entstehen. Nutze es nur, wo das in Ordnung ist.",
	"answer.conversationLabel": "Unterhaltungen",
	"answer.conversationHelp": "Sende /new (oder !new) in der App, um einen neuen Chat zu starten.",
	"answer.conversation.sender": "Ein Chat pro Person",
	"answer.conversation.chat": "Ein Chat pro Gruppe oder Kanal",
	"answer.conversation.window": "Pro Person, neu nach einer Pause",
	"answer.conversation.thread": "Neuer Chat pro Nachricht; Antworten laufen weiter",
	"answer.window": "Pause in Minuten",
	"answer.windowRange": "Gib eine ganze Zahl von 1 bis {{max}} ein.",
	"answer.languageLabel": "Antwortsprache",
	"answer.languageHelp": "Die Hinweise, die der Bot selbst schreibt, etwa Bestätigungen und Absagen. Die Antworten des Modells folgen der Sprache der Unterhaltung.",
	"answer.language.auto": "Automatisch (Sprache deiner Oberfläche, sonst die des Absenders)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Dateien senden, die der Agent erstellt",
	add: "Hinzufügen",
	more: "Mehr",
	less: "Weniger",
	"answer.filesHelp": "Nach der Antwort bis zu 5 Dateien. Programme und Skripte werden nicht gesendet. Das Größenlimit steht unter Dateigrößen und Antwortsprache.",
	"answer.summary": "Antworten: {{reply}} · {{conversation}}",
	"answer.short.off": "Schreibanzeige",
	"answer.short.progress": "Fortschritt",
	"answer.short.stream": "Live-Antwort",
	"answer.short.reasoning": "Denken sichtbar",
	"answer.short.sender": "ein Chat pro Person",
	"answer.short.chat": "ein Chat pro Gruppe",
	"answer.short.window": "neuer Chat nach {{count}} Min.",
	"answer.short.thread": "ein Chat pro Nachricht",
	"approval.title": "Timer und Trigger aus dem Chat",
	"approval.help": "Richtet der Agent etwas ein, das später läuft („in 10 Minuten“, „jeden Tag“), ist jeder Lauf ein Modelllauf.",
	"approval.mode.ask": "Fragt zuerst: Der Bot schlägt es im Chat vor und die Person antwortet mit Ja oder Nein",
	"approval.mode.auto": "Läuft sofort: Es wird eingerichtet, und die Person erfährt, wie sie es abbricht",
	"approval.mode.auto_readonly": "Läuft sofort, wenn die Läufe nur lesen und berichten; sonst fragt er zuerst",
	"approval.limitsHelp": "Diese Limits begrenzen, was ohne Rückfrage eingerichtet wird. Lass ein Feld leer, um den Standardwert zu nutzen. Alles über einem Limit wird stattdessen erfragt.",
	"approval.max_pending": "Höchstzahl gleichzeitiger Timer und Trigger",
	"approval.min_gap_minutes": "Mindestabstand in Minuten zwischen Läufen eines wiederkehrenden Triggers",
	"approval.max_runs_per_day": "Höchstzahl Läufe pro Tag, insgesamt",
	"approval.max_lifetime_days": "Längste Lebensdauer in Tagen",
	"approval.invalid": "Gib eine ganze Zahl von 1 bis {{max}} ein oder lass das Feld leer.",
	"approval.default": "Standard: {{value}}.",
	"approval.summary": "Trigger: {{mode}}",
	"approval.effect": "Vorschläge: {{mode}}",
	"approval.effectChange": "Änderungen und Löschungen: {{mode}}",
	"approval.limits": "Limits",
	"approval.acts.title": "Läufe dürfen handeln",
	"approval.acts.help": "Aus: Die Läufe eines Triggers, der aus diesem Chat entsteht, lesen und berichten nur. An: Sie dürfen auch tun, was du unten ankreuzt, und nur das, was der Agent hat.",
	"approval.acts.modes": "Fragt zuerst: Du entscheidest immer. Läuft sofort: nur wenn du eine verifizierte Person bist und jede Handlung hier angekreuzt ist.",
	"approval.acts.act.files": "Dateien in den Ordnern des Agenten schreiben",
	"approval.acts.act.files.effect": "Ein Lauf kann Dateien des Agenten erstellen und ändern.",
	"approval.acts.act.addons": "Die Aktionen der Add-ons des Agenten nutzen",
	"approval.acts.act.addons.effect": "Ein Lauf kann nutzen, was die Add-ons des Agenten können, auch Befehle.",
	"approval.acts.act.send": "Nachrichten über den Berichtsort hinaus senden",
	"approval.acts.act.send.effect": "Ein Lauf kann von sich aus in andere Chats und Kanäle schreiben.",
	"approval.acts.act.spend": "Kostenpflichtige oder externe Werkzeuge und das Netzwerk nutzen",
	"approval.acts.act.spend.effect": "Ein Lauf kann Dienste außerhalb von LocalAI aufrufen, was Geld kosten kann.",
	"approval.acts.lacks": "Der Agent hat das nicht.",
	"approval.acts.sensitive": "Sensibel",
	"approval.effectActs": ", Läufe dürfen: {{acts}}",
	"approval.actShort.act.files": "Dateien schreiben",
	"approval.actShort.act.addons": "Add-ons nutzen",
	"approval.actShort.act.send": "Nachrichten senden",
	"approval.actShort.act.spend": "kostenpflichtige oder externe Werkzeuge nutzen",
	"approval.short.ask": "fragt zuerst",
	"approval.short.auto": "läuft sofort",
	"approval.short.auto_readonly": "läuft sofort, wenn nur lesend",
	"files.title": "Dateien",
	"files.help": "Lass ein Feld leer, um das Limit des Add-ons zu nutzen. Dein Limit kann nur niedriger sein.",
	"files.receiveLabel": "Größte Datei, die gelesen wird, in MiB",
	"files.sendLabel": "Größte Datei, die gesendet wird, in MiB",
	"files.invalid": "Gib eine Zahl größer als 0 ein.",
	"files.tooHigh": "Das Add-on erlaubt hier höchstens {{max}}.",
	"files.now": "Jetzt: {{limit}} ({{layer}}).",
	"files.receiveHelp": "Dateien, die Personen an den Bot senden. Eine größere Datei wird abgelehnt, und der Bot sagt, welches Limit er erreicht hat.",
	"files.sendHelp": "Dateien, die der Agent erstellt und der Bot zurückschickt. Eine größere Datei wird nicht gesendet, und der Bot sagt, welches Limit er erreicht hat.",
	"files.addon.off": "Dieses Add-on bewegt in dieser Richtung keine Dateien, daher gibt es nichts einzustellen.",
	"files.addon.declared": "Das Add-on gibt bis zu {{max}} an.",
	"files.addon.open": "Das Add-on gibt kein Limit an, daher gilt das Limit der Plattform.",
	"files.host": "Kein Bot kann eine Datei über {{max}} bewegen. Ein Administrator legt das in den Einstellungen fest.",
	"files.layer.owner": "für diesen Bot gesetztes Limit",
	"files.layer.addon": "Limit des Add-ons",
	"files.layer.host": "Limit der Plattform",
	"perm.agentLacks": "Der Agent hat das nicht.",
	"perm.rule": "Gelistete Personen können die angekreuzten Berechtigungen nutzen. Sensible brauchen zusätzlich eine verifizierte Person.",
	"perm.sensitive": "Nur verifizierte Personen",
	"perm.sensitiveHelp": "Sensibel. Wird nie an eine Rolle vergeben. Nur eine verifizierte Person kann sie nutzen, und jede Nutzung wird aufgezeichnet.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Ort, an dem der Bot posten darf",
	"perm.channelsHelp": "Orte, an die der Agent auf Wunsch einer gelisteten Person posten darf, zusätzlich zum Chat, in dem er antwortet. Das bestimmt nicht, wem der Bot zuhört: siehe Kanäle, in denen der Bot zuhört. Höchstens {{max}}.",
	"perm.channelsOff": "Schalte oben „In andere Kanäle posten“ ein, um die Orte zu wählen, an denen der Bot posten darf.",
	"perm.channelId": "Kanal-ID",
	"perm.channelLabel": "Name",
	"perm.channelAdd": "Ort hinzufügen",
	"perm.channelRemove": "Ort {{id}} entfernen",
	"perm.remove": "Entfernen",
	"perm.channelFull": "Die Liste ist voll.",
	"perm.channelProblem.id": "Jeder Ort braucht eine ID von 1 bis {{max}} Bytes ohne Leerzeichen.",
	"perm.channelProblem.label": "Ein Name hat höchstens {{max}} Zeichen.",
	"perm.channelProblem.repeat": "Ein Ort steht doppelt in der Liste.",
	"perm.channelProblem.count": "Höchstens {{max}} Orte.",
	"perm.triggersNeed": "Schalte „Trigger vorschlagen“ ein, um das zu nutzen.",
	"pair.start": "Person verifizieren",
	"pair.startHelp": "Erzeugt einen Code. Sende ihn innerhalb von zehn Minuten als Direktnachricht von dem zu verifizierenden Konto an den Bot. Der Code gilt einmal.",
	"pair.needSave": "Speichere zuerst diesen Bot, dann verifiziere eine Person.",
	"pair.codeTitle": "Dein Verifizierungscode",
	"pair.codeHelp": "Sende diesen Code als Direktnachricht von dem zu verifizierenden Konto an den Bot. Er wird nur jetzt angezeigt, gilt einmal und läuft um {{time}} ab.",
	"pair.codeGone": "Der Code ist abgelaufen. Erzeuge einen neuen, falls die Person noch nicht verifiziert ist.",
	"pair.done": "Verifiziert: {{sender}}.",
	"pair.dismiss": "Code ausblenden",
	"pair.none": "Niemand ist verifiziert.",
	"pair.expires": "endet {{time}}",
	"pair.full": "Drei Personen sind verifiziert. Entferne eine, um eine weitere zu verifizieren.",
	"access.title": "Prüfen",
	"access.needSave": "Speichere diesen Bot zuerst, um zu sehen, wen er zuletzt abgelehnt hat.",
	"access.refresh": "Aktualisieren",
	"access.who": "Absender {{senders}}",
	"can.sender.role": "Rolle: {{title}}",
	"can.fromForm": "Berechnet aus dem Formular in seinem jetzigen Stand. Speichere, um diese Einstellungen zu behalten.",
	"can.fromFormNew": "Noch nicht gespeichert. Berechnet aus dem Formular in seinem jetzigen Stand.",
	"can.loading": "Es wird geprüft, was dieser Bot kann",
	"can.stale": "Wird aktualisiert",
	"can.errorTitle": "Es konnte nicht geprüft werden, was dieser Bot kann",
	"can.retry": "Erneut versuchen",
	"can.allowed": "Erlaubt",
	"can.via.paired": "weil diese Person verifiziert ist",
	"can.via.allowlist": "weil diese Person gelistet ist",
	"can.via.agentConnection": "weil diese Person verifiziert ist und der Agent mit dem Add-on verbunden ist",
	"can.via.role": "über die Rolle {{role}}",
	"can.then": "Noch nicht geprüft: {{list}}.",
	"can.then.server": "die Servereinstellungen",
	"can.then.tools": "der Werkzeug-Schalter des Agenten",
	"can.then.agent": "die Berechtigungen des Agenten",
	"can.then.connection": "die Berechtigungen dieser Verbindung",
	"can.then.sender": "wer sendet",
	"can.then.approval": "wie Vorschläge bestätigt werden",
	"can.noMessage": "Nicht erlaubt.",
	"fix.open_connection": "Einstellung anzeigen",
	"fix.open_agent": "Agent öffnen",
	"fix.open_server_setting": "Einstellungen öffnen",
	"fix.pair_sender": "Person verifizieren",
	"fix.add_person": "Person hinzufügen",
	"fix.save": "Änderungen behalten",
	"fix.token": "Token einfügen",
	"fix.tokenNew": "Neues Token einfügen",
	"fix.agent": "Agent wählen",
	"fix.usual": "Berechtigungen wählen",
	"fix.turnOn": "Einschalten",
	"fix.newTab": "(öffnet in einem neuen Tab)",
	"fix.askAdmin": "Administrator fragen",
	"ready.title": "Status",
	"ready.checkingSummary": "Es wird geprüft, was das Formular bewirkt.",
	"ready.allGood": "Alles Nötige ist vorhanden.",
	"ready.showAll": "Alle {{count}} anzeigen",
	"ready.showProblems": "Nur anzeigen, was Aufmerksamkeit braucht",
	"ready.checking": "Wird geprüft.",
	"ready.unchecked": "Das konnte nicht geprüft werden. Siehe unten „Was dieser Bot kann“.",
	"ready.row.token": "Token",
	"ready.row.agent": "Agent",
	"ready.row.who": "Wer ihn nutzen darf",
	"ready.row.permissions": "Berechtigungen",
	"ready.row.addons": "Add-on-Werkzeuge",
	"ready.row.triggers": "Trigger",
	"ready.row.files": "Dateien",
	"ready.row.notify": "Benachrichtigungen",
	"ready.state.ok": "OK",
	"ready.state.attention": "Braucht Aufmerksamkeit",
	"ready.state.off": "Aus",
	"ready.state.after_save": "Nach dem Speichern",
	"ready.state.broken": "Funktioniert nicht",
	"ready.state.checking": "Wird geprüft",
	"ready.state.unknown": "Unbekannt",
	"ready.token.missing": "Füge das Token des Bots ein. Ohne es wird nichts empfangen.",
	"ready.token.newTyped": "Das Token wird beim Speichern bei der Plattform geprüft.",
	"ready.token.typed": "Das neue Token wird beim Speichern bei der Plattform geprüft.",
	"ready.token.failed": "Die Plattform hat das Token abgelehnt: {{reason}}",
	"ready.token.checked": "Die Plattform hat das Token akzeptiert. {{bot}}",
	"ready.token.saved": "Ein Token ist gespeichert. Die Plattform hat es beim Speichern akzeptiert.",
	"ready.agent.none": "Wähle den Agenten, der antwortet.",
	"ready.agent.credentialsOnly": "Kein Agent. Diese Verbindung hält nur die Zugangsdaten und beantwortet keine Nachricht.",
	"ready.agent.gone": "Der gewählte Agent steht nicht mehr in deiner Liste. Wähle einen anderen.",
	"ready.agent.noModel": "{{name}} hat kein Modell und kann daher nicht antworten. Gib ihm eines.",
	"ready.agent.ok": "{{name}} antwortet mit dem Modell {{model}}.",
	"ready.agent.okUnknown": "Ein Agent ist gewählt.",
	"ready.who.anyone": "Jede Person, die dem Bot schreiben kann, darf ihn nutzen.",
	"ready.who.nobody": "Noch ist niemand gelistet, daher ignoriert der Bot jede Nachricht. Füge eine Person hinzu.",
	"ready.who.channelsOnly": "Nur Kanäle stehen auf der Liste. Personen in einem Kanal können chatten, die angehakten Berechtigungen nutzen sie aber nur dort, wo der Kanal auf Alle hier dürfen Aktionen anfragen steht.",
	"ready.who.listed_one": "{{count}} Person oder Chat ist gelistet.",
	"ready.who.listed_other": "{{count}} Personen oder Chats sind gelistet.",
	"ready.who.mixed": "{{count}} Einträge sind gelistet, Personen und Kanäle.",
	"ready.perm.none": "Keine Berechtigung ist an. Absender können chatten, sonst nichts.",
	"ready.perm.noneSaved": "Keine Berechtigung ist an, daher sind Dateien, Gedächtnis, Trigger und Posts aus.",
	"ready.perm.onlyOwnRows": "Die anderen Berechtigungen sind aus. Trigger und Dateien stehen unten.",
	"ready.perm.ok_one": "{{count}} Berechtigung ist an und ein Absender kann sie nutzen.",
	"ready.perm.ok_other": "{{count}} Berechtigungen sind an und ein Absender kann sie nutzen.",
	"ready.perm.dead_one": "Niemand kann {{names}} nutzen. {{message}}",
	"ready.perm.dead_other": "Niemand kann {{count}} der eingeschalteten Berechtigungen nutzen: {{names}}. Zuerst: {{message}}",
	"ready.addons.off": "Der Agent hat die {{addon}}-Werkzeuge {{tools}}, kann sie in diesem Chat aber erst nutzen, wenn du \"{{permission}}\" einschaltest.",
	"ready.addons.blocked": "Der Agent hat die {{addon}}-Werkzeuge {{tools}}, sie werden aber zurückgehalten. {{message}}",
	"ready.addons.ok": "Der Agent kann die {{addon}}-Werkzeuge {{tools}} in diesem Chat nutzen.",
	"ready.addons.paired": "Verifizierte Personen können die Schreibwerkzeuge von {{addon}} ({{tools}}) in diesem Chat nutzen, weil der Agent mit {{connection}} verbunden ist (Schreibmodus: {{mode}}). Gelistete Personen, die nicht verifiziert sind, brauchen \"{{permission}}\".",
	"ready.addons.removed": "Du hast \"{{permission}}\" ausgeschaltet. Deshalb kann in diesem Chat niemand die Schreibwerkzeuge von {{addon}} ({{tools}}) nutzen, auch keine verifizierte Person. Schalte es ein, um sie zurückzubekommen; gelistete Personen, die nicht verifiziert sind, erhalten sie dann auch.",
	"ready.addons.modeOff": "Der Agent hat die Schreibwerkzeuge von {{addon}} ({{tools}}), sie werden aber zurückgehalten, weil der Schreibmodus von {{connection}} aus ist. Ändere den Schreibmodus an dieser Verbindung.",
	"ready.addons.mode.auto": "läuft sofort",
	"ready.addons.mode.propose": "fragt zuerst",
	"ready.triggers.off": "Der Agent kann hier keine Erinnerungen oder geplanten Aufgaben einrichten.",
	"ready.triggers.blocked": "Trigger sind an, lassen sich aber nicht nutzen. {{message}}",
	"ready.triggers.ok.ask": "Der Agent kann Trigger vorschlagen. Du bestätigst jeden, bevor er startet.",
	"ready.triggers.ok.auto": "Der Agent kann Trigger vorschlagen. Sie starten sofort, ohne dich zu fragen.",
	"ready.triggers.ok.auto_readonly": "Der Agent kann Trigger vorschlagen. Ein Trigger, der nur liest, startet sofort; jeden anderen bestätigst du.",
	"ready.files.offReceive": "Absender können dem Agenten keine Dateien senden.",
	"ready.files.offBoth": "Absender können dem Agenten keine Dateien senden, und der Bot schickt keine zurück.",
	"ready.files.blocked": "Das Empfangen von Dateien ist an, lässt sich aber nicht nutzen. {{message}}",
	"ready.files.ok": "Absender können dem Agenten Dateien senden, und der Bot kann Dateien zurückschicken.",
	"ready.files.okReceive": "Absender können dem Agenten Dateien senden. Der Bot schickt keine zurück.",
	"ready.notify.off": "Kein Chat erhält Hinweise von diesem Bot.",
	"ready.notify.ok": "Hinweise gehen an den Chat {{chat}}.",
	dismiss: "Verwerfen",
	credentialsOnly: "Nur Zugangsdaten",
	agentCredentialsOnly: "Kein Agent (nur Zugangsdaten)",
	agentOptionalHint: "Optional. Ohne Agent hält diese Verbindung nur das Token, die Repository-Liste und den Schreibmodus für deine Chats. Sie beantwortet keine Nachrichten. Wähle einen Agenten, damit sie zuhört.",
	"sender.line_one": "{{name}} · {{count}} Nachricht · {{id}}",
	"sender.line_other": "{{name}} · {{count}} Nachrichten · {{id}}",
	"ready.blocker.nobodyLetIn": "Noch ist niemand zugelassen.",
	"ready.blocker.nobodyPaired": "Dafür braucht es eine verifizierte Person, und noch ist niemand verifiziert.",
	optional: "optional",
	"approvals.title": "Tools, die sofort laufen",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "Fragt zuerst",
	"approvals.state.runs": "Läuft sofort",
	"approvals.state.idle": "Auf sofort laufen gesetzt, tut jetzt nichts",
	"approvals.state.other": "Fragt diesen Absender weiterhin zuerst",
	"approvals.line.asks": "Eine Karte wartet auf dein OK.",
	"approvals.line.runs": "Für die eigenen Chats des Besitzers und für verifizierte Personen. Alle anderen werden weiterhin gefragt.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "Nur der Besitzer und eine verifizierte Person überspringen die Karte. Diese Art von Absender wird gefragt.",
	"dup.text": "Dieser Bot ist auch als {{name}} verbunden. Beide Verbindungen beantworten dieselbe Nachricht.",
	"dup.turnOff": "Diese ausschalten",
	"dup.openOther": "{{name}} öffnen",
	"dup.saveAnyway": "Trotzdem speichern",
	"dup.goBack": "Zurück",
	"dup.confirmHelp": "Speichere nur dann trotzdem, wenn du auf jede Nachricht zwei Antworten haben willst.",
	"access.noteSave.title": "Notizen",
	"access.noteSave.now": "Speichert Notizen sofort und sagt Bescheid, mit Rückgängig",
	"access.noteSave.ask": "Notizen dieser Art Absender warten auf den Eigentümer",
	"trust.answer": "Nur antworten",
	"trust.act": "Alle hier dürfen Aktionen anfragen",
	"ready.row.channelTrust": "Kanäle, in denen der Bot zuhört",
	"ready.row.postTo": "Ort, an dem der Bot posten darf",
	"ready.channelTrust.act": "Personen in {{channels}} können Alltagsaktionen anfragen. Sensible brauchen weiterhin eine verifizierte Person.",
	"ready.channelTrust.answer": "Personen in {{channels}} können keine Aktionen nutzen: stelle es auf Alle hier dürfen Aktionen anfragen.",
	"ready.channelTrust.noCaps": "Unter Berechtigungen ist nichts angehakt, daher werden Dateien und andere Aktionen auch dort abgelehnt, wo alle fragen dürfen.",
	"fix.trust": "Kanal einstellen",
	"can.via.channel": "Alle in diesem Kanal können das anfragen, weil der Kanal auf Alle hier dürfen Aktionen anfragen steht",
	"ready.postTo_one": "Der Bot darf in 1 weiteren Ort posten, wenn eine gelistete Person darum bittet. Das macht die Personen dort nicht vertrauenswürdig.",
	"ready.postTo_other": "Der Bot darf in {{count}} weiteren Orten posten, wenn eine gelistete Person darum bittet. Das macht die Personen dort nicht vertrauenswürdig.",
	"access.toolsTitle": "Aufrufe von Add-on-Werkzeugen",
	"access.toolsHelp": "Die letzten Aufrufe von Add-on-Werkzeugen, die diese Verbindung nutzten oder über diesen Bot kamen, neueste zuerst, höchstens 20. Sie enthalten Werkzeugnamen und Gründe, nie, was gefragt oder geantwortet wurde. Sie werden beim Neustart des Servers zurückgesetzt.",
	"access.toolsNone": "Noch kein Aufruf.",
	"access.outcome.ok": "erfolgreich",
	"access.outcome.held": "angehalten",
	"access.outcome.denied": "abgelehnt",
	"access.outcome.error": "fehlgeschlagen",
	"ready.addons.confirmChat": "Eine verifizierte Person kann die Schreibaktionen von {{addon}} im Chat bestätigen: Der Bot schreibt jede dort hinein und sie antwortet mit Ja oder Nein.",
	"access.outcome.confirmed": "bestätigt",
	"access.outcome.cancelled": "abgebrochen",
	"access.outcome.expired": "abgelaufen",
	"access.askedBy": "angefragt von {{sender}}",
	"access.chat": "in {{chat}}",
	"sender.chat": "in {{chat}}",
	"sender.reason.not_listed": "keine gelistete Person",
	"sender.reason.not_addressed": "die Nachricht nannte den Bot nicht",
	"ready.notReady": "Noch nicht bereit.",
	"ready.fixCount_one": "{{count}} Sache zu beheben",
	"ready.fixCount_other": "{{count}} Sachen zu beheben",
	"ready.quiet_one": "{{count}} Sache einzustellen",
	"ready.quiet_other": "{{count}} Sachen einzustellen",
	"ready.quietDone": "Nichts mehr einzustellen",
	"matrix.title": "Wer was darf",
	"loops.title": "Warten und Timer",
	"loops.help": "Was der Agent später in diesem Chat von selbst tun darf. Das gehört zum Bot: Eine Rolle bekommt es nie.",
	"matrix.note": "Die Schalter und die Rollenfelder stellst du selbst ein. Jede andere Zelle wird aus deinen aktuellen Einstellungen berechnet, mit derselben Prüfung, die der Host bei jeder Nachricht ausführt.",
	"matrix.capability": "Berechtigung",
	"matrix.pick": "Art des Absenders",
	"matrix.col.on": "An für diesen Bot",
	"matrix.col.paired": "Verifizierte Person",
	"matrix.col.listed": "Gelistete Person",
	"matrix.col.channel_acts": "Kanal: alle dürfen handeln",
	"matrix.col.channel_member": "Kanal: nur antworten",
	"matrix.col.anyone": "Jede Person",
	"matrix.state.yes": "Ja",
	"matrix.state.asks": "Fragt zuerst",
	"matrix.state.no": "Nein",
	"matrix.state.waiting": "Wartet auf eine Person",
	"matrix.state.off": "Aus",
	"matrix.state.unknown": "Nicht bekannt",
	"matrix.row.tools": "Dinge in verbundenen Diensten ändern",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Warum eine Zelle Nein oder Aus sagt",
	"matrix.detail.none": "Wähle eine Zelle, um den Grund zu lesen.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Auf die übliche Auswahl zurücksetzen",
	"matrix.more": "Details",
	"matrix.less": "Details ausblenden",
	"matrix.nobodyVerified": "Noch niemand ist verifiziert.",
	"who.title": "Wer mit dem Bot sprechen darf",
	"who.onlyChosen": "Nur Personen, die ich auswähle",
	"who.anyone": "Jeder, der ihm schreiben kann",
	"who.people": "Personen",
	"who.peopleAndChannels": "Personen und Kanäle",
	"who.peopleNone": "Noch niemand ist eingetragen. Füge unten eine Person hinzu.",
	"who.channels": "Kanäle",
	"who.channelsNote": "Personen in einem Kanal können nur in diesem Kanal handeln, nie in einer Direktnachricht.",
	"who.add": "Person oder Kanal hinzufügen",
	"who.recent": "Personen, die dem Bot kürzlich geschrieben haben. Klicke, um sie hinzuzufügen.",
	"who.addPerson": "{{name}} hinzufügen",
	"who.verified": "Verifiziert",
	"who.listed": "Eingetragen",
	"who.verify": "Verifizieren",
	"who.verifyPerson": "{{name}} verifizieren",
	"who.remove": "Entfernen",
	"who.removePerson": "{{name}} entfernen",
	"who.removeChannel": "{{name}} entfernen",
	"who.levelFor": "Was Personen in {{channel}} tun können",
	"answer.more": "Dateigrößen und Antwortsprache",
	"perm.channelsSwitch": "Zum Schalter",
	"perm.channelWho": "Wer es zum Schreiben bringen darf",
	"perm.channelWhoFor": "Wer den Bot in {{id}} schreiben lassen darf",
	"perm.channelWho.any": "Wenn eine erlaubte Person darum bittet",
	"perm.channelWho.verified": "Nur wenn eine verifizierte Person darum bittet",
	"notify.label": "Meine Erinnerungen und Ergebnisse von Läufen senden an",
	"notify.none": "Nirgendwohin",
	"notify.people": "Personen",
	"notify.channels": "Kanäle",
	"notify.saved": "{{id}} (gespeicherte ID)",
	"notify.other": "Eine andere ID...",
	"notify.otherLabel": "Chat-ID",
	"try.title": "Ausprobieren",
	"try.help": "Wähle, wer schreibt, wo und was gewünscht wird. Das ist dieselbe Prüfung, die der Host bei jeder Nachricht macht, auf dem Formular, wie es jetzt ist.",
	"try.noone": "Füge zuerst eine Person hinzu. Dann kannst du ausprobieren, was sie darf.",
	"try.whoLabel": "Wer",
	"try.placeLabel": "Wo",
	"try.actionLabel": "Was gewünscht wird",
	"try.someoneIn": "Jemand in {{channel}}",
	"try.anyone": "Jeder",
	"try.role": "Jemand mit der Rolle {{role}}",
	"try.dm": "Direktnachricht",
	"try.where.dm": "in einer Direktnachricht",
	"try.where.channel": "in {{channel}}",
	"try.is.paired": "{{who}} ist eine verifizierte Person und schreibt {{where}}.",
	"try.is.listed": "{{who}} ist eine Person auf der Liste und schreibt {{where}}.",
	"try.is.channelActs": "Jemand in {{channel}}, wo alle Aktionen anfordern dürfen.",
	"try.is.channelAnswers": "Jemand in {{channel}}, wo es nur Antworten gibt.",
	"try.is.anyone": "Jeder, der dem Bot schreiben kann, wird eingelassen.",
	"try.is.role": "Eine Person mit der Rolle {{role}} wird eingelassen.",
	"try.verdict.allowed": "Erlaubt.",
	"try.verdict.asks": "Erlaubt, aber es fragt zuerst.",
	"try.verdict.refused": "Abgelehnt.",
	"try.loading": "Wird geprüft...",
	"try.error": "Die Prüfung hat nicht geantwortet. Nutze Erneut versuchen in der Tabelle oben.",
	"try.unknown": "Der Host hat für diese Art von Absender keine Antwort gegeben.",
	"try.note": "Es wird nichts an die Plattform gesendet und nichts gespeichert.",
	"refusals.title": "Letzte Ablehnungen",
	"refusals.help": "Was der Bot seit dem Start des Servers abgelehnt hat, das Neueste zuerst. Es enthält IDs, Namen und Chats, nie den Nachrichtentext. Dieses Protokoll liegt nur im Speicher: Nach einem Neustart des Servers ist es leer.",
	"refusals.none": "Seit dem Start des Servers wurde nichts abgelehnt.",
	"refusals.refused": "abgelehnt",
	"refusals.action": "wollte: {{action}}",
	"refusals.talk": "hat dem Bot geschrieben",
	"refusals.allow": "{{name}} erlauben",
	"refusals.act": "Mitgliedern von {{channel}} Aktionen erlauben",
	"perm.channelPickOther": "Andere: ID eingeben",
	"perm.channelHint.verified": "Geplante Läufe können hier nicht schreiben. Wähle \"Wenn eine erlaubte Person darum bittet\", damit sie es können.",
	"perm.channelHint.any": "Geplante Läufe können hier schreiben.",
	"perm.channelNoListen": "Der Bot hört in diesem Kanal nicht zu und schreibt dort nur.",
	"who.post.none": "Der Bot kann hier nicht schreiben.",
	"who.post.add": "Bot darf hier auch schreiben",
	"who.post.addFor": "Bot darf auch in {{name}} schreiben",
	"who.post.verified": "Schreibt hier nur, wenn eine verifizierte Person darum bittet.",
	"who.post.any": "Schreibt hier, wenn eine erlaubte Person darum bittet.",
	"who.post.show": "Ort anzeigen",
	"who.post.showFor": "Ort für {{name}} anzeigen",
	agentLink: "Den Agenten {{name}} öffnen",
	"saved.created": "Verbindung hinzugefügt.",
	"saved.nothing": "Gespeichert. Nichts geändert.",
	"saved.changed": "Gespeichert. Geändert: {{what}}.",
	"saved.part.name": "Name",
	"saved.part.agent": "Agent",
	"saved.part.who": "wen sie annimmt",
	"saved.part.permissions": "Berechtigungen",
	"saved.part.approval": "Freigabe und Aktionen der Trigger",
	"saved.part.files": "Dateieinstellungen",
	"saved.part.notify": "Benachrichtigungen",
	"saved.dropped.title": "Diese Verbindung erlaubt diese Aktionen nicht mehr, deshalb verlieren die Läufe dieser Trigger sie:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "Läuft",
	"conn.state.off": "Aus",
	"conn.state.attention": "Braucht Aufmerksamkeit",
	"conn.state.ready": "Bereit",
	"conn.row.open": "{{name}}: {{state}}. Details anzeigen",
	"conn.row.menu": "Weitere Aktionen für {{name}}",
	"conn.row.testNamed": "{{name}} testen",
	"conn.fix.token": "Token korrigieren",
	"conn.reason.noToken": "Es ist kein Token gespeichert.",
	"conn.reason.duplicate": "Antwortet über denselben Bot wie {{name}}.",
	"conn.reason.testFailed": "Der letzte Test ist fehlgeschlagen: {{reason}}",
	"conn.kv.service": "Dienst",
	"conn.kv.accepts": "Akzeptiert",
	"conn.kv.replies": "Antworten",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Gespeichert",
	"conn.kv.notSaved": "Nicht gespeichert",
	"conn.kv.agents": "Agenten",
	"usedBy.count_one": "Von {{count}} Agent verwendet",
	"usedBy.count_other": "Von {{count}} Agenten verwendet",
	"usedBy.none": "Von keinem Agenten verwendet",
	"conn.pane.lastTest": "Letzter Test",
	"conn.pane.never": "In diesem Browser noch nicht getestet.",
	"conn.pane.passed": "Bestanden {{when}}.",
	"conn.pane.failed": "Fehlgeschlagen {{when}}.",
	"conn.pane.connection": "Verbindung",
	"conn.pane.remove": "Entfernen",
	"conn.pane.test": "Verbindung testen",
	"conn.pane.testing": "Test läuft...",
	"conn.sheet.addDesc": "Gib einen Namen ein, füge das Token hinzu und wähle den Agenten, der antwortet.",
	"conn.sheet.editDesc": "Änderungen gelten, wenn du speicherst. Ein gespeichertes Token wird nie wieder angezeigt.",
	"conn.sheet.connection": "Verbindung",
	"conn.sheet.who": "Wer mit ihr sprechen darf",
	"conn.sheet.may": "Was sie tun darf",
	"conn.sheet.replies": "Antworten, Dateien und Orte",
	"conn.sheet.check": "Prüfen, was sie tun wird",
	"conn.sheet.saveAndTest": "Speichern und testen",
	"conn.sheet.saving": "Speichern...",
	"conn.sheet.testFailed": "Die Verbindung ist gespeichert, aber der Test ist fehlgeschlagen.",
	"conn.sheet.testFailedNoReason": "Es wurde kein Grund genannt.",
	"conn.sheet.testAgain": "Erneut testen",
	"conn.sheet.close": "Schließen",
	"conn.sheet.agentFixed": "Antwortet mit dem Agenten {{name}}",
	"conn.preset.label": "Berechtigungen",
	"conn.preset.answer": "Nur antworten",
	"conn.preset.answerHelp": "Sie antwortet auf Nachrichten. Diese Verbindung fügt keine eigene Berechtigung hinzu.",
	"conn.preset.standard": "Standard",
	"conn.preset.standardHelp": "Die übliche Auswahl, die der Agent hat: {{list}}.",
	"conn.preset.standardNone": "Die übliche Auswahl. Dieser Agent hat nichts davon.",
	"conn.preset.custom": "Benutzerdefiniert",
	"conn.preset.customHelp": "Wähle jede Berechtigung und wer sie nutzen darf.",
	"conn.preset.note": "Eine Vorgabe schaltet nie eine sensible Berechtigung ein. Nutze dafür Benutzerdefiniert. Die Add-on-Verbindungen des Agenten haben eigene Regeln: Verifizierte Personen können deren Schreibwerkzeuge weiterhin nutzen. Ändere das beim Agenten unter \"Was er nutzen kann\".",
	"conn.discard.title": "Änderungen verwerfen?",
	"conn.discard.message": "Du hast diese Verbindung geändert und nicht gespeichert.",
	"conn.discard.confirm": "Änderungen verwerfen",
	"share.label": "Teilen",
	"share.button": "{{name}} teilen",
	"share.intro": "Personen, die du hinzufügst, können diese Verbindung in ihren eigenen Chats und Agenten nutzen. Sie sehen ihren Namen und Zustand, nie das Token oder die Einstellungen. Nachrichten an den Bot erreichen weiterhin deinen Agenten.",
	"share.roleUse": "Darf nutzen",
	"share.roleUseHelp": "Darf sie in eigenen Chats und Agenten nutzen. Kann das Token nicht sehen, sie nicht ändern und nicht teilen.",
	"shared.title": "Mit dir geteilt",
	"shared.text": "Andere Personen lassen dich diese Verbindungen in deinen Chats und Agenten nutzen. Nur die Eigentümer können sie ändern.",
	"shared.on": "Hört zu",
	"shared.off": "Aus",
	"shared.by": "Geteilt von {{name}}",
	loginNeedsHost: "Diese Version von LocalAI kann sich auf dieser Seite nicht anmelden. Aktualisiere LocalAI, um hier eine Verbindung herzustellen."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.zh-CN.json
var connector_zh_CN_default = {
	"answer.title": "在哪里发帖以及如何回复",
	"answer.replyLabel": "智能体工作时",
	"answer.reply.off": "显示正在输入，然后给出回答",
	"answer.reply.progress": "进度：它用到的工具",
	"answer.reply.stream": "实时：边写边显示回答",
	"answer.reply.reasoning": "思考：显示模型的思考过程，然后是回答",
	"answer.replyHelp": "“进度”和“实时”会显示一条处理中的消息，回答出来后替换它。在支持草稿的平台上，“实时”会在私聊中显示草稿，回答随后跟上。较长的回答会继续发成新消息。",
	"answer.replyReasoningHelp": "“思考”会把模型写出的思考过程显示给此绑定的每一位发送者。仅在可以这样做的地方使用。",
	"answer.conversationLabel": "对话",
	"answer.conversationHelp": "在应用中发送 /new（或 !new）即可开始新的对话。",
	"answer.conversation.sender": "每人一个对话",
	"answer.conversation.chat": "每个群组或频道一个对话",
	"answer.conversation.window": "每人一个，安静一段时间后开新对话",
	"answer.conversation.thread": "每条消息一个新对话，回复接着聊",
	"answer.window": "安静时间（分钟）",
	"answer.windowRange": "请输入 1 到 {{max}} 的整数。",
	"answer.languageLabel": "回复语言",
	"answer.languageHelp": "机器人自己撰写的提示，例如确认和拒绝。模型的回答则使用对话所用的语言。",
	"answer.language.auto": "自动（你的界面语言，否则使用发送者的语言）",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "发送智能体生成的文件",
	add: "添加",
	more: "更多",
	less: "收起",
	"answer.filesHelp": "回答之后最多发送 5 个文件。程序和脚本不会发送。大小上限在“文件大小和回复语言”中设置。",
	"answer.summary": "回复：{{reply}} · {{conversation}}",
	"answer.short.off": "正在输入",
	"answer.short.progress": "进度",
	"answer.short.stream": "实时回答",
	"answer.short.reasoning": "显示思考",
	"answer.short.sender": "每人一个对话",
	"answer.short.chat": "每个群组一个对话",
	"answer.short.window": "{{count}} 分钟后开新对话",
	"answer.short.thread": "每条消息一个对话",
	"approval.title": "来自聊天的定时任务和触发器",
	"approval.help": "当智能体设置了稍后运行的内容（“10 分钟后”“每天”）时，每次运行都会调用一次模型。",
	"approval.mode.ask": "先询问：机器人在聊天中提出建议，由对方回答是或否",
	"approval.mode.auto": "立即执行：已完成设置，并告诉对方如何取消",
	"approval.mode.auto_readonly": "运行只读取和汇报时立即执行，否则先询问",
	"approval.limitsHelp": "这些限制决定了无需询问即可设置的范围。字段留空则使用默认值。超出限制的一律改为询问。",
	"approval.max_pending": "同时存在的定时任务和触发器上限",
	"approval.min_gap_minutes": "循环触发器两次运行之间的最少分钟数",
	"approval.max_runs_per_day": "每天的运行总次数上限",
	"approval.max_lifetime_days": "最长存续天数",
	"approval.invalid": "请输入 1 到 {{max}} 的整数，或留空。",
	"approval.default": "默认值：{{value}}。",
	"approval.summary": "触发器：{{mode}}",
	"approval.effect": "建议：{{mode}}",
	"approval.effectChange": "更改和删除：{{mode}}",
	"approval.limits": "限制",
	"approval.acts.title": "运行可执行的操作",
	"approval.acts.help": "关闭：由此聊天创建的触发器，其运行只读取和汇报。开启：运行还可以执行你在下面勾选的操作，且仅限智能体具备的操作。",
	"approval.acts.modes": "先询问：始终由你决定。立即执行：仅当你是已验证的人，且这里勾选了所有操作时。",
	"approval.acts.act.files": "在智能体的文件夹中写入文件",
	"approval.acts.act.files.effect": "运行可以创建和修改智能体保存的文件。",
	"approval.acts.act.addons": "使用智能体附加组件的操作",
	"approval.acts.act.addons.effect": "运行可以使用智能体的附加组件所能做的事，包括命令。",
	"approval.acts.act.send": "向汇报位置之外发送消息",
	"approval.acts.act.send.effect": "运行可以自行向其他聊天和频道写入内容。",
	"approval.acts.act.spend": "使用付费或外部工具以及网络",
	"approval.acts.act.spend.effect": "运行可以调用 LocalAI 之外的服务，这可能产生费用。",
	"approval.acts.lacks": "智能体不具备此项。",
	"approval.acts.sensitive": "敏感",
	"approval.effectActs": "，运行可以：{{acts}}",
	"approval.actShort.act.files": "写入文件",
	"approval.actShort.act.addons": "使用附加组件",
	"approval.actShort.act.send": "发送消息",
	"approval.actShort.act.spend": "使用付费或外部工具",
	"approval.short.ask": "先询问",
	"approval.short.auto": "立即执行",
	"approval.short.auto_readonly": "只读时立即执行",
	"files.title": "文件",
	"files.help": "字段留空则使用附加组件的上限。你设置的上限只能比它更低。",
	"files.receiveLabel": "可读取的最大文件（MiB）",
	"files.sendLabel": "可发送的最大文件（MiB）",
	"files.invalid": "请输入大于 0 的数字。",
	"files.tooHigh": "附加组件在这里最多允许 {{max}}。",
	"files.now": "当前：{{limit}}（{{layer}}）。",
	"files.receiveHelp": "用户发给机器人的文件。过大的文件会被拒绝，机器人会说明触及了哪个上限。",
	"files.sendHelp": "智能体生成并由机器人回传的文件。过大的文件不会发送，机器人会说明触及了哪个上限。",
	"files.addon.off": "此附加组件不支持这个方向的文件传输，因此无需设置。",
	"files.addon.declared": "附加组件声明的上限为 {{max}}。",
	"files.addon.open": "附加组件未声明上限，因此适用平台的上限。",
	"files.host": "任何机器人都不能传输超过 {{max}} 的文件。管理员可在设置中调整。",
	"files.layer.owner": "为此机器人设置的上限",
	"files.layer.addon": "附加组件的上限",
	"files.layer.host": "平台的上限",
	"perm.agentLacks": "智能体不具备此项。",
	"perm.rule": "名单中的人可以使用已勾选的权限。敏感权限还要求是已验证的人。",
	"perm.sensitive": "仅限已验证的人",
	"perm.sensitiveHelp": "敏感。绝不授予角色。只有已验证的人可以使用，每次使用都会被记录。",
	"perm.roleCap": "{{role}}：{{cap}}",
	"perm.channelsTitle": "机器人可以发消息的位置",
	"perm.channelsHelp": "在名单中的人请求时，智能体除了回答所在的聊天外，还可以发消息的位置。这不决定机器人听谁的：请看“机器人监听的频道”。最多 {{max}} 个。",
	"perm.channelsOff": "请先在上方开启“向其他频道发消息”，再选择机器人可以发消息的位置。",
	"perm.channelId": "频道 ID",
	"perm.channelLabel": "名称",
	"perm.channelAdd": "添加位置",
	"perm.channelRemove": "移除位置 {{id}}",
	"perm.remove": "移除",
	"perm.channelFull": "列表已满。",
	"perm.channelProblem.id": "每个位置需要 1 到 {{max}} 字节的 ID，且不含空格。",
	"perm.channelProblem.label": "名称最多 {{max}} 个字符。",
	"perm.channelProblem.repeat": "有位置重复列出。",
	"perm.channelProblem.count": "最多 {{max}} 个位置。",
	"perm.triggersNeed": "请先开启“提议触发器”再使用。",
	"pair.start": "验证某人",
	"pair.startHelp": "生成一个代码。请在十分钟内，用要验证的账户把它私信发给机器人。代码只能使用一次。",
	"pair.needSave": "请先保存此机器人，再验证某人。",
	"pair.codeTitle": "你的验证码",
	"pair.codeHelp": "请用要验证的账户把此代码私信发给机器人。它只显示这一次，只能使用一次，并在 {{time}} 过期。",
	"pair.codeGone": "代码已过期。如果此人尚未验证，请重新生成。",
	"pair.done": "已验证：{{sender}}。",
	"pair.dismiss": "隐藏代码",
	"pair.none": "没有人已验证。",
	"pair.expires": "{{time}} 结束",
	"pair.full": "已验证三个人。请先移除一个，再验证其他人。",
	"access.title": "检查一下",
	"access.needSave": "请先保存此机器人，才能查看它最近拒绝了谁。",
	"access.refresh": "刷新",
	"access.who": "发送者 {{senders}}",
	"can.sender.role": "角色：{{title}}",
	"can.fromForm": "按此表单当前的内容计算。保存后这些设置才会生效。",
	"can.fromFormNew": "尚未保存。按此表单当前的内容计算。",
	"can.loading": "正在检查此机器人可以做什么",
	"can.stale": "正在更新",
	"can.errorTitle": "无法检查此机器人可以做什么",
	"can.retry": "重试",
	"can.allowed": "允许",
	"can.via.paired": "因为此人已验证",
	"can.via.allowlist": "因为此人在名单中",
	"can.via.agentConnection": "因为此人已验证，且智能体已连接到该附加组件",
	"can.via.role": "通过角色 {{role}}",
	"can.then": "尚未检查：{{list}}。",
	"can.then.server": "服务器设置",
	"can.then.tools": "智能体的“工具”开关",
	"can.then.agent": "智能体的权限",
	"can.then.connection": "此连接的权限",
	"can.then.sender": "发送者是谁",
	"can.then.approval": "建议如何被确认",
	"can.noMessage": "不允许。",
	"fix.open_connection": "显示该设置",
	"fix.open_agent": "打开智能体",
	"fix.open_server_setting": "打开设置",
	"fix.pair_sender": "验证某人",
	"fix.add_person": "添加人员",
	"fix.save": "保留这些更改",
	"fix.token": "粘贴 token",
	"fix.tokenNew": "粘贴新的 token",
	"fix.agent": "选择智能体",
	"fix.usual": "选择权限",
	"fix.turnOn": "开启",
	"fix.newTab": "（在新标签页中打开）",
	"fix.askAdmin": "请询问管理员",
	"ready.title": "状态",
	"ready.checkingSummary": "正在检查表单将产生的效果。",
	"ready.allGood": "所需条件均已具备。",
	"ready.showAll": "显示全部 {{count}} 项",
	"ready.showProblems": "只显示需要处理的",
	"ready.checking": "正在检查。",
	"ready.unchecked": "无法检查此项。请查看下方的“此机器人可以做什么”。",
	"ready.row.token": "Token",
	"ready.row.agent": "智能体",
	"ready.row.who": "谁可以使用",
	"ready.row.permissions": "权限",
	"ready.row.addons": "插件工具",
	"ready.row.triggers": "触发器",
	"ready.row.files": "文件",
	"ready.row.notify": "通知",
	"ready.state.ok": "正常",
	"ready.state.attention": "需要处理",
	"ready.state.off": "关闭",
	"ready.state.after_save": "保存后",
	"ready.state.broken": "无法工作",
	"ready.state.checking": "检查中",
	"ready.state.unknown": "未知",
	"ready.token.missing": "请粘贴机器人的 token。没有它就收不到任何消息。",
	"ready.token.newTyped": "保存时会向平台校验该 token。",
	"ready.token.typed": "保存时会向平台校验新的 token。",
	"ready.token.failed": "平台拒绝了该 token：{{reason}}",
	"ready.token.checked": "平台已接受该 token。{{bot}}",
	"ready.token.saved": "已保存 token。保存时平台已接受它。",
	"ready.agent.none": "请选择负责回答的智能体。",
	"ready.agent.credentialsOnly": "没有智能体。此连接只保存凭据，不回答任何消息。",
	"ready.agent.gone": "所选智能体已不在你的列表中。请另选一个。",
	"ready.agent.noModel": "{{name}} 没有模型，无法回答。请为它指定一个。",
	"ready.agent.ok": "{{name}} 负责回答，使用模型 {{model}}。",
	"ready.agent.okUnknown": "已选择智能体。",
	"ready.who.anyone": "任何能给机器人发消息的人都可以使用。",
	"ready.who.nobody": "目前名单中没有人，因此机器人会忽略所有消息。请添加人员。",
	"ready.who.channelsOnly": "列表中只有频道。频道里的人可以聊天，但只有在频道设为“允许此处所有人请求操作”时才能使用已勾选的权限。",
	"ready.who.listed_one": "名单中有 {{count}} 个人或聊天。",
	"ready.who.listed_other": "名单中有 {{count}} 个人或聊天。",
	"ready.who.mixed": "名单中有 {{count}} 个条目，包括人员和频道。",
	"ready.perm.none": "没有开启任何权限。发送者只能聊天，不能做其他事。",
	"ready.perm.noneSaved": "没有开启任何权限，因此文件、记忆、触发器和发帖都处于关闭状态。",
	"ready.perm.onlyOwnRows": "其他权限已关闭。触发器和文件见下方。",
	"ready.perm.ok_one": "已开启 {{count}} 项权限，发送者可以使用。",
	"ready.perm.ok_other": "已开启 {{count}} 项权限，发送者可以使用。",
	"ready.perm.dead_one": "没有人可以使用 {{names}}。{{message}}",
	"ready.perm.dead_other": "已开启的权限中，有 {{count}} 项没有人可以使用：{{names}}。首先：{{message}}",
	"ready.addons.off": "智能体有 {{addon}} 工具 {{tools}},但在你开启“{{permission}}”之前,无法在此聊天中使用。",
	"ready.addons.blocked": "智能体有 {{addon}} 工具 {{tools}},但它们被拦下了。{{message}}",
	"ready.addons.ok": "智能体可以在此聊天中使用 {{addon}} 工具 {{tools}}。",
	"ready.addons.paired": "因为智能体已连接到 {{connection}}（写入模式：{{mode}}），已验证的人可以在此聊天中使用 {{addon}} 的写入工具 {{tools}}。名单中未验证的人需要“{{permission}}”。",
	"ready.addons.removed": "你关闭了“{{permission}}”，因此在此聊天中没有人可以使用 {{addon}} 的写入工具 {{tools}}，包括已验证的人。开启后即可恢复；名单中未验证的人也会获得。",
	"ready.addons.modeOff": "代理拥有 {{addon}} 的写入工具 {{tools}}，但因为 {{connection}} 的写入模式已关闭而被拦下。请在该连接上更改写入模式。",
	"ready.addons.mode.auto": "立即执行",
	"ready.addons.mode.propose": "先询问",
	"ready.triggers.off": "智能体无法在这里设置提醒或定时任务。",
	"ready.triggers.blocked": "触发器已开启，但无法使用。{{message}}",
	"ready.triggers.ok.ask": "智能体可以提议触发器。每个触发器启动前都由你确认。",
	"ready.triggers.ok.auto": "智能体可以提议触发器。它们会立即启动，不会询问你。",
	"ready.triggers.ok.auto_readonly": "智能体可以提议触发器。只读取的触发器立即启动，其他的需要你确认。",
	"ready.files.offReceive": "发送者无法向智能体发送文件。",
	"ready.files.offBoth": "发送者无法向智能体发送文件，机器人也不会回传文件。",
	"ready.files.blocked": "接收文件已开启，但无法使用。{{message}}",
	"ready.files.ok": "发送者可以向智能体发送文件，机器人也可以回传文件。",
	"ready.files.okReceive": "发送者可以向智能体发送文件。机器人不回传文件。",
	"ready.notify.off": "没有聊天会收到此机器人的通知。",
	"ready.notify.ok": "通知会发送到聊天 {{chat}}。",
	dismiss: "忽略",
	credentialsOnly: "仅凭据",
	agentCredentialsOnly: "没有智能体（仅凭据）",
	agentOptionalHint: "可选。没有智能体时，此连接只保存 token、仓库列表和用于你的聊天的写入模式，不回答任何消息。选择智能体后，它才会开始监听。",
	"sender.line_one": "{{name}} · {{count}} 条消息 · {{id}}",
	"sender.line_other": "{{name}} · {{count}} 条消息 · {{id}}",
	"ready.blocker.nobodyLetIn": "目前没有人被放行。",
	"ready.blocker.nobodyPaired": "这需要已验证的人，而目前没有人已验证。",
	optional: "可选",
	"approvals.title": "立即执行的工具",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "先询问",
	"approvals.state.runs": "立即执行",
	"approvals.state.idle": "设为立即执行，目前不做任何事",
	"approvals.state.other": "对此发送者仍先询问",
	"approvals.line.asks": "卡片正在等待你的确认。",
	"approvals.line.runs": "适用于所有者自己的聊天和已验证的人。其他人仍会被询问。",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "只有所有者和已验证的人会跳过卡片。这类发送者仍会被询问。",
	"dup.text": "这个机器人也以 {{name}} 的名称连接。两个连接都会回复同一条消息。",
	"dup.turnOff": "关闭这个连接",
	"dup.openOther": "打开 {{name}}",
	"dup.saveAnyway": "仍然保存",
	"dup.goBack": "返回",
	"dup.confirmHelp": "只有在你想让每条消息收到两个回复时，才仍然保存。",
	"access.noteSave.title": "笔记",
	"access.noteSave.now": "立即保存笔记并告知，可撤销",
	"access.noteSave.ask": "此类发送者的笔记等待所有者处理",
	"trust.answer": "仅回答",
	"trust.act": "允许此处所有人请求操作",
	"ready.row.channelTrust": "机器人监听的频道",
	"ready.row.postTo": "机器人可以发消息的位置",
	"ready.channelTrust.act": "{{channels}} 中的人可以请求日常操作。敏感操作仍需已验证的人。",
	"ready.channelTrust.answer": "{{channels}} 中的人无法使用操作：请设为“允许此处所有人请求操作”。",
	"ready.channelTrust.noCaps": "权限中未勾选任何内容，因此即使所有人都可请求，文件和其他操作也会被拒绝。",
	"fix.trust": "设置频道",
	"can.via.channel": "此频道设为“允许此处所有人请求操作”，因此频道中的所有人都可以请求",
	"ready.postTo_one": "在名单中的人请求时，机器人可以向另外 1 个位置发消息。这不意味着信任其中的人。",
	"ready.postTo_other": "在名单中的人请求时，机器人可以向另外 {{count}} 个位置发消息。这不意味着信任其中的人。",
	"access.toolsTitle": "插件工具调用",
	"access.toolsHelp": "最近使用此连接或通过此机器人进来的插件工具调用，最新的在前，最多 20 条。只包含工具名称和原因，不包含请求或回复的内容。服务器重启后会清空。",
	"access.toolsNone": "还没有调用。",
	"access.outcome.ok": "成功",
	"access.outcome.held": "已挂起",
	"access.outcome.denied": "已拒绝",
	"access.outcome.error": "失败",
	"ready.addons.confirmChat": "已验证的人可以在聊天中确认 {{addon}} 的写入：机器人会在聊天中写出每一项，对方回答是或否。",
	"access.outcome.confirmed": "已确认",
	"access.outcome.cancelled": "已取消",
	"access.outcome.expired": "已过期",
	"access.askedBy": "由 {{sender}} 请求",
	"access.chat": "在 {{chat}}",
	"sender.chat": "在 {{chat}}",
	"sender.reason.not_listed": "不是名单中的人",
	"sender.reason.not_addressed": "消息没有提到机器人",
	"ready.notReady": "还没准备好。",
	"ready.fixCount_one": "{{count}} 项需要处理",
	"ready.fixCount_other": "{{count}} 项需要处理",
	"ready.quiet_one": "{{count}} 项待设置",
	"ready.quiet_other": "{{count}} 项待设置",
	"ready.quietDone": "没有需要设置的项目",
	"matrix.title": "谁能做什么",
	"loops.title": "等待和定时器",
	"loops.help": "智能体之后在此聊天中可以自行做的事。这些属于机器人：角色永远不会获得。",
	"matrix.note": "开关和角色复选框由你设置。其他单元格都根据你当前的设置计算，使用主机处理每条消息时相同的检查。",
	"matrix.capability": "权限",
	"matrix.pick": "发送者类型",
	"matrix.col.on": "对此机器人已开启",
	"matrix.col.paired": "已验证的人",
	"matrix.col.listed": "名单中的人",
	"matrix.col.channel_acts": "频道：所有人可操作",
	"matrix.col.channel_member": "频道：仅回答",
	"matrix.col.anyone": "任何人",
	"matrix.state.yes": "是",
	"matrix.state.asks": "先询问",
	"matrix.state.no": "否",
	"matrix.state.waiting": "等待某人确认",
	"matrix.state.off": "关闭",
	"matrix.state.unknown": "未知",
	"matrix.row.tools": "通过附加组件在已连接的服务中更改数据",
	"matrix.toolRow": "{{addon}}：{{tool}}",
	"matrix.detail.label": "为什么某格显示“否”或“关闭”",
	"matrix.detail.none": "选择一个单元格查看原因。",
	"matrix.detail.title": "{{capability}}：{{who}}",
	"matrix.reset": "恢复为常用设置",
	"matrix.more": "详情",
	"matrix.less": "隐藏详情",
	"matrix.nobodyVerified": "还没有人通过验证。",
	"who.title": "谁可以和机器人对话",
	"who.onlyChosen": "仅限我选择的人",
	"who.anyone": "任何可以给它发消息的人",
	"who.people": "人员",
	"who.peopleAndChannels": "人员和频道",
	"who.peopleNone": "还没有列出任何人。请在下方添加。",
	"who.channels": "频道",
	"who.channelsNote": "频道中的人只能在该频道内操作，绝不能在私信中操作。",
	"who.add": "添加人员或频道",
	"who.recent": "最近给机器人发过消息的人。点击即可添加。",
	"who.addPerson": "添加 {{name}}",
	"who.verified": "已验证",
	"who.listed": "已列出",
	"who.verify": "验证",
	"who.verifyPerson": "验证 {{name}}",
	"who.remove": "移除",
	"who.removePerson": "移除 {{name}}",
	"who.removeChannel": "移除 {{name}}",
	"who.levelFor": "{{channel}} 中的人可以做什么",
	"answer.more": "文件大小和回复语言",
	"perm.channelsSwitch": "前往开关",
	"perm.channelWho": "谁可以让它发帖",
	"perm.channelWhoFor": "谁可以让机器人在 {{id}} 发帖",
	"perm.channelWho.any": "任何被允许的人提出请求时",
	"perm.channelWho.verified": "仅当已验证的人提出请求时",
	"notify.label": "将我的提醒和运行结果发送到",
	"notify.none": "不发送",
	"notify.people": "人员",
	"notify.channels": "频道",
	"notify.saved": "{{id}}（已保存的 ID）",
	"notify.other": "其他 ID...",
	"notify.otherLabel": "聊天 ID",
	"try.title": "试一试",
	"try.help": "选择谁在发消息、在哪里发，以及请求什么。这会按表单当前的状态，运行主机对每条消息所做的检查。",
	"try.noone": "请先添加一个人，然后就可以试试 TA 能做什么。",
	"try.whoLabel": "谁",
	"try.placeLabel": "在哪里",
	"try.actionLabel": "请求什么",
	"try.someoneIn": "{{channel}} 中的某人",
	"try.anyone": "任何人",
	"try.role": "具有“{{role}}”角色的人",
	"try.dm": "私信",
	"try.where.dm": "在私信中",
	"try.where.channel": "在 {{channel}} 中",
	"try.is.paired": "{{who}} 是已验证的人，{{where}}发消息。",
	"try.is.listed": "{{who}} 是名单中的人，{{where}}发消息。",
	"try.is.channelActs": "{{channel}} 中的某人，该频道允许所有人请求操作。",
	"try.is.channelAnswers": "{{channel}} 中的某人，该频道只提供回答。",
	"try.is.anyone": "任何能给机器人发消息的人都会被放行。",
	"try.is.role": "具有“{{role}}”角色的人会被放行。",
	"try.verdict.allowed": "允许。",
	"try.verdict.asks": "允许，但会先询问。",
	"try.verdict.refused": "拒绝。",
	"try.loading": "正在检查...",
	"try.error": "检查没有响应。请使用上方表格中的“重试”。",
	"try.unknown": "主机没有给出这类发送者的答案。",
	"try.note": "不会向平台发送任何内容，也不会保存任何内容。",
	"refusals.title": "最近的拒绝",
	"refusals.help": "自服务器启动以来机器人拒绝的内容，最新的在前。其中只有 ID、名称和聊天，没有消息正文。此日志仅保存在内存中：服务器重启后会清空。",
	"refusals.none": "自服务器启动以来没有拒绝任何内容。",
	"refusals.refused": "已拒绝",
	"refusals.action": "请求：{{action}}",
	"refusals.talk": "给机器人发了消息",
	"refusals.allow": "允许 {{name}}",
	"refusals.act": "让 {{channel}} 的成员可以操作",
	"perm.channelPickOther": "其他：输入 ID",
	"perm.channelHint.verified": "定时运行无法在此发帖。选择“任何被允许的人请求时”即可允许。",
	"perm.channelHint.any": "定时运行可以在此发帖。",
	"perm.channelNoListen": "机器人不在此频道监听，只会在此发帖。",
	"who.post.none": "机器人无法在此发帖。",
	"who.post.add": "也让机器人在此发帖",
	"who.post.addFor": "也让机器人在 {{name}} 发帖",
	"who.post.verified": "仅在已验证的人请求时在此发帖。",
	"who.post.any": "在任何被允许的人请求时在此发帖。",
	"who.post.show": "显示该位置",
	"who.post.showFor": "显示 {{name}} 的位置",
	agentLink: "打开智能体 {{name}}",
	"saved.created": "已添加连接。",
	"saved.nothing": "已保存。没有更改。",
	"saved.changed": "已保存。已更改：{{what}}。",
	"saved.part.name": "名称",
	"saved.part.agent": "智能体",
	"saved.part.who": "接受的对象",
	"saved.part.permissions": "权限",
	"saved.part.approval": "触发器的审批和操作",
	"saved.part.files": "文件设置",
	"saved.part.notify": "通知",
	"saved.dropped.title": "此连接不再允许这些操作，因此这些触发器的运行会失去它们：",
	"saved.dropped.item": "{{name}}：{{acts}}",
	"conn.state.running": "运行中",
	"conn.state.off": "已关闭",
	"conn.state.attention": "需要处理",
	"conn.state.ready": "就绪",
	"conn.row.open": "{{name}}：{{state}}。显示详情",
	"conn.row.menu": "{{name}} 的更多操作",
	"conn.row.testNamed": "测试 {{name}}",
	"conn.fix.token": "修复令牌",
	"conn.reason.noToken": "未保存令牌。",
	"conn.reason.duplicate": "与 {{name}} 使用同一个机器人应答。",
	"conn.reason.testFailed": "上次测试失败：{{reason}}",
	"conn.kv.service": "服务",
	"conn.kv.accepts": "接受",
	"conn.kv.replies": "回复",
	"conn.kv.token": "令牌",
	"conn.kv.saved": "已保存",
	"conn.kv.notSaved": "未保存",
	"conn.kv.agents": "智能体",
	"usedBy.count_one": "被 {{count}} 个智能体使用",
	"usedBy.count_other": "被 {{count}} 个智能体使用",
	"usedBy.none": "没有智能体使用",
	"conn.pane.lastTest": "上次测试",
	"conn.pane.never": "尚未在此浏览器中测试。",
	"conn.pane.passed": "{{when}} 通过。",
	"conn.pane.failed": "{{when}} 失败。",
	"conn.pane.connection": "连接",
	"conn.pane.remove": "移除",
	"conn.pane.test": "测试连接",
	"conn.pane.testing": "正在测试...",
	"conn.sheet.addDesc": "为它命名，添加令牌，并选择负责应答的智能体。",
	"conn.sheet.editDesc": "更改在保存后生效。已保存的令牌不会再次显示。",
	"conn.sheet.connection": "连接",
	"conn.sheet.who": "谁可以与它对话",
	"conn.sheet.may": "它可以做什么",
	"conn.sheet.replies": "回复、文件和位置",
	"conn.sheet.check": "检查它将执行的操作",
	"conn.sheet.saveAndTest": "保存并测试",
	"conn.sheet.saving": "正在保存...",
	"conn.sheet.testFailed": "连接已保存，但测试失败。",
	"conn.sheet.testFailedNoReason": "未给出原因。",
	"conn.sheet.testAgain": "重新测试",
	"conn.sheet.close": "关闭",
	"conn.sheet.agentFixed": "使用智能体 {{name}} 应答",
	"conn.preset.label": "权限",
	"conn.preset.answer": "仅应答",
	"conn.preset.answerHelp": "只回复消息。此连接不会自行增加任何权限。",
	"conn.preset.standard": "标准",
	"conn.preset.standardHelp": "智能体拥有的常用权限：{{list}}。",
	"conn.preset.standardNone": "常用权限。此智能体没有其中任何一项。",
	"conn.preset.custom": "自定义",
	"conn.preset.customHelp": "逐项选择权限以及谁可以使用。",
	"conn.preset.note": "预设绝不会开启敏感权限。如需开启，请使用自定义。智能体所持有的插件连接有各自的规则：已验证的人仍可使用其写入工具。请在智能体的“可使用的内容”中更改。",
	"conn.discard.title": "放弃更改？",
	"conn.discard.message": "你修改了此连接但尚未保存。",
	"conn.discard.confirm": "放弃更改",
	"share.label": "共享",
	"share.button": "共享 {{name}}",
	"share.intro": "你添加的人可以在自己的聊天和智能体中使用此连接。他们能看到它的名称和状态，但永远看不到令牌或设置。发给机器人的消息仍由你的智能体接收。",
	"share.roleUse": "可以使用",
	"share.roleUseHelp": "可以在自己的聊天和智能体中使用。无法查看令牌、修改或再次共享。",
	"shared.title": "与你共享",
	"shared.text": "其他人允许你在自己的聊天和智能体中使用这些连接。只有所有者可以修改它们。",
	"shared.on": "监听中",
	"shared.off": "已关闭",
	"shared.by": "由 {{name}} 共享",
	loginNeedsHost: "此版本的 LocalAI 无法在本页登录。请更新 LocalAI 后在此连接。"
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.id.json
var connector_id_default = {
	"answer.title": "Tempat bot memposting dan cara membalas",
	"answer.replyLabel": "Saat agen bekerja",
	"answer.reply.off": "Mengetik, lalu jawaban",
	"answer.reply.progress": "Progres: alat yang dipakai",
	"answer.reply.stream": "Langsung: jawaban saat sedang ditulis",
	"answer.reply.reasoning": "Berpikir: proses berpikir model, lalu jawaban",
	"answer.replyHelp": "Progres dan Langsung menampilkan satu pesan proses, lalu jawaban menggantikannya. Di platform yang punya draf, Langsung menampilkan draf ke chat pribadi, lalu jawaban menyusul. Jawaban yang panjang dilanjutkan di pesan baru.",
	"answer.replyReasoningHelp": "Berpikir menampilkan proses berpikir model, saat ditulis, kepada setiap pengirim binding ini. Pakai hanya jika itu tidak masalah.",
	"answer.conversationLabel": "Percakapan",
	"answer.conversationHelp": "Kirim /new (atau !new) di aplikasi untuk memulai chat baru.",
	"answer.conversation.sender": "Satu chat per orang",
	"answer.conversation.chat": "Satu chat per grup atau kanal",
	"answer.conversation.window": "Per orang, baru setelah jeda",
	"answer.conversation.thread": "Chat baru per pesan; balasan dilanjutkan",
	"answer.window": "Jeda tanpa pesan, dalam menit",
	"answer.windowRange": "Gunakan bilangan bulat dari 1 sampai {{max}}.",
	"answer.languageLabel": "Bahasa balasan",
	"answer.languageHelp": "Catatan yang ditulis bot sendiri, seperti konfirmasi dan penolakan. Jawaban model mengikuti bahasa percakapan.",
	"answer.language.auto": "Otomatis (bahasa antarmuka Anda, jika tidak bahasa pengirim)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Kirim file yang dibuat agen",
	add: "Tambah",
	more: "Lainnya",
	less: "Lebih sedikit",
	"answer.filesHelp": "Setelah jawaban, hingga 5 file. Program dan skrip tidak dikirim. Batas ukuran ada di Ukuran berkas dan bahasa balasan.",
	"answer.summary": "Jawaban: {{reply}} · {{conversation}}",
	"answer.short.off": "mengetik",
	"answer.short.progress": "progres",
	"answer.short.stream": "jawaban langsung",
	"answer.short.reasoning": "proses berpikir terlihat",
	"answer.short.sender": "satu chat per orang",
	"answer.short.chat": "satu chat per grup",
	"answer.short.window": "chat baru setelah {{count}} mnt",
	"answer.short.thread": "satu chat per pesan",
	"approval.title": "Timer dan pemicu dari chat",
	"approval.help": "Saat agen menyiapkan sesuatu yang berjalan nanti (“dalam 10 menit”, “setiap hari”), setiap jalan adalah satu eksekusi model.",
	"approval.mode.ask": "Tanya dulu: bot mengusulkannya di chat dan orangnya menjawab ya atau tidak",
	"approval.mode.auto": "Langsung dijalankan: disiapkan dan orangnya diberi tahu cara membatalkannya",
	"approval.mode.auto_readonly": "Langsung dijalankan jika jalannya hanya membaca dan melapor; selain itu tanya dulu",
	"approval.limitsHelp": "Batas ini membatasi apa yang disiapkan tanpa bertanya. Kosongkan kolom untuk memakai nilai bawaan. Apa pun yang melebihi batas akan ditanyakan.",
	"approval.max_pending": "Jumlah timer dan pemicu terbanyak sekaligus",
	"approval.min_gap_minutes": "Menit paling sedikit antar jalan pemicu berulang",
	"approval.max_runs_per_day": "Jalan terbanyak per hari, secara total",
	"approval.max_lifetime_days": "Masa aktif terlama, dalam hari",
	"approval.invalid": "Gunakan bilangan bulat dari 1 sampai {{max}}, atau kosongkan.",
	"approval.default": "Bawaan: {{value}}.",
	"approval.summary": "Pemicu: {{mode}}",
	"approval.effect": "Usulan: {{mode}}",
	"approval.effectChange": "Perubahan dan penghapusan: {{mode}}",
	"approval.limits": "Batas",
	"approval.acts.title": "Jalan boleh bertindak",
	"approval.acts.help": "Nonaktif: jalan dari pemicu yang dibuat di chat ini hanya membaca dan melapor. Aktif: jalan juga boleh melakukan apa yang Anda centang di bawah, dan hanya yang dimiliki agen.",
	"approval.acts.modes": "Tanya dulu: Anda selalu memutuskan. Langsung dijalankan: hanya saat Anda orang terverifikasi dan setiap tindakan dicentang di sini.",
	"approval.acts.act.files": "Menulis file di folder agen",
	"approval.acts.act.files.effect": "Sebuah jalan dapat membuat dan mengubah file yang disimpan agen.",
	"approval.acts.act.addons": "Memakai aksi add-on milik agen",
	"approval.acts.act.addons.effect": "Sebuah jalan dapat memakai apa yang dilakukan add-on milik agen, termasuk perintah.",
	"approval.acts.act.send": "Mengirim pesan selain ke tempat ia melapor",
	"approval.acts.act.send.effect": "Sebuah jalan dapat menulis sendiri ke chat dan kanal lain.",
	"approval.acts.act.spend": "Memakai alat berbayar atau eksternal dan jaringan",
	"approval.acts.act.spend.effect": "Sebuah jalan dapat memanggil layanan di luar LocalAI, yang mungkin berbiaya.",
	"approval.acts.lacks": "Agen tidak memiliki ini.",
	"approval.acts.sensitive": "Sensitif",
	"approval.effectActs": ", jalan boleh: {{acts}}",
	"approval.actShort.act.files": "menulis file",
	"approval.actShort.act.addons": "memakai add-on",
	"approval.actShort.act.send": "mengirim pesan",
	"approval.actShort.act.spend": "memakai alat berbayar atau eksternal",
	"approval.short.ask": "tanya dulu",
	"approval.short.auto": "langsung dijalankan",
	"approval.short.auto_readonly": "langsung dijalankan jika hanya baca",
	"files.title": "File",
	"files.help": "Kosongkan kolom untuk memakai batas add-on. Batas Anda hanya boleh lebih rendah dari itu.",
	"files.receiveLabel": "File terbesar yang dibaca, dalam MiB",
	"files.sendLabel": "File terbesar yang dikirim, dalam MiB",
	"files.invalid": "Gunakan angka lebih besar dari 0.",
	"files.tooHigh": "Add-on mengizinkan paling banyak {{max}} di sini.",
	"files.now": "Sekarang: {{limit}} ({{layer}}).",
	"files.receiveHelp": "File yang dikirim orang ke bot. File yang lebih besar ditolak, dan bot menyebut batas mana yang tercapai.",
	"files.sendHelp": "File yang dibuat agen dan dikirim kembali oleh bot. File yang lebih besar tidak dikirim, dan bot menyebut batas mana yang tercapai.",
	"files.addon.off": "Add-on ini tidak memindahkan file ke arah ini, jadi tidak ada yang perlu diatur.",
	"files.addon.declared": "Add-on menyatakan hingga {{max}}.",
	"files.addon.open": "Add-on tidak menyatakan batas, jadi batas platform berlaku.",
	"files.host": "Tidak ada bot yang dapat memindahkan file di atas {{max}}. Administrator mengaturnya di pengaturan.",
	"files.layer.owner": "batas yang ditetapkan untuk bot ini",
	"files.layer.addon": "batas add-on",
	"files.layer.host": "batas platform",
	"perm.agentLacks": "Agen tidak memiliki ini.",
	"perm.rule": "Orang yang terdaftar dapat memakai izin yang dicentang. Izin sensitif juga mengharuskan orang terverifikasi.",
	"perm.sensitive": "Hanya orang terverifikasi",
	"perm.sensitiveHelp": "Sensitif. Tidak pernah diberikan ke peran. Hanya orang terverifikasi yang dapat memakainya, dan setiap pemakaian dicatat.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Tempat ia boleh memposting",
	"perm.channelsHelp": "Tempat agen boleh memposting saat orang yang terdaftar memintanya, selain chat tempat ia menjawab. Ini tidak menentukan siapa yang didengar bot: lihat Kanal tempat bot mendengarkan. Paling banyak {{max}}.",
	"perm.channelsOff": "Aktifkan “Posting ke kanal lain” di atas untuk memilih tempat yang boleh diposting bot.",
	"perm.channelId": "ID kanal",
	"perm.channelLabel": "Nama",
	"perm.channelAdd": "Tambah tempat",
	"perm.channelRemove": "Hapus tempat {{id}}",
	"perm.remove": "Hapus",
	"perm.channelFull": "Daftar sudah penuh.",
	"perm.channelProblem.id": "Setiap tempat memerlukan ID sepanjang 1 sampai {{max}} byte, tanpa spasi.",
	"perm.channelProblem.label": "Nama paling banyak {{max}} karakter.",
	"perm.channelProblem.repeat": "Sebuah tempat terdaftar dua kali.",
	"perm.channelProblem.count": "Paling banyak {{max}} tempat.",
	"perm.triggersNeed": "Aktifkan Usulkan pemicu untuk memakai ini.",
	"pair.start": "Verifikasi orang",
	"pair.startHelp": "Membuat kode. Kirim kode itu ke bot sebagai pesan langsung dari akun yang akan diverifikasi, dalam sepuluh menit. Kode hanya berlaku sekali.",
	"pair.needSave": "Simpan bot ini terlebih dahulu, lalu verifikasi orang.",
	"pair.codeTitle": "Kode verifikasi Anda",
	"pair.codeHelp": "Kirim kode ini ke bot sebagai pesan langsung dari akun yang akan diverifikasi. Kode ini hanya ditampilkan sekarang, berlaku sekali, dan kedaluwarsa pada {{time}}.",
	"pair.codeGone": "Kode sudah kedaluwarsa. Buat yang baru jika orang tersebut belum terverifikasi.",
	"pair.done": "Terverifikasi: {{sender}}.",
	"pair.dismiss": "Sembunyikan kode",
	"pair.none": "Belum ada yang terverifikasi.",
	"pair.expires": "berakhir {{time}}",
	"pair.full": "Tiga orang sudah terverifikasi. Hapus satu untuk memverifikasi yang lain.",
	"access.title": "Periksa",
	"access.needSave": "Simpan bot ini dulu untuk melihat siapa yang baru saja ditolaknya.",
	"access.refresh": "Segarkan",
	"access.who": "pengirim {{senders}}",
	"can.sender.role": "Peran: {{title}}",
	"can.fromForm": "Dihitung dari formulir sebagaimana adanya sekarang. Simpan untuk mempertahankan pengaturan ini.",
	"can.fromFormNew": "Belum disimpan. Dihitung dari formulir sebagaimana adanya sekarang.",
	"can.loading": "Memeriksa apa yang bisa dilakukan bot ini",
	"can.stale": "Memperbarui",
	"can.errorTitle": "Tidak dapat memeriksa apa yang bisa dilakukan bot ini",
	"can.retry": "Coba lagi",
	"can.allowed": "Diizinkan",
	"can.via.paired": "karena orang ini terverifikasi",
	"can.via.allowlist": "karena orang ini terdaftar",
	"can.via.agentConnection": "karena orang ini terverifikasi dan agen terhubung ke add-on",
	"can.via.role": "lewat peran {{role}}",
	"can.then": "Belum diperiksa: {{list}}.",
	"can.then.server": "pengaturan server",
	"can.then.tools": "sakelar Alat milik agen",
	"can.then.agent": "izin agen",
	"can.then.connection": "izin koneksi ini",
	"can.then.sender": "siapa yang mengirim",
	"can.then.approval": "cara usulan dikonfirmasi",
	"can.noMessage": "Tidak diizinkan.",
	"fix.open_connection": "Tampilkan pengaturan",
	"fix.open_agent": "Buka agen",
	"fix.open_server_setting": "Buka Pengaturan",
	"fix.pair_sender": "Verifikasi orang",
	"fix.add_person": "Tambah orang",
	"fix.save": "Simpan perubahan ini",
	"fix.token": "Tempel token",
	"fix.tokenNew": "Tempel token baru",
	"fix.agent": "Pilih agen",
	"fix.usual": "Pilih izin",
	"fix.turnOn": "Aktifkan",
	"fix.newTab": "(dibuka di tab baru)",
	"fix.askAdmin": "Tanya administrator",
	"ready.title": "Status",
	"ready.checkingSummary": "Memeriksa apa yang akan dilakukan formulir.",
	"ready.allGood": "Semua yang diperlukan sudah ada.",
	"ready.showAll": "Tampilkan semua {{count}}",
	"ready.showProblems": "Tampilkan hanya yang perlu perhatian",
	"ready.checking": "Memeriksa.",
	"ready.unchecked": "Tidak dapat memeriksa ini. Lihat “Apa yang bisa dilakukan bot ini” di bawah.",
	"ready.row.token": "Token",
	"ready.row.agent": "Agen",
	"ready.row.who": "Siapa yang boleh memakai",
	"ready.row.permissions": "Izin",
	"ready.row.addons": "Alat add-on",
	"ready.row.triggers": "Pemicu",
	"ready.row.files": "File",
	"ready.row.notify": "Notifikasi",
	"ready.state.ok": "OK",
	"ready.state.attention": "Perlu perhatian",
	"ready.state.off": "Nonaktif",
	"ready.state.after_save": "Setelah disimpan",
	"ready.state.broken": "Tidak berfungsi",
	"ready.state.checking": "Memeriksa",
	"ready.state.unknown": "Tidak diketahui",
	"ready.token.missing": "Tempel token bot. Tanpa token, tidak ada yang diterima.",
	"ready.token.newTyped": "Token diperiksa ke platform saat Anda menyimpan.",
	"ready.token.typed": "Token baru diperiksa ke platform saat Anda menyimpan.",
	"ready.token.failed": "Platform menolak token: {{reason}}",
	"ready.token.checked": "Platform menerima token. {{bot}}",
	"ready.token.saved": "Token sudah tersimpan. Platform menerimanya saat disimpan.",
	"ready.agent.none": "Pilih agen yang menjawab.",
	"ready.agent.credentialsOnly": "Tanpa agen. Koneksi ini hanya menyimpan kredensial dan tidak menjawab pesan.",
	"ready.agent.gone": "Agen yang dipilih tidak ada lagi di daftar Anda. Pilih yang lain.",
	"ready.agent.noModel": "{{name}} tidak punya model, jadi tidak dapat menjawab. Berikan satu model.",
	"ready.agent.ok": "{{name}} menjawab, dengan model {{model}}.",
	"ready.agent.okUnknown": "Agen sudah dipilih.",
	"ready.who.anyone": "Siapa saja yang dapat mengirim pesan ke bot boleh memakainya.",
	"ready.who.nobody": "Belum ada yang terdaftar, jadi bot mengabaikan semua pesan. Tambahkan orang.",
	"ready.who.channelsOnly": "Hanya kanal yang ada di daftar. Orang di kanal dapat mengobrol, tetapi mereka memakai izin yang dicentang hanya jika kanal disetel ke Biarkan semua orang di sini meminta tindakan.",
	"ready.who.listed_one": "{{count}} orang atau chat terdaftar.",
	"ready.who.listed_other": "{{count}} orang atau chat terdaftar.",
	"ready.who.mixed": "{{count}} entri terdaftar, orang dan kanal.",
	"ready.perm.none": "Tidak ada izin yang aktif. Pengirim dapat chat, dan tidak lebih.",
	"ready.perm.noneSaved": "Tidak ada izin yang aktif, jadi file, memori, pemicu, dan posting nonaktif.",
	"ready.perm.onlyOwnRows": "Izin lainnya nonaktif. Pemicu dan file ada di bawah.",
	"ready.perm.ok_one": "{{count}} izin aktif dan pengirim dapat memakainya.",
	"ready.perm.ok_other": "{{count}} izin aktif dan pengirim dapat memakainya.",
	"ready.perm.dead_one": "Tidak ada yang dapat memakai {{names}}. {{message}}",
	"ready.perm.dead_other": "Tidak ada yang dapat memakai {{count}} izin yang aktif: {{names}}. Pertama: {{message}}",
	"ready.addons.off": "Agen memiliki alat {{addon}} {{tools}}, tetapi tidak bisa memakainya di obrolan ini sampai Anda mengaktifkan \"{{permission}}\".",
	"ready.addons.blocked": "Agen memiliki alat {{addon}} {{tools}}, tetapi ditahan. {{message}}",
	"ready.addons.ok": "Agen dapat memakai alat {{addon}} {{tools}} di obrolan ini.",
	"ready.addons.paired": "Orang terverifikasi dapat memakai alat tulis {{addon}} ({{tools}}) di obrolan ini, karena agen terhubung ke {{connection}} (mode tulis: {{mode}}). Orang yang terdaftar tetapi belum terverifikasi memerlukan \"{{permission}}\".",
	"ready.addons.removed": "Anda mematikan \"{{permission}}\", jadi tidak ada yang dapat memakai alat tulis {{addon}} ({{tools}}) di obrolan ini, termasuk orang terverifikasi. Aktifkan untuk mengembalikannya; orang yang terdaftar tetapi belum terverifikasi juga mendapatkannya.",
	"ready.addons.modeOff": "Agen memiliki alat tulis {{addon}} ({{tools}}), tetapi ditahan karena mode tulis {{connection}} mati. Ubah mode tulis pada koneksi itu.",
	"ready.addons.mode.auto": "langsung dijalankan",
	"ready.addons.mode.propose": "tanya dulu",
	"ready.triggers.off": "Agen tidak dapat menyetel pengingat atau tugas terjadwal di sini.",
	"ready.triggers.blocked": "Pemicu aktif, tetapi tidak dapat dipakai. {{message}}",
	"ready.triggers.ok.ask": "Agen dapat mengusulkan pemicu. Anda mengonfirmasi tiap pemicu sebelum dimulai.",
	"ready.triggers.ok.auto": "Agen dapat mengusulkan pemicu. Pemicu langsung dimulai, tanpa bertanya kepada Anda.",
	"ready.triggers.ok.auto_readonly": "Agen dapat mengusulkan pemicu. Pemicu yang hanya membaca langsung dimulai; pemicu lain Anda konfirmasi.",
	"ready.files.offReceive": "Pengirim tidak dapat mengirim file ke agen.",
	"ready.files.offBoth": "Pengirim tidak dapat mengirim file ke agen, dan bot tidak mengirim file kembali.",
	"ready.files.blocked": "Menerima file aktif, tetapi tidak dapat dipakai. {{message}}",
	"ready.files.ok": "Pengirim dapat mengirim file ke agen, dan bot dapat mengirim file kembali.",
	"ready.files.okReceive": "Pengirim dapat mengirim file ke agen. Bot tidak mengirim file kembali.",
	"ready.notify.off": "Tidak ada chat yang menerima notifikasi dari bot ini.",
	"ready.notify.ok": "Notifikasi dikirim ke chat {{chat}}.",
	dismiss: "Abaikan",
	credentialsOnly: "Hanya kredensial",
	agentCredentialsOnly: "Tanpa agen (hanya kredensial)",
	agentOptionalHint: "Opsional. Tanpa agen, koneksi ini hanya menyimpan token, daftar repositori, dan mode tulis untuk chat Anda. Koneksi tidak menjawab pesan. Pilih agen agar koneksi mulai mendengarkan.",
	"sender.line_one": "{{name}} · {{count}} pesan · {{id}}",
	"sender.line_other": "{{name}} · {{count}} pesan · {{id}}",
	"ready.blocker.nobodyLetIn": "Belum ada yang diizinkan masuk.",
	"ready.blocker.nobodyPaired": "Ini memerlukan orang terverifikasi, dan belum ada yang terverifikasi.",
	optional: "opsional",
	"approvals.title": "Alat yang langsung dijalankan",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "Tanya dulu",
	"approvals.state.runs": "Langsung dijalankan",
	"approvals.state.idle": "Diatur untuk langsung dijalankan, tidak melakukan apa pun sekarang",
	"approvals.state.other": "Masih tanya dulu ke pengirim ini",
	"approvals.line.asks": "Kartu menunggu OK Anda.",
	"approvals.line.runs": "Untuk chat milik pemilik sendiri dan untuk orang terverifikasi. Semua orang lain tetap ditanya.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "Hanya pemilik dan orang terverifikasi yang tidak perlu kartu. Pengirim jenis ini tetap ditanya.",
	"dup.text": "Bot ini juga terhubung sebagai {{name}}. Kedua koneksi akan menjawab pesan yang sama.",
	"dup.turnOff": "Matikan yang ini",
	"dup.openOther": "Buka {{name}}",
	"dup.saveAnyway": "Tetap simpan",
	"dup.goBack": "Kembali",
	"dup.confirmHelp": "Tetap simpan hanya jika Anda ingin menerima dua jawaban untuk setiap pesan.",
	"access.noteSave.title": "Catatan",
	"access.noteSave.now": "Menyimpan catatan langsung dan memberi tahu, dengan Urungkan",
	"access.noteSave.ask": "Catatan dari jenis pengirim ini menunggu pemilik",
	"trust.answer": "Hanya menjawab",
	"trust.act": "Biarkan semua orang di sini meminta tindakan",
	"ready.row.channelTrust": "Kanal tempat bot mendengarkan",
	"ready.row.postTo": "Tempat ia boleh memposting",
	"ready.channelTrust.act": "Orang di {{channels}} dapat meminta tindakan sehari-hari. Yang sensitif tetap butuh orang terverifikasi.",
	"ready.channelTrust.answer": "Orang di {{channels}} tidak dapat memakai tindakan: setel ke Biarkan semua orang di sini meminta tindakan.",
	"ready.channelTrust.noCaps": "Tidak ada yang dicentang di izin, jadi file dan tindakan lain ditolak bahkan di tempat semua orang boleh meminta.",
	"fix.trust": "Atur kanal",
	"can.via.channel": "Semua orang di kanal ini dapat memintanya karena kanal disetel ke Biarkan semua orang di sini meminta tindakan",
	"ready.postTo_one": "Bot boleh memposting ke 1 tempat lain saat orang yang terdaftar memintanya. Itu tidak membuat orang di dalamnya dipercaya.",
	"ready.postTo_other": "Bot boleh memposting ke {{count}} tempat lain saat orang yang terdaftar memintanya. Itu tidak membuat orang di dalamnya dipercaya.",
	"access.toolsTitle": "Panggilan alat add-on",
	"access.toolsHelp": "Panggilan terbaru ke alat add-on yang memakai koneksi ini atau masuk lewat bot ini, terbaru dulu, paling banyak 20. Isinya nama alat dan alasan, tidak pernah apa yang diminta atau dijawab. Daftar ini direset saat server dimulai ulang.",
	"access.toolsNone": "Belum ada panggilan.",
	"access.outcome.ok": "berhasil",
	"access.outcome.held": "ditahan",
	"access.outcome.denied": "ditolak",
	"access.outcome.error": "gagal",
	"ready.addons.confirmChat": "Orang terverifikasi dapat mengonfirmasi penulisan {{addon}} di obrolan: bot menuliskan setiap permintaan di sana dan mereka menjawab ya atau tidak.",
	"access.outcome.confirmed": "dikonfirmasi",
	"access.outcome.cancelled": "dibatalkan",
	"access.outcome.expired": "kedaluwarsa",
	"access.askedBy": "diminta oleh {{sender}}",
	"access.chat": "di {{chat}}",
	"sender.chat": "di {{chat}}",
	"sender.reason.not_listed": "bukan orang yang terdaftar",
	"sender.reason.not_addressed": "pesan tidak menyebut bot",
	"ready.notReady": "Belum siap.",
	"ready.fixCount_one": "{{count}} hal untuk diperbaiki",
	"ready.fixCount_other": "{{count}} hal untuk diperbaiki",
	"ready.quiet_one": "{{count}} hal untuk diatur",
	"ready.quiet_other": "{{count}} hal untuk diatur",
	"ready.quietDone": "Tidak ada lagi yang perlu diatur",
	"matrix.title": "Siapa boleh melakukan apa",
	"loops.title": "Penantian dan pewaktu",
	"loops.help": "Apa yang boleh dilakukan agen nanti di obrolan ini dengan sendirinya. Ini milik bot: peran tidak pernah mendapatkannya.",
	"matrix.note": "Sakelar dan kotak peran Anda yang mengatur. Sel lainnya dihitung dari pengaturan Anda saat ini, dengan pemeriksaan yang sama yang dijalankan host untuk setiap pesan.",
	"matrix.capability": "Izin",
	"matrix.pick": "Jenis pengirim",
	"matrix.col.on": "Aktif untuk bot ini",
	"matrix.col.paired": "Orang terverifikasi",
	"matrix.col.listed": "Orang yang terdaftar",
	"matrix.col.channel_acts": "Kanal: semua minta tindakan",
	"matrix.col.channel_member": "Kanal: hanya menjawab",
	"matrix.col.anyone": "Siapa saja",
	"matrix.state.yes": "Ya",
	"matrix.state.asks": "Tanya dulu",
	"matrix.state.no": "Tidak",
	"matrix.state.waiting": "Menunggu konfirmasi orang",
	"matrix.state.off": "Nonaktif",
	"matrix.state.unknown": "Tidak diketahui",
	"matrix.row.tools": "Mengubah data di layanan terhubung",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Mengapa sel bertuliskan Tidak atau Nonaktif",
	"matrix.detail.none": "Pilih sebuah sel untuk membaca alasannya.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Setel ulang ke set yang biasa",
	"matrix.more": "Detail",
	"matrix.less": "Sembunyikan detail",
	"matrix.nobodyVerified": "Belum ada yang terverifikasi.",
	"who.title": "Siapa yang boleh berbicara dengan bot",
	"who.onlyChosen": "Hanya orang yang saya pilih",
	"who.anyone": "Siapa pun yang bisa mengirim pesan kepadanya",
	"who.people": "Orang",
	"who.peopleAndChannels": "Orang dan kanal",
	"who.peopleNone": "Belum ada yang terdaftar. Tambahkan orang di bawah.",
	"who.channels": "Kanal",
	"who.channelsNote": "Orang di sebuah kanal hanya dapat bertindak di dalam kanal itu, tidak pernah di pesan langsung.",
	"who.add": "Tambah orang atau kanal",
	"who.recent": "Orang yang baru-baru ini menulis ke bot. Klik untuk menambahkan.",
	"who.addPerson": "Tambah {{name}}",
	"who.verified": "Terverifikasi",
	"who.listed": "Terdaftar",
	"who.verify": "Verifikasi",
	"who.verifyPerson": "Verifikasi {{name}}",
	"who.remove": "Hapus",
	"who.removePerson": "Hapus {{name}}",
	"who.removeChannel": "Hapus {{name}}",
	"who.levelFor": "Apa yang dapat dilakukan orang di {{channel}}",
	"answer.more": "Ukuran berkas dan bahasa balasan",
	"perm.channelsSwitch": "Buka sakelarnya",
	"perm.channelWho": "Siapa yang boleh menyuruhnya memposting",
	"perm.channelWhoFor": "Siapa yang boleh menyuruh bot memposting di {{id}}",
	"perm.channelWho.any": "Saat orang yang diizinkan meminta",
	"perm.channelWho.verified": "Hanya saat orang yang terverifikasi meminta",
	"notify.label": "Kirim pengingat dan hasil eksekusi saya ke",
	"notify.none": "Tidak ke mana pun",
	"notify.people": "Orang",
	"notify.channels": "Kanal",
	"notify.saved": "{{id}} (ID tersimpan)",
	"notify.other": "ID lain...",
	"notify.otherLabel": "ID obrolan",
	"try.title": "Coba",
	"try.help": "Pilih siapa yang menulis, di mana, dan apa yang diminta. Ini menjalankan pemeriksaan yang dilakukan host untuk setiap pesan, pada formulir seperti sekarang.",
	"try.noone": "Tambahkan seseorang dulu. Setelah itu Anda bisa mencoba apa yang boleh dilakukannya.",
	"try.whoLabel": "Siapa",
	"try.placeLabel": "Di mana",
	"try.actionLabel": "Apa yang diminta",
	"try.someoneIn": "Seseorang di {{channel}}",
	"try.anyone": "Siapa saja",
	"try.role": "Seseorang dengan peran {{role}}",
	"try.dm": "Pesan langsung",
	"try.where.dm": "dalam pesan langsung",
	"try.where.channel": "di {{channel}}",
	"try.is.paired": "{{who}} adalah orang yang terverifikasi, menulis {{where}}.",
	"try.is.listed": "{{who}} adalah orang dalam daftar, menulis {{where}}.",
	"try.is.channelActs": "Seseorang di {{channel}}, tempat semua orang boleh meminta tindakan.",
	"try.is.channelAnswers": "Seseorang di {{channel}}, tempat orang hanya mendapat jawaban.",
	"try.is.anyone": "Siapa pun yang dapat mengirim pesan ke bot diizinkan masuk.",
	"try.is.role": "Orang dengan peran {{role}} diizinkan masuk.",
	"try.verdict.allowed": "Diizinkan.",
	"try.verdict.asks": "Diizinkan, tetapi bertanya dulu.",
	"try.verdict.refused": "Ditolak.",
	"try.loading": "Memeriksa...",
	"try.error": "Pemeriksaan tidak menjawab. Gunakan Coba lagi di tabel di atas.",
	"try.unknown": "Host tidak memberi jawaban untuk jenis pengirim ini.",
	"try.note": "Tidak ada yang dikirim ke platform dan tidak ada yang disimpan.",
	"refusals.title": "Penolakan terbaru",
	"refusals.help": "Hal yang ditolak bot sejak server dimulai, yang terbaru dulu. Isinya ID, nama, dan obrolan, bukan teks pesan. Log ini hanya disimpan di memori: kosong setelah server dimulai ulang.",
	"refusals.none": "Tidak ada yang ditolak sejak server dimulai.",
	"refusals.refused": "ditolak",
	"refusals.action": "meminta: {{action}}",
	"refusals.talk": "menulis ke bot",
	"refusals.allow": "Izinkan {{name}}",
	"refusals.act": "Izinkan anggota {{channel}} bertindak",
	"perm.channelPickOther": "Lainnya: ketik ID",
	"perm.channelHint.verified": "Jalan terjadwal tidak bisa memposting di sini. Pilih \"Saat orang yang diizinkan meminta\" agar bisa.",
	"perm.channelHint.any": "Jalan terjadwal bisa memposting di sini.",
	"perm.channelNoListen": "Bot tidak mendengarkan di kanal ini, jadi hanya akan memposting di sana.",
	"who.post.none": "Bot tidak bisa memposting di sini.",
	"who.post.add": "Izinkan bot memposting di sini juga",
	"who.post.addFor": "Izinkan bot memposting juga di {{name}}",
	"who.post.verified": "Memposting di sini hanya saat orang terverifikasi meminta.",
	"who.post.any": "Memposting di sini saat orang yang diizinkan meminta.",
	"who.post.show": "Tampilkan tempatnya",
	"who.post.showFor": "Tampilkan tempat untuk {{name}}",
	agentLink: "Buka agen {{name}}",
	"saved.created": "Koneksi ditambahkan.",
	"saved.nothing": "Tersimpan. Tidak ada yang berubah.",
	"saved.changed": "Tersimpan. Berubah: {{what}}.",
	"saved.part.name": "nama",
	"saved.part.agent": "agen",
	"saved.part.who": "siapa yang diterima",
	"saved.part.permissions": "izin",
	"saved.part.approval": "persetujuan dan tindakan pemicu",
	"saved.part.files": "pengaturan berkas",
	"saved.part.notify": "notifikasi",
	"saved.dropped.title": "Koneksi ini tidak lagi mengizinkan tindakan ini, sehingga eksekusi pemicu berikut kehilangannya:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "Berjalan",
	"conn.state.off": "Mati",
	"conn.state.attention": "Perlu perhatian",
	"conn.state.ready": "Siap",
	"conn.row.open": "{{name}}: {{state}}. Tampilkan detail",
	"conn.row.menu": "Tindakan lain untuk {{name}}",
	"conn.row.testNamed": "Uji {{name}}",
	"conn.fix.token": "Perbaiki token",
	"conn.reason.noToken": "Belum ada token yang disimpan.",
	"conn.reason.duplicate": "Menjawab dengan bot yang sama seperti {{name}}.",
	"conn.reason.testFailed": "Pengujian terakhir gagal: {{reason}}",
	"conn.kv.service": "Layanan",
	"conn.kv.accepts": "Menerima",
	"conn.kv.replies": "Balasan",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Tersimpan",
	"conn.kv.notSaved": "Belum tersimpan",
	"conn.kv.agents": "Agen",
	"usedBy.count_one": "Dipakai oleh {{count}} agen",
	"usedBy.count_other": "Dipakai oleh {{count}} agen",
	"usedBy.none": "Tidak dipakai agen mana pun",
	"conn.pane.lastTest": "Pengujian terakhir",
	"conn.pane.never": "Belum diuji di browser ini.",
	"conn.pane.passed": "Lulus {{when}}.",
	"conn.pane.failed": "Gagal {{when}}.",
	"conn.pane.connection": "Koneksi",
	"conn.pane.remove": "Hapus",
	"conn.pane.test": "Uji koneksi",
	"conn.pane.testing": "Menguji...",
	"conn.sheet.addDesc": "Beri nama, tambahkan token, lalu pilih agen yang menjawab.",
	"conn.sheet.editDesc": "Perubahan berlaku saat Anda menyimpan. Token yang tersimpan tidak pernah ditampilkan lagi.",
	"conn.sheet.connection": "Koneksi",
	"conn.sheet.who": "Siapa yang boleh mengobrol dengannya",
	"conn.sheet.may": "Apa yang boleh dilakukannya",
	"conn.sheet.replies": "Balasan, file, dan tempat",
	"conn.sheet.check": "Periksa apa yang akan dilakukannya",
	"conn.sheet.saveAndTest": "Simpan dan uji",
	"conn.sheet.saving": "Menyimpan...",
	"conn.sheet.testFailed": "Koneksi sudah tersimpan, tetapi pengujian gagal.",
	"conn.sheet.testFailedNoReason": "Tidak ada alasan yang diberikan.",
	"conn.sheet.testAgain": "Uji lagi",
	"conn.sheet.close": "Tutup",
	"conn.sheet.agentFixed": "Menjawab dengan agen {{name}}",
	"conn.preset.label": "Izin",
	"conn.preset.answer": "Hanya menjawab",
	"conn.preset.answerHelp": "Membalas pesan. Koneksi ini tidak menambah izin sendiri.",
	"conn.preset.standard": "Standar",
	"conn.preset.standardHelp": "Set yang biasa dimiliki agen: {{list}}.",
	"conn.preset.standardNone": "Set yang biasa. Agen ini tidak memilikinya.",
	"conn.preset.custom": "Kustom",
	"conn.preset.customHelp": "Pilih setiap izin dan siapa yang boleh memakainya.",
	"conn.preset.note": "Preset tidak pernah mengaktifkan izin sensitif. Gunakan Kustom untuk itu. Koneksi add-on yang dimiliki agen punya aturan sendiri: orang terverifikasi tetap dapat memakai alat tulisnya. Ubah di agen, pada \"Yang dapat digunakan\".",
	"conn.discard.title": "Buang perubahan?",
	"conn.discard.message": "Anda mengubah koneksi ini dan belum menyimpannya.",
	"conn.discard.confirm": "Buang perubahan",
	"share.label": "Bagikan",
	"share.button": "Bagikan {{name}}",
	"share.intro": "Orang yang Anda tambahkan dapat memakai koneksi ini di obrolan dan agen mereka sendiri. Mereka melihat nama dan statusnya, tidak pernah tokennya atau pengaturannya. Pesan ke bot tetap sampai ke agen Anda.",
	"share.roleUse": "Dapat memakai",
	"share.roleUseHelp": "Dapat memakainya di obrolan dan agen mereka. Tidak dapat melihat token, mengubah, atau membagikannya.",
	"shared.title": "Dibagikan kepada Anda",
	"shared.text": "Orang lain mengizinkan Anda memakai koneksi ini di obrolan dan agen Anda. Hanya pemiliknya yang dapat mengubahnya.",
	"shared.on": "Mendengarkan",
	"shared.off": "Mati",
	"shared.by": "Dibagikan oleh {{name}}",
	loginNeedsHost: "Versi LocalAI ini tidak dapat masuk dari halaman ini. Perbarui LocalAI untuk terhubung di sini."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.ko.json
var connector_ko_default = {
	"answer.title": "어디에 게시하고 어떻게 답하는지",
	"answer.replyLabel": "에이전트가 작업하는 동안",
	"answer.reply.off": "입력 중 표시 후 답변",
	"answer.reply.progress": "진행 상황: 사용하는 도구",
	"answer.reply.stream": "실시간: 작성되는 대로 답변 표시",
	"answer.reply.reasoning": "추론: 모델의 추론 과정, 그다음 답변",
	"answer.replyHelp": "진행 상황과 실시간은 작업 중 메시지 하나를 보여 주고, 답변이 나오면 그 메시지를 대체합니다. 초안을 지원하는 플랫폼에서 실시간은 비공개 채팅에 초안을 대신 보여 주고, 이어서 답변이 옵니다. 긴 답변은 새 메시지로 이어집니다.",
	"answer.replyReasoningHelp": "추론은 모델이 쓰는 추론 과정을 이 연결의 모든 발신자에게 보여 줍니다. 그래도 괜찮은 곳에서만 사용하세요.",
	"answer.conversationLabel": "대화",
	"answer.conversationHelp": "앱에서 /new (또는 !new)를 보내면 새 채팅이 시작됩니다.",
	"answer.conversation.sender": "사람마다 채팅 하나",
	"answer.conversation.chat": "그룹이나 채널마다 채팅 하나",
	"answer.conversation.window": "사람마다, 조용한 시간이 지나면 새로 시작",
	"answer.conversation.thread": "메시지마다 새 채팅, 답글은 이어짐",
	"answer.window": "조용한 시간(분)",
	"answer.windowRange": "1부터 {{max}}까지의 정수를 입력하세요.",
	"answer.languageLabel": "답변 언어",
	"answer.languageHelp": "확인이나 거절처럼 봇이 직접 쓰는 안내문입니다. 모델의 답변은 대화의 언어를 따릅니다.",
	"answer.language.auto": "자동 (사용 중인 인터페이스 언어, 없으면 보낸 사람의 언어)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "에이전트가 만든 파일 보내기",
	add: "추가",
	more: "더 보기",
	less: "간단히",
	"answer.filesHelp": "답변 뒤에 파일을 최대 5개 보냅니다. 프로그램과 스크립트는 보내지 않습니다. 크기 제한은 파일 크기와 답변 언어에서 설정합니다.",
	"answer.summary": "답변: {{reply}} · {{conversation}}",
	"answer.short.off": "입력 중 표시",
	"answer.short.progress": "진행 상황",
	"answer.short.stream": "실시간 답변",
	"answer.short.reasoning": "추론 표시",
	"answer.short.sender": "사람마다 채팅",
	"answer.short.chat": "그룹마다 채팅",
	"answer.short.window": "{{count}}분 후 새 채팅",
	"answer.short.thread": "메시지마다 채팅",
	"approval.title": "채팅의 타이머와 트리거",
	"approval.help": "에이전트가 나중에 실행될 작업(\"10분 뒤\", \"매일\")을 설정하면, 실행할 때마다 모델이 한 번 실행됩니다.",
	"approval.mode.ask": "먼저 묻기: 봇이 채팅에서 제안하고 상대가 예 또는 아니요로 답합니다",
	"approval.mode.auto": "바로 실행: 설정되고 취소하는 방법을 상대에게 알림",
	"approval.mode.auto_readonly": "실행이 읽고 보고하기만 하면 바로 실행, 그 외에는 먼저 묻기",
	"approval.limitsHelp": "이 한도는 묻지 않고 설정할 수 있는 범위를 제한합니다. 비워 두면 기본값을 씁니다. 한도를 넘는 것은 대신 묻습니다.",
	"approval.max_pending": "동시에 둘 수 있는 타이머와 트리거의 최대 개수",
	"approval.min_gap_minutes": "반복 트리거 실행 사이의 최소 간격(분)",
	"approval.max_runs_per_day": "하루 총 실행 횟수 상한",
	"approval.max_lifetime_days": "최대 유지 기간(일)",
	"approval.invalid": "1부터 {{max}}까지의 정수를 입력하거나 비워 두세요.",
	"approval.default": "기본값: {{value}}.",
	"approval.summary": "트리거: {{mode}}",
	"approval.effect": "제안: {{mode}}",
	"approval.effectChange": "변경과 삭제: {{mode}}",
	"approval.limits": "한도",
	"approval.acts.title": "실행이 할 수 있는 동작",
	"approval.acts.help": "꺼짐: 이 채팅에서 만든 트리거의 실행은 읽고 보고하기만 합니다. 켜짐: 아래에서 선택한 동작도 할 수 있으며, 에이전트가 가진 권한 범위에서만 가능합니다.",
	"approval.acts.modes": "먼저 묻기: 항상 직접 결정합니다. 바로 실행: 검증된 사람이고 모든 동작이 여기서 선택된 경우에만 적용됩니다.",
	"approval.acts.act.files": "에이전트의 폴더에 파일 쓰기",
	"approval.acts.act.files.effect": "실행이 에이전트가 보관하는 파일을 만들고 바꿀 수 있습니다.",
	"approval.acts.act.addons": "에이전트의 애드온 동작 사용",
	"approval.acts.act.addons.effect": "실행이 에이전트의 애드온이 하는 일을 명령까지 포함해 사용할 수 있습니다.",
	"approval.acts.act.send": "보고하는 곳 밖으로 메시지 보내기",
	"approval.acts.act.send.effect": "실행이 스스로 다른 채팅과 채널에 쓸 수 있습니다.",
	"approval.acts.act.spend": "유료 또는 외부 도구와 네트워크 사용",
	"approval.acts.act.spend.effect": "실행이 LocalAI 밖의 서비스를 호출할 수 있으며 비용이 발생할 수 있습니다.",
	"approval.acts.lacks": "에이전트에게 이 권한이 없습니다.",
	"approval.acts.sensitive": "민감함",
	"approval.effectActs": ", 실행이 할 수 있는 동작: {{acts}}",
	"approval.actShort.act.files": "파일 쓰기",
	"approval.actShort.act.addons": "애드온 사용",
	"approval.actShort.act.send": "메시지 보내기",
	"approval.actShort.act.spend": "유료 또는 외부 도구 사용",
	"approval.short.ask": "먼저 묻기",
	"approval.short.auto": "바로 실행",
	"approval.short.auto_readonly": "읽기 전용이면 바로 실행",
	"files.title": "파일",
	"files.help": "비워 두면 애드온의 제한을 따릅니다. 직접 정하는 제한은 애드온의 제한보다 낮게만 설정할 수 있습니다.",
	"files.receiveLabel": "읽을 수 있는 최대 파일 크기(MiB)",
	"files.sendLabel": "보낼 수 있는 최대 파일 크기(MiB)",
	"files.invalid": "0보다 큰 숫자를 입력하세요.",
	"files.tooHigh": "이 애드온은 여기에 최대 {{max}}까지 허용합니다.",
	"files.now": "현재: {{limit}} ({{layer}}).",
	"files.receiveHelp": "사람들이 봇에 보내는 파일입니다. 더 큰 파일은 거부되며, 봇이 어떤 제한에 걸렸는지 알려 줍니다.",
	"files.sendHelp": "에이전트가 만들어 봇이 돌려보내는 파일입니다. 더 큰 파일은 보내지 않으며, 봇이 어떤 제한에 걸렸는지 알려 줍니다.",
	"files.addon.off": "이 애드온은 이 방향으로 파일을 옮기지 않으므로 설정할 것이 없습니다.",
	"files.addon.declared": "애드온이 최대 {{max}}까지 지원한다고 밝혔습니다.",
	"files.addon.open": "애드온이 제한을 밝히지 않았으므로 플랫폼의 제한이 적용됩니다.",
	"files.host": "어떤 봇도 {{max}}보다 큰 파일은 옮길 수 없습니다. 관리자가 설정에서 정합니다.",
	"files.layer.owner": "이 봇에 설정한 제한",
	"files.layer.addon": "애드온의 제한",
	"files.layer.host": "플랫폼의 제한",
	"perm.agentLacks": "에이전트에게 이 권한이 없습니다.",
	"perm.rule": "목록에 있는 사람은 선택된 권한을 사용할 수 있습니다. 민감한 권한은 검증된 사람이어야 합니다.",
	"perm.sensitive": "검증된 사람만",
	"perm.sensitiveHelp": "민감함. 역할에는 부여되지 않습니다. 검증된 사람만 사용할 수 있으며 사용할 때마다 기록됩니다.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "봇이 게시할 수 있는 곳",
	"perm.channelsHelp": "목록에 있는 사람이 요청하면, 답변하는 채팅 외에 에이전트가 게시할 수 있는 곳입니다. 봇이 누구의 말을 듣는지는 정하지 않습니다. 봇이 듣는 채널을 보세요. 최대 {{max}}개.",
	"perm.channelsOff": "봇이 게시할 수 있는 곳을 고르려면 위에서 \"다른 채널에 게시\"를 켜세요.",
	"perm.channelId": "채널 ID",
	"perm.channelLabel": "이름",
	"perm.channelAdd": "곳 추가",
	"perm.channelRemove": "곳 {{id}} 제거",
	"perm.remove": "제거",
	"perm.channelFull": "목록이 가득 찼습니다.",
	"perm.channelProblem.id": "곳마다 공백 없는 1~{{max}}바이트의 ID가 필요합니다.",
	"perm.channelProblem.label": "이름은 최대 {{max}}자입니다.",
	"perm.channelProblem.repeat": "같은 곳이 두 번 나열되어 있습니다.",
	"perm.channelProblem.count": "곳은 최대 {{max}}개입니다.",
	"perm.triggersNeed": "이 기능을 쓰려면 \"트리거 제안\"을 켜세요.",
	"pair.start": "사람 검증",
	"pair.startHelp": "코드를 만듭니다. 검증할 계정에서 10분 안에 이 코드를 봇에 다이렉트 메시지로 보내세요. 코드는 한 번만 사용할 수 있습니다.",
	"pair.needSave": "먼저 이 봇을 저장한 다음 사람을 검증하세요.",
	"pair.codeTitle": "검증 코드",
	"pair.codeHelp": "검증할 계정에서 이 코드를 봇에 다이렉트 메시지로 보내세요. 코드는 지금만 표시되고, 한 번만 사용할 수 있으며, {{time}}에 만료됩니다.",
	"pair.codeGone": "코드가 만료되었습니다. 그 사람이 아직 검증되지 않았다면 새로 만드세요.",
	"pair.done": "검증됨: {{sender}}.",
	"pair.dismiss": "코드 숨기기",
	"pair.none": "검증된 사람이 없습니다.",
	"pair.expires": "{{time}}에 종료",
	"pair.full": "사람 3명이 검증되어 있습니다. 다른 사람을 검증하려면 하나를 제거하세요.",
	"access.title": "확인하기",
	"access.needSave": "이 봇을 먼저 저장하면 최근 거절한 사람을 볼 수 있습니다.",
	"access.refresh": "새로 고침",
	"access.who": "보낸 사람 {{senders}}",
	"can.sender.role": "역할: {{title}}",
	"can.fromForm": "양식의 현재 상태로 계산했습니다. 이 설정을 유지하려면 저장하세요.",
	"can.fromFormNew": "아직 저장되지 않았습니다. 양식의 현재 상태로 계산했습니다.",
	"can.loading": "이 봇이 할 수 있는 일을 확인하는 중",
	"can.stale": "업데이트 중",
	"can.errorTitle": "이 봇이 할 수 있는 일을 확인하지 못했습니다",
	"can.retry": "다시 시도",
	"can.allowed": "허용됨",
	"can.via.paired": "이 사람이 검증되어 있어서",
	"can.via.allowlist": "이 사람이 목록에 있어서",
	"can.via.agentConnection": "이 사람이 검증되어 있고 에이전트가 애드온에 연결되어 있기 때문입니다",
	"can.via.role": "역할 {{role}}을(를) 통해",
	"can.then": "아직 확인하지 않음: {{list}}.",
	"can.then.server": "서버 설정",
	"can.then.tools": "에이전트의 도구 스위치",
	"can.then.agent": "에이전트의 권한",
	"can.then.connection": "이 연결의 권한",
	"can.then.sender": "보내는 사람",
	"can.then.approval": "제안을 확인하는 방식",
	"can.noMessage": "허용되지 않습니다.",
	"fix.open_connection": "설정 보기",
	"fix.open_agent": "에이전트 열기",
	"fix.open_server_setting": "설정 열기",
	"fix.pair_sender": "사람 검증",
	"fix.add_person": "사람 추가",
	"fix.save": "변경 사항 유지",
	"fix.token": "토큰 붙여넣기",
	"fix.tokenNew": "새 토큰 붙여넣기",
	"fix.agent": "에이전트 고르기",
	"fix.usual": "권한 고르기",
	"fix.turnOn": "켜기",
	"fix.newTab": "(새 탭에서 열림)",
	"fix.askAdmin": "관리자에게 요청",
	"ready.title": "상태",
	"ready.checkingSummary": "양식이 어떻게 동작할지 확인하는 중입니다.",
	"ready.allGood": "필요한 것이 모두 갖춰져 있습니다.",
	"ready.showAll": "{{count}}개 모두 보기",
	"ready.showProblems": "확인이 필요한 항목만 보기",
	"ready.checking": "확인하는 중.",
	"ready.unchecked": "확인할 수 없습니다. 아래의 \"이 봇이 할 수 있는 일\"을 보세요.",
	"ready.row.token": "토큰",
	"ready.row.agent": "에이전트",
	"ready.row.who": "사용할 수 있는 사람",
	"ready.row.permissions": "권한",
	"ready.row.addons": "애드온 도구",
	"ready.row.triggers": "트리거",
	"ready.row.files": "파일",
	"ready.row.notify": "알림",
	"ready.state.ok": "정상",
	"ready.state.attention": "확인 필요",
	"ready.state.off": "꺼짐",
	"ready.state.after_save": "저장 후",
	"ready.state.broken": "작동 안 함",
	"ready.state.checking": "확인 중",
	"ready.state.unknown": "알 수 없음",
	"ready.token.missing": "봇의 토큰을 붙여 넣으세요. 토큰이 없으면 아무것도 받지 못합니다.",
	"ready.token.newTyped": "저장할 때 플랫폼에서 토큰을 확인합니다.",
	"ready.token.typed": "저장할 때 플랫폼에서 새 토큰을 확인합니다.",
	"ready.token.failed": "플랫폼이 토큰을 거부했습니다: {{reason}}",
	"ready.token.checked": "플랫폼이 토큰을 받아들였습니다. {{bot}}",
	"ready.token.saved": "토큰이 저장되어 있습니다. 저장할 때 플랫폼이 받아들였습니다.",
	"ready.agent.none": "답변할 에이전트를 고르세요.",
	"ready.agent.credentialsOnly": "에이전트 없음. 이 연결은 자격 증명만 보관하며 메시지에 답변하지 않습니다.",
	"ready.agent.gone": "선택한 에이전트가 더 이상 목록에 없습니다. 다른 에이전트를 고르세요.",
	"ready.agent.noModel": "{{name}}에는 모델이 없어서 답변할 수 없습니다. 모델을 지정하세요.",
	"ready.agent.ok": "{{name}}이(가) 모델 {{model}}(으)로 답변합니다.",
	"ready.agent.okUnknown": "에이전트가 선택되어 있습니다.",
	"ready.who.anyone": "봇에 메시지를 보낼 수 있는 사람은 누구나 사용할 수 있습니다.",
	"ready.who.nobody": "아직 목록에 있는 사람이 없어서 봇이 모든 메시지를 무시합니다. 사람을 추가하세요.",
	"ready.who.channelsOnly": "목록에 채널만 있습니다. 채널의 사람들은 대화할 수 있지만, 선택한 권한은 채널이 '여기 모두 작업 요청 허용'으로 설정된 곳에서만 쓸 수 있습니다.",
	"ready.who.listed_one": "사람 또는 채팅 {{count}}개가 목록에 있습니다.",
	"ready.who.listed_other": "사람 또는 채팅 {{count}}개가 목록에 있습니다.",
	"ready.who.mixed": "사람과 채널을 합쳐 항목 {{count}}개가 목록에 있습니다.",
	"ready.perm.none": "켜진 권한이 없습니다. 보낸 사람은 채팅만 할 수 있습니다.",
	"ready.perm.noneSaved": "켜진 권한이 없어서 파일, 메모리, 트리거, 게시가 꺼져 있습니다.",
	"ready.perm.onlyOwnRows": "다른 권한은 꺼져 있습니다. 트리거와 파일은 아래에 있습니다.",
	"ready.perm.ok_one": "권한 {{count}}개가 켜져 있으며 보낸 사람이 사용할 수 있습니다.",
	"ready.perm.ok_other": "권한 {{count}}개가 켜져 있으며 보낸 사람이 사용할 수 있습니다.",
	"ready.perm.dead_one": "아무도 {{names}}을(를) 사용할 수 없습니다. {{message}}",
	"ready.perm.dead_other": "켜진 권한 중 {{count}}개를 아무도 사용할 수 없습니다: {{names}}. 첫 번째: {{message}}",
	"ready.addons.off": "에이전트에 {{addon}} 도구 {{tools}}이(가) 있지만, \"{{permission}}\"을(를) 켜기 전에는 이 채팅에서 사용할 수 없습니다.",
	"ready.addons.blocked": "에이전트에 {{addon}} 도구 {{tools}}이(가) 있지만 보류되었습니다. {{message}}",
	"ready.addons.ok": "에이전트가 이 채팅에서 {{addon}} 도구 {{tools}}을(를) 사용할 수 있습니다.",
	"ready.addons.paired": "에이전트가 {{connection}}에 연결되어 있으므로(쓰기 모드: {{mode}}), 검증된 사람은 이 채팅에서 {{addon}} 쓰기 도구 {{tools}}을(를) 사용할 수 있습니다. 검증되지 않은 목록의 사람은 \"{{permission}}\"이(가) 필요합니다.",
	"ready.addons.removed": "\"{{permission}}\"을(를) 꺼 두었으므로 이 채팅에서는 검증된 사람도 {{addon}} 쓰기 도구 {{tools}}을(를) 사용할 수 없습니다. 켜면 다시 사용할 수 있으며, 목록에 있지만 검증되지 않은 사람도 사용할 수 있게 됩니다.",
	"ready.addons.modeOff": "에이전트에 {{addon}} 쓰기 도구 {{tools}}이(가) 있지만, {{connection}}의 쓰기 모드가 꺼져 있어 사용할 수 없습니다. 해당 연결에서 쓰기 모드를 바꾸세요.",
	"ready.addons.mode.auto": "바로 실행",
	"ready.addons.mode.propose": "먼저 묻기",
	"ready.triggers.off": "에이전트가 여기서 알림이나 예약 작업을 설정할 수 없습니다.",
	"ready.triggers.blocked": "트리거가 켜져 있지만 사용할 수 없습니다. {{message}}",
	"ready.triggers.ok.ask": "에이전트가 트리거를 제안할 수 있습니다. 시작하기 전에 하나씩 확인합니다.",
	"ready.triggers.ok.auto": "에이전트가 트리거를 제안할 수 있습니다. 묻지 않고 바로 시작합니다.",
	"ready.triggers.ok.auto_readonly": "에이전트가 트리거를 제안할 수 있습니다. 읽기만 하는 트리거는 바로 시작하고, 그 외에는 직접 확인합니다.",
	"ready.files.offReceive": "보낸 사람이 에이전트에게 파일을 보낼 수 없습니다.",
	"ready.files.offBoth": "보낸 사람이 에이전트에게 파일을 보낼 수 없고, 봇도 파일을 돌려보내지 않습니다.",
	"ready.files.blocked": "파일 받기가 켜져 있지만 사용할 수 없습니다. {{message}}",
	"ready.files.ok": "보낸 사람이 에이전트에게 파일을 보낼 수 있고, 봇도 파일을 돌려보낼 수 있습니다.",
	"ready.files.okReceive": "보낸 사람이 에이전트에게 파일을 보낼 수 있습니다. 봇은 파일을 돌려보내지 않습니다.",
	"ready.notify.off": "이 봇의 알림을 받는 채팅이 없습니다.",
	"ready.notify.ok": "알림은 채팅 {{chat}}(으)로 갑니다.",
	dismiss: "닫기",
	credentialsOnly: "자격 증명만",
	agentCredentialsOnly: "에이전트 없음(자격 증명만)",
	agentOptionalHint: "선택 사항입니다. 에이전트가 없으면 이 연결은 토큰, 저장소 목록, 내 채팅의 쓰기 모드만 보관합니다. 메시지에 답변하지 않습니다. 수신하려면 에이전트를 고르세요.",
	"sender.line_one": "{{name}} · 메시지 {{count}}개 · {{id}}",
	"sender.line_other": "{{name}} · 메시지 {{count}}개 · {{id}}",
	"ready.blocker.nobodyLetIn": "아직 아무도 허용되지 않았습니다.",
	"ready.blocker.nobodyPaired": "검증된 사람이 필요한데, 아직 검증된 사람이 없습니다.",
	optional: "선택",
	"approvals.title": "바로 실행되는 도구",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "먼저 묻기",
	"approvals.state.runs": "바로 실행",
	"approvals.state.idle": "바로 실행하도록 설정됨, 지금은 아무것도 하지 않음",
	"approvals.state.other": "이 보낸 사람에게는 여전히 먼저 묻기",
	"approvals.line.asks": "카드가 확인을 기다리고 있습니다.",
	"approvals.line.runs": "소유자의 채팅과 검증된 사람을 위한 것입니다. 그 밖의 모든 사람에게는 여전히 묻습니다.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "소유자와 검증된 사람만 카드를 건너뜁니다. 이런 종류의 보낸 사람에게는 묻습니다.",
	"dup.text": "이 봇은 {{name}}(으)로도 연결되어 있습니다. 두 연결이 같은 메시지에 모두 답합니다.",
	"dup.turnOff": "이 연결 끄기",
	"dup.openOther": "{{name}} 열기",
	"dup.saveAnyway": "그래도 저장",
	"dup.goBack": "돌아가기",
	"dup.confirmHelp": "메시지마다 답을 두 번 받고 싶을 때만 그래도 저장하세요.",
	"access.noteSave.title": "메모",
	"access.noteSave.now": "메모를 바로 저장하고 되돌리기와 함께 알려줍니다",
	"access.noteSave.ask": "이 유형의 보낸 사람의 메모는 소유자를 기다립니다",
	"trust.answer": "답변만",
	"trust.act": "여기 모두 작업 요청 허용",
	"ready.row.channelTrust": "봇이 듣는 채널",
	"ready.row.postTo": "봇이 게시할 수 있는 곳",
	"ready.channelTrust.act": "{{channels}}의 사람들은 일상 작업을 요청할 수 있습니다. 민감한 작업은 여전히 검증된 사람이 필요합니다.",
	"ready.channelTrust.answer": "{{channels}}의 사람들은 작업을 쓸 수 없습니다. '여기 모두 작업 요청 허용'으로 설정하세요.",
	"ready.channelTrust.noCaps": "권한에 선택된 것이 없어, 모두가 요청할 수 있는 곳에서도 파일과 다른 작업이 거부됩니다.",
	"fix.trust": "채널 설정",
	"can.via.channel": "이 채널이 '여기 모두 작업 요청 허용'으로 설정되어 있어 이 채널의 모두가 요청할 수 있습니다",
	"ready.postTo_one": "봇은 목록에 있는 사람이 요청하면 다른 곳 1곳에 게시할 수 있습니다. 그 안의 사람들을 신뢰하는 것은 아닙니다.",
	"ready.postTo_other": "봇은 목록에 있는 사람이 요청하면 다른 곳 {{count}}곳에 게시할 수 있습니다. 그 안의 사람들을 신뢰하는 것은 아닙니다.",
	"access.toolsTitle": "애드온 도구 호출",
	"access.toolsHelp": "이 연결을 사용했거나 이 봇을 통해 들어온 애드온 도구의 최근 호출이며, 최신순으로 최대 20개입니다. 도구 이름과 이유만 담고, 요청이나 응답 내용은 담지 않습니다. 서버를 다시 시작하면 초기화됩니다.",
	"access.toolsNone": "아직 호출이 없습니다.",
	"access.outcome.ok": "성공",
	"access.outcome.held": "보류됨",
	"access.outcome.denied": "거부됨",
	"access.outcome.error": "실패",
	"ready.addons.confirmChat": "검증된 사람은 채팅에서 {{addon}} 쓰기 작업을 확인할 수 있습니다. 봇이 각 요청을 그곳에 쓰고 예 또는 아니요로 답합니다.",
	"access.outcome.confirmed": "확인됨",
	"access.outcome.cancelled": "취소됨",
	"access.outcome.expired": "만료됨",
	"access.askedBy": "{{sender}} 요청",
	"access.chat": "{{chat}}에서",
	"sender.chat": "{{chat}}에서",
	"sender.reason.not_listed": "목록에 있는 사람이 아님",
	"sender.reason.not_addressed": "메시지에 봇이 언급되지 않음",
	"ready.notReady": "아직 준비되지 않았습니다.",
	"ready.fixCount_one": "확인할 항목 {{count}}개",
	"ready.fixCount_other": "확인할 항목 {{count}}개",
	"ready.quiet_one": "설정할 항목 {{count}}개",
	"ready.quiet_other": "설정할 항목 {{count}}개",
	"ready.quietDone": "더 설정할 항목이 없습니다",
	"matrix.title": "누가 무엇을 할 수 있는지",
	"loops.title": "대기와 타이머",
	"loops.help": "에이전트가 나중에 이 채팅에서 스스로 할 수 있는 일입니다. 이 설정은 봇에 속하며 역할에는 주어지지 않습니다.",
	"matrix.note": "스위치와 역할 체크박스는 직접 설정합니다. 나머지 셀은 현재 설정을 바탕으로 호스트가 메시지마다 실행하는 것과 같은 검사로 계산됩니다.",
	"matrix.capability": "권한",
	"matrix.pick": "보낸 사람 종류",
	"matrix.col.on": "이 봇에서 켜짐",
	"matrix.col.paired": "검증된 사람",
	"matrix.col.listed": "목록에 있는 사람",
	"matrix.col.channel_acts": "채널: 모두 작업",
	"matrix.col.channel_member": "채널: 답변만",
	"matrix.col.anyone": "누구나",
	"matrix.state.yes": "예",
	"matrix.state.asks": "먼저 묻기",
	"matrix.state.no": "아니요",
	"matrix.state.waiting": "사람 확인 대기 중",
	"matrix.state.off": "꺼짐",
	"matrix.state.unknown": "알 수 없음",
	"matrix.row.tools": "연결된 서비스의 데이터 변경",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "'아니요' 또는 '꺼짐'인 이유",
	"matrix.detail.none": "셀을 선택하면 이유를 볼 수 있습니다.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "일반 설정으로 되돌리기",
	"matrix.more": "자세히",
	"matrix.less": "자세히 숨기기",
	"matrix.nobodyVerified": "아직 인증된 사람이 없습니다.",
	"who.title": "누가 봇과 대화할 수 있나요",
	"who.onlyChosen": "제가 고른 사람만",
	"who.anyone": "메시지를 보낼 수 있는 누구나",
	"who.people": "사람",
	"who.peopleAndChannels": "사람과 채널",
	"who.peopleNone": "아직 목록에 아무도 없습니다. 아래에서 추가하세요.",
	"who.channels": "채널",
	"who.channelsNote": "채널 안의 사람은 그 채널 안에서만 동작할 수 있으며, 다이렉트 메시지에서는 불가능합니다.",
	"who.add": "사람 또는 채널 추가",
	"who.recent": "최근 봇에 메시지를 보낸 사람. 클릭하여 추가하세요.",
	"who.addPerson": "{{name}} 추가",
	"who.verified": "인증됨",
	"who.listed": "목록에 있음",
	"who.verify": "인증",
	"who.verifyPerson": "{{name}} 인증",
	"who.remove": "제거",
	"who.removePerson": "{{name}} 제거",
	"who.removeChannel": "{{name}} 제거",
	"who.levelFor": "{{channel}}의 사람이 할 수 있는 일",
	"answer.more": "파일 크기와 답변 언어",
	"perm.channelsSwitch": "스위치로 이동",
	"perm.channelWho": "누가 게시하게 할 수 있는지",
	"perm.channelWhoFor": "누가 {{id}}에 봇이 게시하게 할 수 있는지",
	"perm.channelWho.any": "허용된 사람이 요청할 때",
	"perm.channelWho.verified": "인증된 사람이 요청할 때만",
	"notify.label": "내 알림과 실행 결과를 보낼 곳",
	"notify.none": "보내지 않음",
	"notify.people": "사람",
	"notify.channels": "채널",
	"notify.saved": "{{id}} (저장된 ID)",
	"notify.other": "다른 ID...",
	"notify.otherLabel": "채팅 ID",
	"try.title": "시험해 보기",
	"try.help": "누가, 어디서, 무엇을 요청하는지 고르세요. 호스트가 모든 메시지에 하는 검사를 지금 양식 그대로 실행합니다.",
	"try.noone": "먼저 사람을 추가하세요. 그러면 그 사람이 할 수 있는 일을 시험해 볼 수 있습니다.",
	"try.whoLabel": "누가",
	"try.placeLabel": "어디서",
	"try.actionLabel": "요청 내용",
	"try.someoneIn": "{{channel}}의 누군가",
	"try.anyone": "누구나",
	"try.role": "{{role}} 역할을 가진 사람",
	"try.dm": "다이렉트 메시지",
	"try.where.dm": "다이렉트 메시지에서",
	"try.where.channel": "{{channel}}에서",
	"try.is.paired": "{{who}}은(는) 인증된 사람이며 {{where}} 글을 씁니다.",
	"try.is.listed": "{{who}}은(는) 목록에 있는 사람이며 {{where}} 글을 씁니다.",
	"try.is.channelActs": "{{channel}}의 누군가. 이 채널에서는 모두가 작업을 요청할 수 있습니다.",
	"try.is.channelAnswers": "{{channel}}의 누군가. 이 채널에서는 답변만 받습니다.",
	"try.is.anyone": "봇에 메시지를 보낼 수 있는 사람은 누구나 허용됩니다.",
	"try.is.role": "{{role}} 역할을 가진 사람은 허용됩니다.",
	"try.verdict.allowed": "허용됨.",
	"try.verdict.asks": "허용되지만 먼저 묻습니다.",
	"try.verdict.refused": "거절됨.",
	"try.loading": "확인 중...",
	"try.error": "검사가 응답하지 않았습니다. 위 표의 다시 시도를 사용하세요.",
	"try.unknown": "호스트가 이 유형의 발신자에 대한 답을 주지 않았습니다.",
	"try.note": "플랫폼에는 아무것도 전송되지 않고 아무것도 저장되지 않습니다.",
	"refusals.title": "최근 거절",
	"refusals.help": "서버가 시작된 뒤 봇이 거절한 내용이며 최신순입니다. ID, 이름, 채팅만 담고 메시지 내용은 담지 않습니다. 이 기록은 메모리에만 있어 서버를 다시 시작하면 비워집니다.",
	"refusals.none": "서버가 시작된 뒤 거절한 내용이 없습니다.",
	"refusals.refused": "거절됨",
	"refusals.action": "요청: {{action}}",
	"refusals.talk": "봇에 메시지를 보냄",
	"refusals.allow": "{{name}} 허용",
	"refusals.act": "{{channel}} 구성원이 작업하도록 허용",
	"perm.channelPickOther": "기타: ID 입력",
	"perm.channelHint.verified": "예약 실행은 여기에 게시할 수 없습니다. 허용하려면 \"허용된 사람이 요청할 때\"를 선택하세요.",
	"perm.channelHint.any": "예약 실행이 여기에 게시할 수 있습니다.",
	"perm.channelNoListen": "봇은 이 채널을 듣지 않으므로 게시만 합니다.",
	"who.post.none": "봇이 여기에 게시할 수 없습니다.",
	"who.post.add": "봇이 여기에도 게시하도록 허용",
	"who.post.addFor": "봇이 {{name}}에도 게시하도록 허용",
	"who.post.verified": "확인된 사람이 요청할 때만 여기에 게시합니다.",
	"who.post.any": "허용된 사람이 요청하면 여기에 게시합니다.",
	"who.post.show": "장소 보기",
	"who.post.showFor": "{{name}}의 장소 보기",
	agentLink: "에이전트 {{name}} 열기",
	"saved.created": "연결이 추가되었습니다.",
	"saved.nothing": "저장되었습니다. 변경 사항이 없습니다.",
	"saved.changed": "저장되었습니다. 변경됨: {{what}}.",
	"saved.part.name": "이름",
	"saved.part.agent": "에이전트",
	"saved.part.who": "수락 대상",
	"saved.part.permissions": "권한",
	"saved.part.approval": "트리거 승인 및 동작",
	"saved.part.files": "파일 설정",
	"saved.part.notify": "알림",
	"saved.dropped.title": "이 연결은 더 이상 이러한 동작을 허용하지 않으므로, 다음 트리거의 실행에서 해당 동작이 빠집니다:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "실행 중",
	"conn.state.off": "꺼짐",
	"conn.state.attention": "확인 필요",
	"conn.state.ready": "준비됨",
	"conn.row.open": "{{name}}: {{state}}. 세부 정보 보기",
	"conn.row.menu": "{{name}}의 다른 작업",
	"conn.row.testNamed": "{{name}} 테스트",
	"conn.fix.token": "토큰 수정",
	"conn.reason.noToken": "저장된 토큰이 없습니다.",
	"conn.reason.duplicate": "{{name}}와(과) 같은 봇으로 응답합니다.",
	"conn.reason.testFailed": "마지막 테스트 실패: {{reason}}",
	"conn.kv.service": "서비스",
	"conn.kv.accepts": "허용 대상",
	"conn.kv.replies": "응답",
	"conn.kv.token": "토큰",
	"conn.kv.saved": "저장됨",
	"conn.kv.notSaved": "저장 안 됨",
	"conn.kv.agents": "에이전트",
	"usedBy.count_one": "에이전트 {{count}}개가 사용 중",
	"usedBy.count_other": "에이전트 {{count}}개가 사용 중",
	"usedBy.none": "사용하는 에이전트 없음",
	"conn.pane.lastTest": "마지막 테스트",
	"conn.pane.never": "이 브라우저에서는 아직 테스트하지 않았습니다.",
	"conn.pane.passed": "{{when}} 통과.",
	"conn.pane.failed": "{{when}} 실패.",
	"conn.pane.connection": "연결",
	"conn.pane.remove": "제거",
	"conn.pane.test": "연결 테스트",
	"conn.pane.testing": "테스트 중...",
	"conn.sheet.addDesc": "이름을 정하고 토큰을 추가한 뒤 응답할 에이전트를 선택하세요.",
	"conn.sheet.editDesc": "변경 사항은 저장할 때 적용됩니다. 저장된 토큰은 다시 표시되지 않습니다.",
	"conn.sheet.connection": "연결",
	"conn.sheet.who": "대화할 수 있는 사람",
	"conn.sheet.may": "할 수 있는 일",
	"conn.sheet.replies": "응답, 파일, 장소",
	"conn.sheet.check": "수행할 작업 확인",
	"conn.sheet.saveAndTest": "저장 후 테스트",
	"conn.sheet.saving": "저장 중...",
	"conn.sheet.testFailed": "연결은 저장되었지만 테스트에 실패했습니다.",
	"conn.sheet.testFailedNoReason": "이유가 제공되지 않았습니다.",
	"conn.sheet.testAgain": "다시 테스트",
	"conn.sheet.close": "닫기",
	"conn.sheet.agentFixed": "에이전트 {{name}}(으)로 응답",
	"conn.preset.label": "권한",
	"conn.preset.answer": "응답만",
	"conn.preset.answerHelp": "메시지에 응답합니다. 이 연결은 자체 권한을 추가하지 않습니다.",
	"conn.preset.standard": "표준",
	"conn.preset.standardHelp": "에이전트가 가진 일반 권한 모음: {{list}}.",
	"conn.preset.standardNone": "일반 권한 모음입니다. 이 에이전트는 해당 권한이 없습니다.",
	"conn.preset.custom": "사용자 지정",
	"conn.preset.customHelp": "권한과 사용할 수 있는 사람을 각각 선택하세요.",
	"conn.preset.note": "프리셋은 민감한 권한을 켜지 않습니다. 그런 권한은 사용자 지정을 사용하세요. 에이전트가 가진 애드온 연결에는 고유한 규칙이 있어, 검증된 사람은 여전히 그 쓰기 도구를 사용할 수 있습니다. 에이전트의 \"사용할 수 있는 것\"에서 변경하세요.",
	"conn.discard.title": "변경 사항을 버릴까요?",
	"conn.discard.message": "이 연결을 변경했지만 저장하지 않았습니다.",
	"conn.discard.confirm": "변경 사항 버리기",
	"share.label": "공유",
	"share.button": "{{name}} 공유",
	"share.intro": "추가한 사람은 자신의 채팅과 에이전트에서 이 연결을 사용할 수 있습니다. 이름과 상태만 보이며 토큰이나 설정은 절대 보이지 않습니다. 봇으로 오는 메시지는 계속 내 에이전트가 받습니다.",
	"share.roleUse": "사용 가능",
	"share.roleUseHelp": "자신의 채팅과 에이전트에서 사용할 수 있습니다. 토큰을 보거나, 변경하거나, 공유할 수 없습니다.",
	"shared.title": "나와 공유됨",
	"shared.text": "다른 사람이 내 채팅과 에이전트에서 이 연결을 사용하도록 허용했습니다. 소유자만 변경할 수 있습니다.",
	"shared.on": "수신 중",
	"shared.off": "꺼짐",
	"shared.by": "{{name}} 님이 공유함",
	loginNeedsHost: "이 LocalAI 버전에서는 이 페이지에서 로그인할 수 없습니다. 여기서 연결하려면 LocalAI를 업데이트하세요."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.tr.json
var connector_tr_default = {
	"answer.title": "Nereye gönderir ve nasıl yanıt verir",
	"answer.replyLabel": "Ajan çalışırken",
	"answer.reply.off": "Yazıyor, sonra yanıt",
	"answer.reply.progress": "İlerleme: kullandığı araçlar",
	"answer.reply.stream": "Canlı: yanıt yazıldıkça",
	"answer.reply.reasoning": "Düşünme: modelin düşüncesi, sonra yanıt",
	"answer.replyHelp": "İlerleme ve Canlı, tek bir çalışıyor mesajı gösterir ve yanıt onun yerine geçer. Taslak destekleyen bir platformda Canlı, özel bir sohbete bunun yerine bir taslak gösterir ve yanıt onu izler. Uzun bir yanıt yeni mesajlarla devam eder.",
	"answer.replyReasoningHelp": "Düşünme, modelin düşüncesini yazdıkça bu bağlamanın her göndericisine gösterir. Yalnızca bunun sorun olmadığı yerde kullan.",
	"answer.conversationLabel": "Konuşmalar",
	"answer.conversationHelp": "Yeni bir sohbet başlatmak için uygulamada /new (veya !new) gönder.",
	"answer.conversation.sender": "Kişi başına bir sohbet",
	"answer.conversation.chat": "Grup veya kanal başına bir sohbet",
	"answer.conversation.window": "Kişi başına, sessiz bir sürenin ardından yeni",
	"answer.conversation.thread": "Mesaj başına yeni sohbet; yanıtlar devam eder",
	"answer.window": "Sessiz süre, dakika olarak",
	"answer.windowRange": "1 ile {{max}} arasında bir tam sayı kullan.",
	"answer.languageLabel": "Yanıt dili",
	"answer.languageHelp": "Botun kendisinin yazdığı notlar, örneğin onaylar ve retler. Modelin yanıtları konuşmanın dilini izler.",
	"answer.language.auto": "Otomatik (arayüz dilin, yoksa göndericinin dili)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Ajanın ürettiği dosyaları gönder",
	add: "Ekle",
	more: "Daha fazla",
	less: "Daha az",
	"answer.filesHelp": "Yanıttan sonra en fazla 5 dosya. Programlar ve betikler gönderilmez. Boyut sınırı Dosya boyutları ve yanıt dili altındadır.",
	"answer.summary": "Yanıtlar: {{reply}} · {{conversation}}",
	"answer.short.off": "yazıyor",
	"answer.short.progress": "ilerleme",
	"answer.short.stream": "canlı yanıt",
	"answer.short.reasoning": "düşünme gösterilir",
	"answer.short.sender": "kişi başına sohbet",
	"answer.short.chat": "grup başına sohbet",
	"answer.short.window": "{{count}} dk sonra yeni sohbet",
	"answer.short.thread": "mesaj başına sohbet",
	"approval.title": "Sohbetten zamanlayıcılar ve tetikleyiciler",
	"approval.help": "Ajan daha sonra çalışacak bir şey kurduğunda (\"10 dakika sonra\", \"her gün\"), her çalışma bir model çalışmasıdır.",
	"approval.mode.ask": "Önce sorar: bot bunu sohbette önerir ve kişi evet veya hayır diye yanıt verir",
	"approval.mode.auto": "Hemen çalışır: kurulur ve kişiye nasıl iptal edeceği söylenir",
	"approval.mode.auto_readonly": "Çalışmalar yalnızca okuyup raporladığında hemen çalışır; aksi halde önce sorar",
	"approval.limitsHelp": "Bu sınırlar, sormadan kurulanı sınırlar. Varsayılanı için bir alanı boş bırak. Bir sınırı aşan her şey bunun yerine sorulur.",
	"approval.max_pending": "Aynı anda en fazla zamanlayıcı ve tetikleyici",
	"approval.min_gap_minutes": "Yinelenen bir tetikleyicinin çalışmaları arasındaki en az dakika",
	"approval.max_runs_per_day": "Günde en fazla çalışma, hepsi birlikte",
	"approval.max_lifetime_days": "En uzun ömür, gün olarak",
	"approval.invalid": "1 ile {{max}} arasında bir tam sayı kullan veya boş bırak.",
	"approval.default": "Varsayılan: {{value}}.",
	"approval.summary": "Tetikleyiciler: {{mode}}",
	"approval.effect": "Öneriler: {{mode}}",
	"approval.effectChange": "Değişiklikler ve silmeler: {{mode}}",
	"approval.limits": "Sınırlar",
	"approval.acts.title": "Çalışmalar işlem yapabilir",
	"approval.acts.help": "Kapalı: bu sohbetten oluşturulan bir tetikleyicinin çalışmaları yalnızca okur ve raporlar. Açık: aşağıda işaretlediğini ve yalnızca ajanın sahip olduğunu da yapabilirler.",
	"approval.acts.modes": "Önce sorar: her zaman sen karar verirsin. Hemen çalışır: yalnızca doğrulanmış bir kişiysen ve her eylem burada işaretliyse.",
	"approval.acts.act.files": "Ajanın klasörlerine dosya yaz",
	"approval.acts.act.files.effect": "Bir çalışma, ajanın tuttuğu dosyaları oluşturabilir ve değiştirebilir.",
	"approval.acts.act.addons": "Ajanın eklentilerinin eylemlerini kullan",
	"approval.acts.act.addons.effect": "Bir çalışma, ajanın eklentilerinin yaptığı şeyleri, komutlar dahil, kullanabilir.",
	"approval.acts.act.send": "Rapor verdiği yerin ötesine mesaj gönder",
	"approval.acts.act.send.effect": "Bir çalışma kendi başına diğer sohbetlere ve kanallara yazabilir.",
	"approval.acts.act.spend": "Ücretli veya harici araçları ve ağı kullan",
	"approval.acts.act.spend.effect": "Bir çalışma, LocalAI dışındaki hizmetleri çağırabilir; bunun maliyeti olabilir.",
	"approval.acts.lacks": "Ajanın buna sahip değil.",
	"approval.acts.sensitive": "Hassas",
	"approval.effectActs": ", çalışmalar şunları yapabilir: {{acts}}",
	"approval.actShort.act.files": "dosya yazma",
	"approval.actShort.act.addons": "eklenti kullanma",
	"approval.actShort.act.send": "mesaj gönderme",
	"approval.actShort.act.spend": "ücretli veya harici araç kullanma",
	"approval.short.ask": "önce sorar",
	"approval.short.auto": "hemen çalışır",
	"approval.short.auto_readonly": "salt okunursa hemen çalışır",
	"files.title": "Dosyalar",
	"files.help": "Eklentinin sınırını kullanmak için bir alanı boş bırak. Senin sınırın bundan yalnızca daha düşük olabilir.",
	"files.receiveLabel": "Okuduğu en büyük dosya, MiB olarak",
	"files.sendLabel": "Gönderdiği en büyük dosya, MiB olarak",
	"files.invalid": "0'dan büyük bir sayı kullan.",
	"files.tooHigh": "Eklenti burada en fazla {{max}} değerine izin verir.",
	"files.now": "Şu an: {{limit}} ({{layer}}).",
	"files.receiveHelp": "İnsanların bota gönderdiği dosyalar. Daha büyük bir dosya reddedilir ve bot hangi sınıra takıldığını söyler.",
	"files.sendHelp": "Ajanın ürettiği ve botun geri gönderdiği dosyalar. Daha büyük bir dosya gönderilmez ve bot hangi sınıra takıldığını söyler.",
	"files.addon.off": "Bu eklenti bu yönde dosya taşımaz, bu yüzden ayarlanacak bir şey yok.",
	"files.addon.declared": "Eklenti {{max}} değerine kadar bildiriyor.",
	"files.addon.open": "Eklenti bir sınır bildirmiyor, bu yüzden platformun sınırı geçerli.",
	"files.host": "Hiçbir bot {{max}} üzerindeki bir dosyayı taşıyamaz. Bunu bir yönetici ayarlardan belirler.",
	"files.layer.owner": "bu bot için belirlenen sınır",
	"files.layer.addon": "eklentinin sınırı",
	"files.layer.host": "platformun sınırı",
	"perm.agentLacks": "Ajanın buna sahip değil.",
	"perm.rule": "Listedeki kişiler işaretlenen izinleri kullanabilir. Hassas olanlar ayrıca doğrulanmış bir kişi gerektirir.",
	"perm.sensitive": "Yalnızca doğrulanmış kişiler",
	"perm.sensitiveHelp": "Hassas. Bir role asla verilmez. Yalnızca doğrulanmış bir kişi kullanabilir ve her kullanım kaydedilir.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Botun gönderebileceği yerler",
	"perm.channelsHelp": "Listedeki bir kişi istediğinde, yanıt verdiği sohbetin yanı sıra ajanın gönderebileceği yerler. Bu, botun kimi dinleyeceğine karar vermez: Botun dinlediği kanallara bak. En fazla {{max}}.",
	"perm.channelsOff": "Botun gönderebileceği yerleri seçmek için yukarıdaki \"Diğer kanallara gönder\"i aç.",
	"perm.channelId": "Kanal kimliği",
	"perm.channelLabel": "Ad",
	"perm.channelAdd": "Yer ekle",
	"perm.channelRemove": "Yeri kaldır: {{id}}",
	"perm.remove": "Kaldır",
	"perm.channelFull": "Liste dolu.",
	"perm.channelProblem.id": "Her yerin, boşluksuz 1 ile {{max}} bayt arasında bir kimliği olmalı.",
	"perm.channelProblem.label": "Bir ad en fazla {{max}} karakterdir.",
	"perm.channelProblem.repeat": "Bir yer iki kez listelenmiş.",
	"perm.channelProblem.count": "En fazla {{max}} yer.",
	"perm.triggersNeed": "Bunu kullanmak için Tetikleyici öner'i aç.",
	"pair.start": "Bir kişiyi doğrula",
	"pair.startHelp": "Bir kod üretir. Onu, doğrulanacak hesaptan ona doğrudan mesajla ve on dakika içinde bota gönder. Kod bir kez çalışır.",
	"pair.needSave": "Önce bu botu kaydet, sonra bir kişiyi doğrula.",
	"pair.codeTitle": "Doğrulama kodun",
	"pair.codeHelp": "Bu kodu, doğrulanacak hesaptan bota doğrudan mesajla gönder. Yalnızca şimdi gösterilir, bir kez çalışır ve {{time}} zamanında sona erer.",
	"pair.codeGone": "Kodun süresi doldu. Kişi henüz doğrulanmadıysa yeni bir tane oluştur.",
	"pair.done": "Doğrulandı: {{sender}}.",
	"pair.dismiss": "Kodu gizle",
	"pair.none": "Doğrulanmış kimse yok.",
	"pair.expires": "sona erme: {{time}}",
	"pair.full": "Üç kişi doğrulanmış. Başka birini doğrulamak için birini kaldır.",
	"access.title": "Kontrol et",
	"access.needSave": "Son zamanlarda kimi reddettiğini görmek için önce bu botu kaydet.",
	"access.refresh": "Yenile",
	"access.who": "gönderen {{senders}}",
	"can.sender.role": "Rol: {{title}}",
	"can.fromForm": "Formun şu anki haline göre hesaplandı. Bu ayarları saklamak için kaydet.",
	"can.fromFormNew": "Henüz kaydedilmedi. Formun şu anki haline göre hesaplandı.",
	"can.loading": "Bu botun neler yapabileceği kontrol ediliyor",
	"can.stale": "Güncelleniyor",
	"can.errorTitle": "Bu botun neler yapabileceği kontrol edilemedi",
	"can.retry": "Yeniden dene",
	"can.allowed": "İzin verildi",
	"can.via.paired": "çünkü bu kişi doğrulanmış",
	"can.via.allowlist": "çünkü bu kişi listede",
	"can.via.agentConnection": "çünkü bu kişi doğrulanmış ve ajan eklentiye bağlı",
	"can.via.role": "{{role}} rolü üzerinden",
	"can.then": "Henüz kontrol edilmedi: {{list}}.",
	"can.then.server": "sunucu ayarları",
	"can.then.tools": "ajanın Araçlar anahtarı",
	"can.then.agent": "ajanın izinleri",
	"can.then.connection": "bu bağlantının izinleri",
	"can.then.sender": "kimin gönderdiği",
	"can.then.approval": "önerilerin nasıl onaylandığı",
	"can.noMessage": "İzin verilmedi.",
	"fix.open_connection": "Ayarı göster",
	"fix.open_agent": "Ajanı aç",
	"fix.open_server_setting": "Ayarlar'ı aç",
	"fix.pair_sender": "Bir kişiyi doğrula",
	"fix.add_person": "Kişi ekle",
	"fix.save": "Bu değişiklikleri sakla",
	"fix.token": "Token'ı yapıştır",
	"fix.tokenNew": "Yeni bir token yapıştır",
	"fix.agent": "Bir ajan seç",
	"fix.usual": "İzinleri seç",
	"fix.turnOn": "Aç",
	"fix.newTab": "(yeni sekmede açılır)",
	"fix.askAdmin": "Bir yöneticiye sor",
	"ready.title": "Durum",
	"ready.checkingSummary": "Formun ne yapacağı kontrol ediliyor.",
	"ready.allGood": "Gereken her şey hazır.",
	"ready.showAll": "Tüm {{count}} öğeyi göster",
	"ready.showProblems": "Yalnızca dikkat gerektirenleri göster",
	"ready.checking": "Kontrol ediliyor.",
	"ready.unchecked": "Bu kontrol edilemedi. Aşağıdaki \"Bu botun yapabilecekleri\"ne bak.",
	"ready.row.token": "Token",
	"ready.row.agent": "Ajan",
	"ready.row.who": "Kimler kullanabilir",
	"ready.row.permissions": "İzinler",
	"ready.row.addons": "Eklenti araçları",
	"ready.row.triggers": "Tetikleyiciler",
	"ready.row.files": "Dosyalar",
	"ready.row.notify": "Bildirimler",
	"ready.state.ok": "Tamam",
	"ready.state.attention": "Dikkat gerekiyor",
	"ready.state.off": "Kapalı",
	"ready.state.after_save": "Kaydettikten sonra",
	"ready.state.broken": "Çalışmıyor",
	"ready.state.checking": "Kontrol ediliyor",
	"ready.state.unknown": "Bilinmiyor",
	"ready.token.missing": "Botun token'ını yapıştır. Onsuz hiçbir şey alınmaz.",
	"ready.token.newTyped": "Token, kaydettiğinde platformla kontrol edilir.",
	"ready.token.typed": "Yeni token, kaydettiğinde platformla kontrol edilir.",
	"ready.token.failed": "Platform token'ı reddetti: {{reason}}",
	"ready.token.checked": "Platform token'ı kabul etti. {{bot}}",
	"ready.token.saved": "Bir token kayıtlı. Platform, kaydedildiğinde onu kabul etti.",
	"ready.agent.none": "Yanıt veren ajanı seç.",
	"ready.agent.credentialsOnly": "Ajan yok. Bu bağlantı yalnızca kimlik bilgilerini tutar ve hiçbir mesaja yanıt vermez.",
	"ready.agent.gone": "Seçilen ajan artık listende değil. Başka birini seç.",
	"ready.agent.noModel": "{{name}} ajanının modeli yok, bu yüzden yanıt veremez. Ona bir model ver.",
	"ready.agent.ok": "{{name}} yanıt veriyor, {{model}} modeliyle.",
	"ready.agent.okUnknown": "Bir ajan seçildi.",
	"ready.who.anyone": "Bota mesaj yazabilen herkes onu kullanabilir.",
	"ready.who.nobody": "Henüz listede kimse yok, bu yüzden bot her mesajı yok sayar. Bir kişi ekle.",
	"ready.who.channelsOnly": "Listede yalnızca kanallar var. Bir kanaldaki kişiler sohbet edebilir, ancak işaretlenen izinleri yalnızca kanal Buradaki herkes eylem isteyebilsin olarak ayarlıysa kullanabilir.",
	"ready.who.listed_one": "{{count}} kişi veya sohbet listede.",
	"ready.who.listed_other": "{{count}} kişi veya sohbet listede.",
	"ready.who.mixed": "{{count}} girdi listede, kişiler ve kanallar.",
	"ready.perm.none": "Hiçbir izin açık değil. Gönderenler sohbet edebilir, başka hiçbir şey yapamaz.",
	"ready.perm.noneSaved": "Hiçbir izin açık değil, bu yüzden dosyalar, bellek, tetikleyiciler ve gönderiler kapalı.",
	"ready.perm.onlyOwnRows": "Diğer izinler kapalı. Tetikleyiciler ve dosyalar aşağıda.",
	"ready.perm.ok_one": "{{count}} izin açık ve bir gönderen onu kullanabilir.",
	"ready.perm.ok_other": "{{count}} izin açık ve bir gönderen bunları kullanabilir.",
	"ready.perm.dead_one": "Kimse {{names}} iznini kullanamaz. {{message}}",
	"ready.perm.dead_other": "Açık izinlerden {{count}} tanesini kimse kullanamaz: {{names}}. İlki: {{message}}",
	"ready.addons.off": "Ajanın {{addon}} araçlarına sahip: {{tools}}, ve sen \"{{permission}}\"ı açana kadar bu sohbette onları kullanamaz.",
	"ready.addons.blocked": "Ajanın {{addon}} araçlarına sahip: {{tools}}, ve bunlar engelleniyor. {{message}}",
	"ready.addons.ok": "Ajan bu sohbette {{addon}} araçlarını kullanabilir: {{tools}}.",
	"ready.addons.paired": "Doğrulanmış kişiler bu sohbette {{addon}} yazma araçlarını kullanabilir: {{tools}}, çünkü bu ajan {{connection}} bağlantısına bağlı (yazma modu: {{mode}}). Doğrulanmamış listedeki kişiler \"{{permission}}\" gerektirir.",
	"ready.addons.removed": "\"{{permission}}\"ı kapattın, bu yüzden bu sohbette kimse {{addon}} yazma araçlarını kullanamaz: {{tools}}, doğrulanmış kişiler bile. Geri getirmek için aç; doğrulanmamış listedeki kişiler de onları alır.",
	"ready.addons.modeOff": "Ajanın {{addon}} yazma araçlarına sahip: {{tools}}, ve {{connection}} bağlantısının yazma modu kapalı olduğu için engelleniyor. O bağlantıdaki yazma modunu değiştir.",
	"ready.addons.mode.auto": "hemen çalışır",
	"ready.addons.mode.propose": "önce sorar",
	"ready.triggers.off": "Ajan burada hatırlatıcı veya zamanlanmış görev kuramaz.",
	"ready.triggers.blocked": "Tetikleyiciler açık ve kullanılamıyor. {{message}}",
	"ready.triggers.ok.ask": "Ajan tetikleyici önerebilir. Her birini başlamadan önce sen onaylarsın.",
	"ready.triggers.ok.auto": "Ajan tetikleyici önerebilir. Sana sormadan hemen başlarlar.",
	"ready.triggers.ok.auto_readonly": "Ajan tetikleyici önerebilir. Yalnızca okuyan bir tetikleyici hemen başlar; diğerlerini sen onaylarsın.",
	"ready.files.offReceive": "Gönderenler ajana dosya gönderemez.",
	"ready.files.offBoth": "Gönderenler ajana dosya gönderemez ve bot geri dosya göndermez.",
	"ready.files.blocked": "Dosya alma açık ve kullanılamıyor. {{message}}",
	"ready.files.ok": "Gönderenler ajana dosya gönderebilir ve bot geri dosya gönderebilir.",
	"ready.files.okReceive": "Gönderenler ajana dosya gönderebilir. Bot geri dosya göndermez.",
	"ready.notify.off": "Hiçbir sohbet bu bottan bildirim almıyor.",
	"ready.notify.ok": "Bildirimler şu sohbete gider: {{chat}}.",
	dismiss: "Kapat",
	credentialsOnly: "Yalnızca kimlik bilgileri",
	agentCredentialsOnly: "Ajan yok (yalnızca kimlik bilgileri)",
	agentOptionalHint: "İsteğe bağlı. Ajan olmadan bu bağlantı yalnızca token'ı, depo listesini ve sohbetlerin için yazma modunu tutar. Hiçbir mesaja yanıt vermez. Dinlemesi için bir ajan seç.",
	"sender.line_one": "{{name}} · {{count}} mesaj · {{id}}",
	"sender.line_other": "{{name}} · {{count}} mesaj · {{id}}",
	"ready.blocker.nobodyLetIn": "Henüz kimse içeri alınmadı.",
	"ready.blocker.nobodyPaired": "Bunun için doğrulanmış bir kişi gerekir ve henüz kimse doğrulanmadı.",
	optional: "isteğe bağlı",
	"approvals.title": "Hemen çalışan araçlar",
	"approvals.help": "Bu eklentinin bazı araçları onay kartı olmadan çalışabilir, ancak yalnızca sahibi bunu eklentinin sayfasında seçtiyse. Diğer her araç ve diğer her gönderen yine sorulur.",
	"approvals.state.asks": "Önce sorar",
	"approvals.state.runs": "Hemen çalışır",
	"approvals.state.idle": "Hemen çalışacak şekilde ayarlı, şu an bir şey yapmaz",
	"approvals.state.other": "Bu göndericiye yine önce sorar",
	"approvals.line.asks": "Bir kart senin onayını bekliyor.",
	"approvals.line.runs": "Sahibin kendi sohbetleri ve doğrulanmış kişiler için. Diğer herkese yine sorulur.",
	"approvals.line.idle": "Bu bağlantının yazma modu Salt okunur, bu yüzden hiçbir yazma aracı çalışmaz.",
	"approvals.line.other": "Yalnızca sahibi ve doğrulanmış bir kişi kartı atlar. Bu tür bir göndericiye sorulur.",
	"dup.text": "Bu bot ayrıca {{name}} olarak da bağlı. Her iki bağlantı da aynı mesaja yanıt verecek.",
	"dup.turnOff": "Bunu kapat",
	"dup.openOther": "Aç: {{name}}",
	"dup.saveAnyway": "Yine de kaydet",
	"dup.goBack": "Geri dön",
	"dup.confirmHelp": "Yalnızca her mesaja iki yanıt almak istiyorsan yine de kaydet.",
	"access.noteSave.title": "Notlar",
	"access.noteSave.now": "Notları hemen kaydeder ve Geri Al ile sana bildirir",
	"access.noteSave.ask": "Bu tür göndericiden gelen notlar sahibini bekler",
	"trust.answer": "Yalnızca yanıtla",
	"trust.act": "Buradaki herkes eylem isteyebilsin",
	"ready.row.channelTrust": "Botun dinlediği kanallar",
	"ready.row.postTo": "Botun gönderebileceği yerler",
	"ready.channelTrust.act": "{{channels}} içindeki kişiler günlük eylemler isteyebilir. Hassas olanlar yine doğrulanmış bir kişi gerektirir.",
	"ready.channelTrust.answer": "{{channels}} içindeki kişiler eylem kullanamaz: Buradaki herkes eylem isteyebilsin olarak ayarla.",
	"ready.channelTrust.noCaps": "İzinler altında hiçbir şey işaretli değil, bu yüzden herkesin isteyebildiği yerde bile dosyalar ve diğer eylemler reddedilir.",
	"fix.trust": "Kanalı ayarla",
	"can.via.channel": "Bu kanaldaki herkes bunu isteyebilir çünkü kanal Buradaki herkes eylem isteyebilsin olarak ayarlı",
	"ready.postTo_one": "Listedeki bir kişi istediğinde bot 1 başka yere gönderebilir. Bu, içindeki kişilere güvenmek anlamına gelmez.",
	"ready.postTo_other": "Listedeki bir kişi istediğinde bot {{count}} başka yere gönderebilir. Bu, içlerindeki kişilere güvenmek anlamına gelmez.",
	"access.toolsTitle": "Eklenti aracı çağrıları",
	"access.toolsHelp": "Bu bağlantıyı kullanan veya bu bottan gelen eklenti araçlarının son çağrıları, en yenisi önce, en fazla 20. Araç adlarını ve sebepleri tutar, neyin istendiğini veya yanıtlandığını asla tutmaz. Sunucu yeniden başladığında sıfırlanır.",
	"access.toolsNone": "Henüz araç çağrısı yok.",
	"access.outcome.ok": "tamam",
	"access.outcome.held": "bekletildi",
	"access.outcome.denied": "reddedildi",
	"access.outcome.error": "başarısız",
	"ready.addons.confirmChat": "Doğrulanmış bir kişi, sohbette {{addon}} yazmalarını onaylayabilir: bot her birini orada yazar ve kişi evet veya hayır diye yanıt verir.",
	"access.outcome.confirmed": "onaylandı",
	"access.outcome.cancelled": "iptal edildi",
	"access.outcome.expired": "süresi doldu",
	"access.askedBy": "isteyen: {{sender}}",
	"access.chat": "{{chat}} içinde",
	"sender.chat": "{{chat}} içinde",
	"sender.reason.not_listed": "listedeki bir kişi değil",
	"sender.reason.not_addressed": "mesaj botu anmadı",
	"ready.notReady": "Henüz hazır değil.",
	"ready.fixCount_one": "Düzeltilecek {{count}} şey",
	"ready.fixCount_other": "Düzeltilecek {{count}} şey",
	"ready.quiet_one": "Ayarlanacak {{count}} şey",
	"ready.quiet_other": "Ayarlanacak {{count}} şey",
	"ready.quietDone": "Ayarlanacak bir şey kalmadı",
	"matrix.title": "Kim ne yapabilir",
	"loops.title": "Beklemeler ve zamanlayıcılar",
	"loops.help": "Ajanın bu sohbette daha sonra kendi başına yapabilecekleri. Bunlar bota aittir: bir role asla verilmez.",
	"matrix.note": "Anahtarlar ve rol kutuları senin ayarlayacağın şeylerdir. Diğer her hücre, ana makinenin her mesaj için çalıştırdığı aynı kontrolle, ayarlarının şu anki haline göre hesaplanır.",
	"matrix.capability": "İzin",
	"matrix.pick": "Gönderen türü",
	"matrix.col.on": "Bu bot için açık",
	"matrix.col.paired": "Doğrulanmış kişi",
	"matrix.col.listed": "Listedeki kişi",
	"matrix.col.channel_acts": "Kanal: herkes eylem yapar",
	"matrix.col.channel_member": "Kanal: yalnızca yanıtla",
	"matrix.col.anyone": "Herkes",
	"matrix.state.yes": "Evet",
	"matrix.state.asks": "Önce sorar",
	"matrix.state.no": "Hayır",
	"matrix.state.waiting": "Bir kişiyi bekliyor",
	"matrix.state.off": "Kapalı",
	"matrix.state.unknown": "Bilinmiyor",
	"matrix.row.tools": "Bağlı hizmetlerdeki şeyleri değiştir",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Bir hücre neden Hayır veya Kapalı diyor",
	"matrix.detail.none": "Nedenini okumak için bir hücre seç.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Olağan kümeye sıfırla",
	"matrix.more": "Ayrıntılar",
	"matrix.less": "Ayrıntıları gizle",
	"matrix.nobodyVerified": "Henüz kimse doğrulanmadı.",
	"who.title": "Kimler bota konuşabilir",
	"who.onlyChosen": "Yalnızca seçtiğim kişiler",
	"who.anyone": "Mesaj yazabilen herkes",
	"who.people": "Kişiler",
	"who.peopleAndChannels": "Kişiler ve kanallar",
	"who.peopleNone": "Henüz listede kimse yok. Aşağıdan bir kişi ekle.",
	"who.channels": "Kanallar",
	"who.channelsNote": "Bir kanaldaki kişiler yalnızca o kanalın içinde işlem yapabilir, doğrudan mesajda asla.",
	"who.add": "Kişi veya kanal ekle",
	"who.recent": "Bota yakın zamanda yazan kişiler. Eklemek için birine tıkla.",
	"who.addPerson": "Ekle: {{name}}",
	"who.verified": "Doğrulanmış",
	"who.listed": "Listede",
	"who.verify": "Doğrula",
	"who.verifyPerson": "Doğrula: {{name}}",
	"who.remove": "Kaldır",
	"who.removePerson": "Kaldır: {{name}}",
	"who.removeChannel": "Kaldır: {{name}}",
	"who.levelFor": "{{channel}} içindeki kişilerin yapabilecekleri",
	"answer.more": "Dosya boyutları ve yanıt dili",
	"perm.channelsSwitch": "Anahtara git",
	"perm.channelWho": "Kimler gönderim yaptırabilir",
	"perm.channelWhoFor": "{{id}} içinde botun gönderim yapmasını kimler sağlayabilir",
	"perm.channelWho.any": "İzin verilen herhangi biri istediğinde",
	"perm.channelWho.verified": "Yalnızca doğrulanmış bir kişi istediğinde",
	"notify.label": "Hatırlatıcılarımı ve çalışma sonuçlarını şuraya gönder",
	"notify.none": "Hiçbir yere",
	"notify.people": "Kişiler",
	"notify.channels": "Kanallar",
	"notify.saved": "{{id}} (kayıtlı kimlik)",
	"notify.other": "Başka bir kimlik...",
	"notify.otherLabel": "Sohbet kimliği",
	"try.title": "Dene",
	"try.help": "Kimin yazdığını, nerede yazdığını ve ne istediğini seç. Bu, ana makinenin her mesaj için çalıştırdığı kontrolü, formun şu anki haline göre çalıştırır.",
	"try.noone": "Önce bir kişi ekle. Sonra neler yapabileceğini deneyebilirsin.",
	"try.whoLabel": "Kim",
	"try.placeLabel": "Nerede",
	"try.actionLabel": "Ne istiyor",
	"try.someoneIn": "{{channel}} içindeki biri",
	"try.anyone": "Herkes",
	"try.role": "{{role}} rolüne sahip biri",
	"try.dm": "Doğrudan mesaj",
	"try.where.dm": "doğrudan mesajda",
	"try.where.channel": "{{channel}} içinde",
	"try.is.paired": "{{who}} doğrulanmış bir kişi, {{where}} yazıyor.",
	"try.is.listed": "{{who}} listedeki bir kişi, {{where}} yazıyor.",
	"try.is.channelActs": "{{channel}} içindeki biri, buradaki herkesin eylem isteyebildiği yerde.",
	"try.is.channelAnswers": "{{channel}} içindeki biri, kişilerin yalnızca yanıt aldığı yerde.",
	"try.is.anyone": "Bota mesaj yazabilen herkes içeri alınır.",
	"try.is.role": "{{role}} rolüne sahip bir kişi içeri alınır.",
	"try.verdict.allowed": "İzin verildi.",
	"try.verdict.asks": "İzin verildi, ancak önce sorar.",
	"try.verdict.refused": "Reddedildi.",
	"try.loading": "Kontrol ediliyor...",
	"try.error": "Kontrol yanıt vermedi. Yukarıdaki tablodaki Yeniden dene'yi kullan.",
	"try.unknown": "Ana makine bu tür gönderen için yanıt vermedi.",
	"try.note": "Platforma hiçbir şey gönderilmez ve hiçbir şey kaydedilmez.",
	"refusals.title": "Son retler",
	"refusals.help": "Sunucu başladığından beri botun reddettikleri, en yenisi önce. Kimlikleri, adları ve sohbetleri tutar, mesaj metnini asla tutmaz. Bu günlük yalnızca bellekte tutulur: sunucu yeniden başladıktan sonra boştur.",
	"refusals.none": "Sunucu başladığından beri reddedilen bir şey yok.",
	"refusals.refused": "reddedildi",
	"refusals.action": "istenen: {{action}}",
	"refusals.talk": "bota yazdı",
	"refusals.allow": "İzin ver: {{name}}",
	"refusals.act": "{{channel}} üyelerinin işlem yapmasına izin ver",
	"perm.channelPickOther": "Diğer: bir kimlik yaz",
	"perm.channelHint.verified": "Zamanlanmış çalışmalar buraya gönderim yapamaz. İzin vermek için \"İzin verilen herhangi biri istediğinde\"yi seç.",
	"perm.channelHint.any": "Zamanlanmış çalışmalar buraya gönderim yapabilir.",
	"perm.channelNoListen": "Bot bu kanalı dinlemiyor, bu yüzden oraya yalnızca gönderim yapar.",
	"who.post.none": "Bot buraya gönderim yapamaz.",
	"who.post.add": "Botun buraya da gönderim yapmasına izin ver",
	"who.post.addFor": "Botun {{name}} içine de gönderim yapmasına izin ver",
	"who.post.verified": "Buraya yalnızca doğrulanmış bir kişi istediğinde gönderim yapar.",
	"who.post.any": "Buraya izin verilen herhangi biri istediğinde gönderim yapar.",
	"who.post.show": "Yeri göster",
	"who.post.showFor": "Yeri göster: {{name}}",
	agentLink: "Ajanı aç: {{name}}",
	"saved.created": "Bağlantı eklendi.",
	"saved.nothing": "Kaydedildi. Hiçbir şey değişmedi.",
	"saved.changed": "Kaydedildi. Değişenler: {{what}}.",
	"saved.part.name": "ad",
	"saved.part.agent": "ajan",
	"saved.part.who": "kimleri kabul ettiği",
	"saved.part.permissions": "izinler",
	"saved.part.approval": "tetikleyici onayı ve eylemler",
	"saved.part.files": "dosya ayarları",
	"saved.part.notify": "bildirimler",
	"saved.dropped.title": "Bu bağlantı artık bu eylemlere izin vermiyor, bu yüzden bu tetikleyicilerin çalışmaları bunları kaybeder:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "Çalışıyor",
	"conn.state.off": "Kapalı",
	"conn.state.attention": "Dikkat gerekiyor",
	"conn.state.ready": "Hazır",
	"conn.row.open": "{{name}}: {{state}}. Ayrıntıları göster",
	"conn.row.menu": "Daha fazla işlem: {{name}}",
	"conn.row.testNamed": "Sına: {{name}}",
	"conn.fix.token": "Token'ı düzelt",
	"conn.reason.noToken": "Kayıtlı token yok.",
	"conn.reason.duplicate": "{{name}} ile aynı bota yanıt veriyor.",
	"conn.reason.testFailed": "Son sınama başarısız oldu: {{reason}}",
	"conn.kv.service": "Hizmet",
	"conn.kv.accepts": "Kabul eder",
	"conn.kv.replies": "Yanıtlar",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Kayıtlı",
	"conn.kv.notSaved": "Kayıtlı değil",
	"conn.kv.agents": "Ajanlar",
	"usedBy.count_one": "{{count}} ajan kullanıyor",
	"usedBy.count_other": "{{count}} ajan kullanıyor",
	"usedBy.none": "Hiçbir ajan kullanmıyor",
	"conn.pane.lastTest": "Son sınama",
	"conn.pane.never": "Bu tarayıcıda henüz sınanmadı.",
	"conn.pane.passed": "Başarılı: {{when}}.",
	"conn.pane.failed": "Başarısız: {{when}}.",
	"conn.pane.connection": "Bağlantı",
	"conn.pane.remove": "Kaldır",
	"conn.pane.test": "Bağlantıyı sına",
	"conn.pane.testing": "Sınanıyor...",
	"conn.sheet.addDesc": "Ona bir ad ver, token'ını ekle ve yanıt verecek ajanı seç.",
	"conn.sheet.editDesc": "Değişiklikler kaydettiğinde uygulanır. Kayıtlı bir token bir daha gösterilmez.",
	"conn.sheet.connection": "Bağlantı",
	"conn.sheet.who": "Kimler ona konuşabilir",
	"conn.sheet.may": "Neler yapabilir",
	"conn.sheet.replies": "Yanıtlar, dosyalar ve yerler",
	"conn.sheet.check": "Ne yapacağını kontrol et",
	"conn.sheet.saveAndTest": "Kaydet ve sına",
	"conn.sheet.saving": "Kaydediliyor...",
	"conn.sheet.testFailed": "Bağlantı kaydedildi, ancak sınama başarısız oldu.",
	"conn.sheet.testFailedNoReason": "Sebep belirtilmedi.",
	"conn.sheet.testAgain": "Yeniden sına",
	"conn.sheet.close": "Kapat",
	"conn.sheet.agentFixed": "{{name}} ajanıyla yanıt verir",
	"conn.preset.label": "İzinler",
	"conn.preset.answer": "Yalnızca yanıtla",
	"conn.preset.answerHelp": "Mesajlara yanıt verir. Bu bağlantı kendi başına izin eklemez.",
	"conn.preset.standard": "Standart",
	"conn.preset.standardHelp": "Ajanın sahip olduğu olağan küme: {{list}}.",
	"conn.preset.standardNone": "Olağan küme. Bu ajan bunların hiçbirine sahip değil.",
	"conn.preset.custom": "Özel",
	"conn.preset.customHelp": "Her izni ve kimlerin kullanabileceğini seç.",
	"conn.preset.note": "Bir hazır ayar hassas bir izni asla açmaz. Onlar için Özel'i kullan. Ajanın sahip olduğu eklenti bağlantılarının kendi kuralları vardır: doğrulanmış kişiler yine de yazma araçlarını kullanabilir. Bunu ajanda, \"Neleri kullanabilir\" altında değiştir.",
	"conn.discard.title": "Değişikliklerinden vazgeçilsin mi?",
	"conn.discard.message": "Bu bağlantıyı değiştirdin ve kaydetmedin.",
	"conn.discard.confirm": "Değişikliklerden vazgeç",
	"share.label": "Paylaş",
	"share.button": "Paylaş: {{name}}",
	"share.intro": "Eklediğin kişiler bu bağlantıyı kendi sohbetlerinde ve ajanlarında kullanabilir. Adını ve durumunu görürler, token'ını veya ayarlarını asla. Bota gelen mesajlar yine senin ajanına ulaşır.",
	"share.roleUse": "Kullanabilir",
	"share.roleUseHelp": "Sohbetlerinde ve ajanlarında kullanabilir. Token'ı göremez, değiştiremez veya paylaşamaz.",
	"shared.title": "Seninle paylaşılanlar",
	"shared.text": "Başka kişiler bu bağlantıları sohbetlerinde ve ajanlarında kullanmana izin verdi. Onları yalnızca sahipleri değiştirebilir.",
	"shared.on": "Dinliyor",
	"shared.off": "Kapalı",
	"shared.by": "Paylaşan: {{name}}",
	loginNeedsHost: "LocalAI'nin bu sürümü bu sayfadan giriş yapamaz. Buradan bağlanmak için LocalAI'yi güncelle."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/connector.pt-BR.json
var connector_pt_BR_default = {
	"answer.title": "Onde ele publica e como responde",
	"answer.replyLabel": "Enquanto o agente trabalha",
	"answer.reply.off": "Digitando, depois a resposta",
	"answer.reply.progress": "Progresso: as ferramentas que usa",
	"answer.reply.stream": "Ao vivo: a resposta conforme é escrita",
	"answer.reply.reasoning": "Raciocínio: o raciocínio do modelo, depois a resposta",
	"answer.replyHelp": "Progresso e Ao vivo mostram uma única mensagem de trabalho, que a resposta substitui. Em uma plataforma com rascunhos, Ao vivo mostra um rascunho a um chat privado, e a resposta vem depois. Uma resposta longa continua em novas mensagens.",
	"answer.replyReasoningHelp": "Raciocínio mostra o raciocínio do modelo, enquanto ele escreve, a cada remetente desta ligação. Use apenas onde isso for aceitável.",
	"answer.conversationLabel": "Conversas",
	"answer.conversationHelp": "Envie /new (ou !new) no app para iniciar um novo chat.",
	"answer.conversation.sender": "Um chat por pessoa",
	"answer.conversation.chat": "Um chat por grupo ou canal",
	"answer.conversation.window": "Por pessoa, novo após uma pausa",
	"answer.conversation.thread": "Novo chat por mensagem; as respostas continuam",
	"answer.window": "Pausa, em minutos",
	"answer.windowRange": "Use um número inteiro de 1 a {{max}}.",
	"answer.languageLabel": "Idioma das respostas",
	"answer.languageHelp": "As mensagens que o bot escreve por conta própria, como confirmações e recusas. As respostas do modelo seguem o idioma da conversa.",
	"answer.language.auto": "Automático (o idioma da sua interface, senão o do remetente)",
	"answer.language.en": "English",
	"answer.language.it": "Italiano",
	"answer.language.de": "Deutsch",
	"answer.language.es": "Español",
	"answer.language.fr": "Français",
	"answer.language.pt-BR": "Português (Brasil)",
	"answer.files": "Enviar os arquivos que o agente cria",
	add: "Adicionar",
	more: "Mais",
	less: "Menos",
	"answer.filesHelp": "Depois da resposta, até 5 arquivos. Programas e scripts não são enviados. O limite de tamanho está em Tamanho dos arquivos e idioma das respostas.",
	"answer.summary": "Responde: {{reply}} · {{conversation}}",
	"answer.short.off": "digitando",
	"answer.short.progress": "progresso",
	"answer.short.stream": "resposta ao vivo",
	"answer.short.reasoning": "raciocínio visível",
	"answer.short.sender": "um chat por pessoa",
	"answer.short.chat": "um chat por grupo",
	"answer.short.window": "novo chat após {{count}} min",
	"answer.short.thread": "um chat por mensagem",
	"approval.title": "Timers e gatilhos a partir do chat",
	"approval.help": "Quando o agente configura algo que roda depois (\"em 10 minutos\", \"todo dia\"), cada execução é uma execução do modelo.",
	"approval.mode.ask": "Pergunta antes: o bot propõe no chat e a pessoa responde sim ou não",
	"approval.mode.auto": "Age na hora: é configurado e a pessoa é avisada de como cancelar",
	"approval.mode.auto_readonly": "Age na hora quando as execuções só leem e relatam; senão, pergunta antes",
	"approval.limitsHelp": "Estes limites definem o que é configurado sem perguntar. Deixe um campo vazio para usar o padrão. O que passar de um limite é perguntado.",
	"approval.max_pending": "Máximo de timers e gatilhos ao mesmo tempo",
	"approval.min_gap_minutes": "Mínimo de minutos entre execuções de um gatilho recorrente",
	"approval.max_runs_per_day": "Máximo de execuções por dia, no total",
	"approval.max_lifetime_days": "Duração máxima, em dias",
	"approval.invalid": "Use um número inteiro de 1 a {{max}}, ou deixe vazio.",
	"approval.default": "Padrão: {{value}}.",
	"approval.summary": "Gatilhos: {{mode}}",
	"approval.effect": "Propostas: {{mode}}",
	"approval.effectChange": "Alterações e exclusões: {{mode}}",
	"approval.limits": "Limites",
	"approval.acts.title": "Execuções podem agir",
	"approval.acts.help": "Desligado: as execuções de um gatilho criado neste chat só leem e relatam. Ligado: elas também podem fazer o que você marcar abaixo, e só o que o agente tem.",
	"approval.acts.modes": "Pergunta antes: você sempre decide. Age na hora: só quando você é uma pessoa verificada e todas as ações estão marcadas aqui.",
	"approval.acts.act.files": "Escrever arquivos nas pastas do agente",
	"approval.acts.act.files.effect": "Uma execução pode criar e alterar arquivos que o agente guarda.",
	"approval.acts.act.addons": "Usar as ações dos complementos do agente",
	"approval.acts.act.addons.effect": "Uma execução pode usar o que os complementos do agente fazem, inclusive comandos.",
	"approval.acts.act.send": "Enviar mensagens além de onde relata",
	"approval.acts.act.send.effect": "Uma execução pode escrever em outros chats e canais por conta própria.",
	"approval.acts.act.spend": "Usar ferramentas pagas ou externas e a rede",
	"approval.acts.act.spend.effect": "Uma execução pode chamar serviços fora do LocalAI, o que pode custar dinheiro.",
	"approval.acts.lacks": "O agente não tem isto.",
	"approval.acts.sensitive": "Sensível",
	"approval.effectActs": ", as execuções podem: {{acts}}",
	"approval.actShort.act.files": "escrever arquivos",
	"approval.actShort.act.addons": "usar complementos",
	"approval.actShort.act.send": "enviar mensagens",
	"approval.actShort.act.spend": "usar ferramentas pagas ou externas",
	"approval.short.ask": "pergunta antes",
	"approval.short.auto": "age na hora",
	"approval.short.auto_readonly": "age na hora se for só leitura",
	"files.title": "Arquivos",
	"files.help": "Deixe um campo vazio para usar o limite do complemento. O seu limite só pode ser menor que esse.",
	"files.receiveLabel": "Maior arquivo que lê, em MiB",
	"files.sendLabel": "Maior arquivo que envia, em MiB",
	"files.invalid": "Use um número maior que 0.",
	"files.tooHigh": "O complemento permite no máximo {{max}} aqui.",
	"files.now": "Agora: {{limit}} ({{layer}}).",
	"files.receiveHelp": "Arquivos que as pessoas enviam ao bot. Um arquivo maior é recusado, e o bot diz qual limite atingiu.",
	"files.sendHelp": "Arquivos que o agente cria e o bot envia de volta. Um arquivo maior não é enviado, e o bot diz qual limite atingiu.",
	"files.addon.off": "Este complemento não move arquivos nesta direção, então não há nada a configurar.",
	"files.addon.declared": "O complemento declara até {{max}}.",
	"files.addon.open": "O complemento não declara limite, então vale o limite da plataforma.",
	"files.host": "Nenhum bot pode mover um arquivo acima de {{max}}. Um administrador define isso nas configurações.",
	"files.layer.owner": "limite definido para este bot",
	"files.layer.addon": "limite do complemento",
	"files.layer.host": "limite da plataforma",
	"perm.agentLacks": "O agente não tem isto.",
	"perm.rule": "Pessoas listadas podem usar as permissões marcadas. As sensíveis também exigem uma pessoa verificada.",
	"perm.sensitive": "Só pessoas verificadas",
	"perm.sensitiveHelp": "Sensível. Nunca é dada a um papel. Só uma pessoa verificada pode usá-la, e todo uso é registrado.",
	"perm.roleCap": "{{role}}: {{cap}}",
	"perm.channelsTitle": "Lugar onde o bot pode publicar",
	"perm.channelsHelp": "Lugares onde o agente pode publicar quando uma pessoa listada pede, além do chat em que responde. Isso não decide quem o bot escuta: veja Canais onde o bot escuta. No máximo {{max}}.",
	"perm.channelsOff": "Ligue \"Publicar em outros canais\" acima para escolher os lugares onde o bot pode publicar.",
	"perm.channelId": "ID do canal",
	"perm.channelLabel": "Nome",
	"perm.channelAdd": "Adicionar um lugar",
	"perm.channelRemove": "Remover o lugar {{id}}",
	"perm.remove": "Remover",
	"perm.channelFull": "A lista está cheia.",
	"perm.channelProblem.id": "Cada lugar precisa de um ID de 1 a {{max}} bytes, sem espaços.",
	"perm.channelProblem.label": "Um nome tem no máximo {{max}} caracteres.",
	"perm.channelProblem.repeat": "Um lugar aparece duas vezes na lista.",
	"perm.channelProblem.count": "No máximo {{max}} lugares.",
	"perm.triggersNeed": "Ligue Propor gatilhos para usar isto.",
	"pair.start": "Verificar uma pessoa",
	"pair.startHelp": "Gera um código. Envie-o ao bot em mensagem direta, da conta a verificar, em até dez minutos. O código vale uma vez.",
	"pair.needSave": "Salve este bot primeiro, depois verifique uma pessoa.",
	"pair.codeTitle": "Seu código de verificação",
	"pair.codeHelp": "Envie este código ao bot em mensagem direta, da conta a verificar. Ele só aparece agora, vale uma vez e expira às {{time}}.",
	"pair.codeGone": "O código expirou. Gere um novo se a pessoa ainda não estiver verificada.",
	"pair.done": "Verificada: {{sender}}.",
	"pair.dismiss": "Ocultar o código",
	"pair.none": "Ninguém está verificado.",
	"pair.expires": "termina {{time}}",
	"pair.full": "Três pessoas estão verificadas. Remova uma para verificar outra.",
	"access.title": "Verifique",
	"access.needSave": "Salve este bot primeiro para ver quem ele recusou recentemente.",
	"access.refresh": "Atualizar",
	"access.who": "remetente {{senders}}",
	"can.sender.role": "Papel: {{title}}",
	"can.fromForm": "Calculado a partir do formulário como está agora. Salve para manter estas configurações.",
	"can.fromFormNew": "Ainda não salvo. Calculado a partir do formulário como está agora.",
	"can.loading": "Verificando o que este bot pode fazer",
	"can.stale": "Atualizando",
	"can.errorTitle": "Não foi possível verificar o que este bot pode fazer",
	"can.retry": "Tentar de novo",
	"can.allowed": "Permitido",
	"can.via.paired": "porque esta pessoa está verificada",
	"can.via.allowlist": "porque esta pessoa está listada",
	"can.via.agentConnection": "porque esta pessoa está verificada e o agente está conectado ao complemento",
	"can.via.role": "pelo papel {{role}}",
	"can.then": "Ainda não verificado: {{list}}.",
	"can.then.server": "as configurações do servidor",
	"can.then.tools": "a chave Ferramentas do agente",
	"can.then.agent": "as permissões do agente",
	"can.then.connection": "as permissões desta conexão",
	"can.then.sender": "quem está enviando",
	"can.then.approval": "como as propostas são confirmadas",
	"can.noMessage": "Não permitido.",
	"fix.open_connection": "Mostrar a configuração",
	"fix.open_agent": "Abrir o agente",
	"fix.open_server_setting": "Abrir Configurações",
	"fix.pair_sender": "Verificar uma pessoa",
	"fix.add_person": "Adicionar uma pessoa",
	"fix.save": "Manter estas alterações",
	"fix.token": "Colar o token",
	"fix.tokenNew": "Colar um novo token",
	"fix.agent": "Escolher um agente",
	"fix.usual": "Escolher permissões",
	"fix.turnOn": "Ligar",
	"fix.newTab": "(abre em uma nova aba)",
	"fix.askAdmin": "Pedir a um administrador",
	"ready.title": "Status",
	"ready.checkingSummary": "Verificando o que o formulário fará.",
	"ready.allGood": "Tudo o que é necessário está no lugar.",
	"ready.showAll": "Mostrar todos os {{count}}",
	"ready.showProblems": "Mostrar só o que precisa de atenção",
	"ready.checking": "Verificando.",
	"ready.unchecked": "Não foi possível verificar isto. Veja \"O que este bot pode fazer\" abaixo.",
	"ready.row.token": "Token",
	"ready.row.agent": "Agente",
	"ready.row.who": "Quem pode usar",
	"ready.row.permissions": "Permissões",
	"ready.row.addons": "Ferramentas de complementos",
	"ready.row.triggers": "Gatilhos",
	"ready.row.files": "Arquivos",
	"ready.row.notify": "Notificações",
	"ready.state.ok": "OK",
	"ready.state.attention": "Precisa de atenção",
	"ready.state.off": "Desligado",
	"ready.state.after_save": "Depois de salvar",
	"ready.state.broken": "Não funciona",
	"ready.state.checking": "Verificando",
	"ready.state.unknown": "Desconhecido",
	"ready.token.missing": "Cole o token do bot. Sem ele nada é recebido.",
	"ready.token.newTyped": "O token é verificado com a plataforma quando você salva.",
	"ready.token.typed": "O novo token é verificado com a plataforma quando você salva.",
	"ready.token.failed": "A plataforma recusou o token: {{reason}}",
	"ready.token.checked": "A plataforma aceitou o token. {{bot}}",
	"ready.token.saved": "Há um token salvo. A plataforma o aceitou quando foi salvo.",
	"ready.agent.none": "Escolha o agente que responde.",
	"ready.agent.credentialsOnly": "Sem agente. Esta conexão só guarda as credenciais e não responde a nenhuma mensagem.",
	"ready.agent.gone": "O agente escolhido não está mais na sua lista. Escolha outro.",
	"ready.agent.noModel": "{{name}} não tem modelo, então não pode responder. Dê um a ele.",
	"ready.agent.ok": "{{name}} responde, com o modelo {{model}}.",
	"ready.agent.okUnknown": "Um agente está escolhido.",
	"ready.who.anyone": "Qualquer pessoa que possa enviar mensagem ao bot pode usá-lo.",
	"ready.who.nobody": "Ninguém está listado ainda, então o bot ignora todas as mensagens. Adicione uma pessoa.",
	"ready.who.channelsOnly": "Só há canais na lista. As pessoas de um canal podem conversar, mas só usam as permissões marcadas onde o canal está em Deixar todos aqui pedirem ações.",
	"ready.who.listed_one": "{{count}} pessoa ou chat está listado.",
	"ready.who.listed_other": "{{count}} pessoas ou chats estão listados.",
	"ready.who.mixed": "{{count}} entradas estão listadas, pessoas e canais.",
	"ready.perm.none": "Nenhuma permissão está ligada. Os remetentes podem conversar, e nada mais.",
	"ready.perm.noneSaved": "Nenhuma permissão está ligada, então arquivos, memória, gatilhos e publicações estão desligados.",
	"ready.perm.onlyOwnRows": "As outras permissões estão desligadas. Gatilhos e arquivos estão abaixo.",
	"ready.perm.ok_one": "{{count}} permissão está ligada e um remetente pode usá-la.",
	"ready.perm.ok_other": "{{count}} permissões estão ligadas e um remetente pode usá-las.",
	"ready.perm.dead_one": "Ninguém pode usar {{names}}. {{message}}",
	"ready.perm.dead_other": "Ninguém pode usar {{count}} das permissões ligadas: {{names}}. Primeiro: {{message}}",
	"ready.addons.off": "O agente tem as ferramentas de {{addon}} {{tools}}, mas não pode usá-las neste chat até você ligar \"{{permission}}\".",
	"ready.addons.blocked": "O agente tem as ferramentas de {{addon}} {{tools}}, mas elas estão retidas. {{message}}",
	"ready.addons.ok": "O agente pode usar as ferramentas de {{addon}} {{tools}} neste chat.",
	"ready.addons.paired": "Pessoas verificadas podem usar as ferramentas de escrita de {{addon}} ({{tools}}) neste chat, porque o agente está conectado a {{connection}} (modo de escrita: {{mode}}). Pessoas listadas que não estão verificadas precisam de \"{{permission}}\".",
	"ready.addons.removed": "Você desligou \"{{permission}}\", então ninguém pode usar as ferramentas de escrita de {{addon}} ({{tools}}) neste chat, nem pessoas verificadas. Ligue para trazê-las de volta; pessoas listadas que não estão verificadas também as recebem.",
	"ready.addons.modeOff": "O agente tem as ferramentas de escrita de {{addon}} ({{tools}}), mas elas estão retidas porque o modo de escrita de {{connection}} está desativado. Altere o modo de escrita nessa conexão.",
	"ready.addons.mode.auto": "age na hora",
	"ready.addons.mode.propose": "pergunta antes",
	"ready.triggers.off": "O agente não pode configurar lembretes nem tarefas agendadas aqui.",
	"ready.triggers.blocked": "Os gatilhos estão ligados, mas não podem ser usados. {{message}}",
	"ready.triggers.ok.ask": "O agente pode propor gatilhos. Você confirma cada um antes de começar.",
	"ready.triggers.ok.auto": "O agente pode propor gatilhos. Eles começam na hora, sem perguntar a você.",
	"ready.triggers.ok.auto_readonly": "O agente pode propor gatilhos. Um gatilho que só lê começa na hora; você confirma os outros.",
	"ready.files.offReceive": "Os remetentes não podem enviar arquivos ao agente.",
	"ready.files.offBoth": "Os remetentes não podem enviar arquivos ao agente, e o bot não envia nenhum de volta.",
	"ready.files.blocked": "O recebimento de arquivos está ligado, mas não pode ser usado. {{message}}",
	"ready.files.ok": "Os remetentes podem enviar arquivos ao agente, e o bot pode enviar arquivos de volta.",
	"ready.files.okReceive": "Os remetentes podem enviar arquivos ao agente. O bot não envia nenhum de volta.",
	"ready.notify.off": "Nenhum chat recebe avisos deste bot.",
	"ready.notify.ok": "Os avisos vão para o chat {{chat}}.",
	dismiss: "Descartar",
	credentialsOnly: "Só credenciais",
	agentCredentialsOnly: "Sem agente (só credenciais)",
	agentOptionalHint: "Opcional. Sem um agente, esta conexão só guarda o token, a lista de repositórios e o modo de escrita dos seus chats. Ela não responde a mensagens. Escolha um agente para ela passar a escutar.",
	"sender.line_one": "{{name}} · {{count}} mensagem · {{id}}",
	"sender.line_other": "{{name}} · {{count}} mensagens · {{id}}",
	"ready.blocker.nobodyLetIn": "Ninguém foi liberado ainda.",
	"ready.blocker.nobodyPaired": "Isto exige uma pessoa verificada, e ninguém está verificado ainda.",
	optional: "opcional",
	"approvals.title": "Ferramentas que agem na hora",
	"approvals.help": "Some tools of this add-on can run without a confirmation card, but only when the owner chose that on the page of the add-on. Every other tool and every other sender is still asked.",
	"approvals.state.asks": "Pergunta antes",
	"approvals.state.runs": "Age na hora",
	"approvals.state.idle": "Configurado para agir na hora, não faz nada agora",
	"approvals.state.other": "Ainda pergunta antes a este remetente",
	"approvals.line.asks": "Um cartão está aguardando seu OK.",
	"approvals.line.runs": "Para os chats do proprietário e para pessoas verificadas. Todos os outros ainda são perguntados.",
	"approvals.line.idle": "The write mode of this connection is Read only, so no write tool runs.",
	"approvals.line.other": "Só o proprietário e uma pessoa verificada pulam o cartão. Este tipo de remetente é perguntado.",
	"dup.text": "Este bot também está conectado como {{name}}. As duas conexões vão responder à mesma mensagem.",
	"dup.turnOff": "Desativar esta",
	"dup.openOther": "Abrir {{name}}",
	"dup.saveAnyway": "Salvar mesmo assim",
	"dup.goBack": "Voltar",
	"dup.confirmHelp": "Salve mesmo assim só se você quiser receber duas respostas para cada mensagem.",
	"access.noteSave.title": "Notas",
	"access.noteSave.now": "Salva as notas na hora e avisa, com Desfazer",
	"access.noteSave.ask": "As notas deste tipo de remetente esperam o proprietário",
	"trust.answer": "Só responder",
	"trust.act": "Deixar todos aqui pedirem ações",
	"ready.row.channelTrust": "Canais onde o bot escuta",
	"ready.row.postTo": "Lugar onde o bot pode publicar",
	"ready.channelTrust.act": "Pessoas em {{channels}} podem pedir ações comuns. As sensíveis ainda exigem uma pessoa verificada.",
	"ready.channelTrust.answer": "As pessoas de {{channels}} não podem usar ações: defina como Deixar todos aqui pedirem ações.",
	"ready.channelTrust.noCaps": "Nada está marcado em permissões, então arquivos e outras ações são recusados mesmo onde todos podem pedir.",
	"fix.trust": "Configurar o canal",
	"can.via.channel": "Todos neste canal podem pedir isso porque o canal está em Deixar todos aqui pedirem ações",
	"ready.postTo_one": "O bot pode publicar em mais 1 lugar quando uma pessoa listada pede. Isso não dá confiança às pessoas nele.",
	"ready.postTo_other": "O bot pode publicar em mais {{count}} lugares quando uma pessoa listada pede. Isso não dá confiança às pessoas neles.",
	"access.toolsTitle": "Chamadas às ferramentas dos complementos",
	"access.toolsHelp": "As últimas chamadas às ferramentas dos complementos que usaram esta conexão ou chegaram por este bot, da mais recente para a mais antiga, no máximo 20. Contêm nomes de ferramentas e motivos, nunca o que foi pedido ou respondido. Zeram quando o servidor reinicia.",
	"access.toolsNone": "Ainda não há chamadas.",
	"access.outcome.ok": "concluída",
	"access.outcome.held": "retida",
	"access.outcome.denied": "negada",
	"access.outcome.error": "falhou",
	"ready.addons.confirmChat": "Uma pessoa verificada pode confirmar no chat as escritas de {{addon}}: o bot escreve cada uma lá e a pessoa responde sim ou não.",
	"access.outcome.confirmed": "confirmada",
	"access.outcome.cancelled": "cancelada",
	"access.outcome.expired": "expirada",
	"access.askedBy": "pedida por {{sender}}",
	"access.chat": "em {{chat}}",
	"sender.chat": "em {{chat}}",
	"sender.reason.not_listed": "não é uma pessoa listada",
	"sender.reason.not_addressed": "a mensagem não citava o bot",
	"ready.notReady": "Ainda não está pronto.",
	"ready.fixCount_one": "{{count}} coisa para corrigir",
	"ready.fixCount_other": "{{count}} coisas para corrigir",
	"ready.quiet_one": "{{count}} coisa para configurar",
	"ready.quiet_other": "{{count}} coisas para configurar",
	"ready.quietDone": "Nada mais para configurar",
	"matrix.title": "Quem pode fazer o quê",
	"loops.title": "Esperas e temporizadores",
	"loops.help": "O que o agente pode fazer depois neste chat sozinho. Isso pertence ao bot: um papel nunca recebe.",
	"matrix.note": "Os interruptores e as caixas dos papéis são seus para ajustar. Todas as outras células são calculadas a partir das suas configurações atuais, pela mesma verificação que o host faz a cada mensagem.",
	"matrix.capability": "Permissão",
	"matrix.pick": "Tipo de remetente",
	"matrix.col.on": "Ligado para este bot",
	"matrix.col.paired": "Pessoa verificada",
	"matrix.col.listed": "Pessoa listada",
	"matrix.col.channel_acts": "Canal: todos agem",
	"matrix.col.channel_member": "Canal: só responder",
	"matrix.col.anyone": "Qualquer pessoa",
	"matrix.state.yes": "Sim",
	"matrix.state.asks": "Pergunta antes",
	"matrix.state.no": "Não",
	"matrix.state.waiting": "Aguardando uma pessoa",
	"matrix.state.off": "Desligado",
	"matrix.state.unknown": "Desconhecido",
	"matrix.row.tools": "Alterar coisas em serviços conectados",
	"matrix.toolRow": "{{addon}}: {{tool}}",
	"matrix.detail.label": "Por que uma célula diz Não ou Desligado",
	"matrix.detail.none": "Escolha uma célula para ler o motivo.",
	"matrix.detail.title": "{{capability}}: {{who}}",
	"matrix.reset": "Voltar ao conjunto habitual",
	"matrix.more": "Detalhes",
	"matrix.less": "Ocultar os detalhes",
	"matrix.nobodyVerified": "Ninguém foi verificado ainda.",
	"who.title": "Quem pode falar com o bot",
	"who.onlyChosen": "Somente as pessoas que eu escolher",
	"who.anyone": "Qualquer pessoa que possa enviar mensagem",
	"who.people": "Pessoas",
	"who.peopleAndChannels": "Pessoas e canais",
	"who.peopleNone": "Ninguém está na lista ainda. Adicione uma pessoa abaixo.",
	"who.channels": "Canais",
	"who.channelsNote": "As pessoas de um canal só podem agir dentro desse canal, nunca em uma mensagem direta.",
	"who.add": "Adicionar uma pessoa ou um canal",
	"who.recent": "Pessoas que escreveram ao bot recentemente. Clique para adicionar.",
	"who.addPerson": "Adicionar {{name}}",
	"who.verified": "Verificada",
	"who.listed": "Na lista",
	"who.verify": "Verificar",
	"who.verifyPerson": "Verificar {{name}}",
	"who.remove": "Remover",
	"who.removePerson": "Remover {{name}}",
	"who.removeChannel": "Remover {{name}}",
	"who.levelFor": "O que as pessoas em {{channel}} podem fazer",
	"answer.more": "Tamanho dos arquivos e idioma das respostas",
	"perm.channelsSwitch": "Ir para o interruptor",
	"perm.channelWho": "Quem pode fazer com que publique",
	"perm.channelWhoFor": "Quem pode fazer o bot publicar em {{id}}",
	"perm.channelWho.any": "Quando qualquer pessoa permitida pedir",
	"perm.channelWho.verified": "Somente quando uma pessoa verificada pedir",
	"notify.label": "Enviar meus lembretes e resultados de execução para",
	"notify.none": "Para lugar nenhum",
	"notify.people": "Pessoas",
	"notify.channels": "Canais",
	"notify.saved": "{{id}} (ID salvo)",
	"notify.other": "Outro ID...",
	"notify.otherLabel": "ID do chat",
	"try.title": "Experimente",
	"try.help": "Escolha quem escreve, onde e o que pede. Isso executa a verificação que o host faz a cada mensagem, no formulário como está agora.",
	"try.noone": "Adicione uma pessoa primeiro. Depois você poderá testar o que ela pode fazer.",
	"try.whoLabel": "Quem",
	"try.placeLabel": "Onde",
	"try.actionLabel": "O que pedem",
	"try.someoneIn": "Alguém em {{channel}}",
	"try.anyone": "Qualquer pessoa",
	"try.role": "Alguém com a função {{role}}",
	"try.dm": "Mensagem direta",
	"try.where.dm": "em uma mensagem direta",
	"try.where.channel": "em {{channel}}",
	"try.is.paired": "{{who}} é uma pessoa verificada e escreve {{where}}.",
	"try.is.listed": "{{who}} é uma pessoa da lista e escreve {{where}}.",
	"try.is.channelActs": "Alguém em {{channel}}, onde todos podem pedir ações.",
	"try.is.channelAnswers": "Alguém em {{channel}}, onde as pessoas só recebem respostas.",
	"try.is.anyone": "Qualquer pessoa que possa enviar mensagem ao bot é aceita.",
	"try.is.role": "Uma pessoa com a função {{role}} é aceita.",
	"try.verdict.allowed": "Permitido.",
	"try.verdict.asks": "Permitido, mas pergunta antes.",
	"try.verdict.refused": "Recusado.",
	"try.loading": "Verificando...",
	"try.error": "A verificação não respondeu. Use Tentar de novo na tabela acima.",
	"try.unknown": "O host não deu resposta para este tipo de remetente.",
	"try.note": "Nada é enviado à plataforma e nada é salvo.",
	"refusals.title": "Recusas recentes",
	"refusals.help": "O que o bot recusou desde que o servidor iniciou, do mais recente ao mais antigo. Contém IDs, nomes e chats, nunca o texto das mensagens. Este registro fica só na memória: está vazio depois que o servidor reinicia.",
	"refusals.none": "Nada foi recusado desde que o servidor iniciou.",
	"refusals.refused": "recusado",
	"refusals.action": "pediu: {{action}}",
	"refusals.talk": "escreveu ao bot",
	"refusals.allow": "Permitir {{name}}",
	"refusals.act": "Permitir que membros de {{channel}} ajam",
	"perm.channelPickOther": "Outro: digitar um ID",
	"perm.channelHint.verified": "Execuções agendadas não podem postar aqui. Escolha \"Quando qualquer pessoa permitida pede\" para permitir.",
	"perm.channelHint.any": "Execuções agendadas podem postar aqui.",
	"perm.channelNoListen": "O bot não escuta neste canal, então só vai postar lá.",
	"who.post.none": "O bot não pode postar aqui.",
	"who.post.add": "Deixar o bot postar aqui também",
	"who.post.addFor": "Deixar o bot postar também em {{name}}",
	"who.post.verified": "Posta aqui só quando uma pessoa verificada pede.",
	"who.post.any": "Posta aqui quando qualquer pessoa permitida pede.",
	"who.post.show": "Mostrar o lugar",
	"who.post.showFor": "Mostrar o lugar de {{name}}",
	agentLink: "Abrir o agente {{name}}",
	"saved.created": "Conexão adicionada.",
	"saved.nothing": "Salvo. Nada mudou.",
	"saved.changed": "Salvo. Alterado: {{what}}.",
	"saved.part.name": "nome",
	"saved.part.agent": "agente",
	"saved.part.who": "quem ela aceita",
	"saved.part.permissions": "permissões",
	"saved.part.approval": "aprovação e ações dos gatilhos",
	"saved.part.files": "configurações de arquivos",
	"saved.part.notify": "notificações",
	"saved.dropped.title": "Esta conexão não permite mais estas ações, então as execuções destes gatilhos as perdem:",
	"saved.dropped.item": "{{name}}: {{acts}}",
	"conn.state.running": "Em execução",
	"conn.state.off": "Desligada",
	"conn.state.attention": "Precisa de atenção",
	"conn.state.ready": "Pronta",
	"conn.row.open": "{{name}}: {{state}}. Mostrar detalhes",
	"conn.row.menu": "Mais ações para {{name}}",
	"conn.row.testNamed": "Testar {{name}}",
	"conn.fix.token": "Corrigir o token",
	"conn.reason.noToken": "Nenhum token salvo.",
	"conn.reason.duplicate": "Responde com o mesmo bot que {{name}}.",
	"conn.reason.testFailed": "O último teste falhou: {{reason}}",
	"conn.kv.service": "Serviço",
	"conn.kv.accepts": "Aceita",
	"conn.kv.replies": "Respostas",
	"conn.kv.token": "Token",
	"conn.kv.saved": "Salvo",
	"conn.kv.notSaved": "Não salvo",
	"conn.kv.agents": "Agentes",
	"usedBy.count_one": "Usada por {{count}} agente",
	"usedBy.count_other": "Usada por {{count}} agentes",
	"usedBy.none": "Nenhum agente a usa",
	"conn.pane.lastTest": "Último teste",
	"conn.pane.never": "Ainda não testada neste navegador.",
	"conn.pane.passed": "Passou {{when}}.",
	"conn.pane.failed": "Falhou {{when}}.",
	"conn.pane.connection": "Conexão",
	"conn.pane.remove": "Remover",
	"conn.pane.test": "Testar a conexão",
	"conn.pane.testing": "Testando...",
	"conn.sheet.addDesc": "Dê um nome, adicione o token e escolha o agente que responde.",
	"conn.sheet.editDesc": "As alterações valem ao salvar. Um token salvo nunca é mostrado de novo.",
	"conn.sheet.connection": "Conexão",
	"conn.sheet.who": "Quem pode falar com ela",
	"conn.sheet.may": "O que ela pode fazer",
	"conn.sheet.replies": "Respostas, arquivos e locais",
	"conn.sheet.check": "Verificar o que ela fará",
	"conn.sheet.saveAndTest": "Salvar e testar",
	"conn.sheet.saving": "Salvando...",
	"conn.sheet.testFailed": "A conexão foi salva, mas o teste falhou.",
	"conn.sheet.testFailedNoReason": "Nenhum motivo foi informado.",
	"conn.sheet.testAgain": "Testar de novo",
	"conn.sheet.close": "Fechar",
	"conn.sheet.agentFixed": "Responde com o agente {{name}}",
	"conn.preset.label": "Permissões",
	"conn.preset.answer": "Só responder",
	"conn.preset.answerHelp": "Responde às mensagens. Esta conexão não adiciona nenhuma permissão própria.",
	"conn.preset.standard": "Padrão",
	"conn.preset.standardHelp": "O conjunto usual que o agente tem: {{list}}.",
	"conn.preset.standardNone": "O conjunto usual. Este agente não tem nenhuma.",
	"conn.preset.custom": "Personalizado",
	"conn.preset.customHelp": "Escolha cada permissão e quem pode usá-la.",
	"conn.preset.note": "Uma predefinição nunca ativa uma permissão sensível. Use Personalizado para essas. As conexões de complementos que o agente tem possuem regras próprias: pessoas verificadas ainda podem usar suas ferramentas de escrita. Altere isso no agente, em \"O que pode usar\".",
	"conn.discard.title": "Descartar as alterações?",
	"conn.discard.message": "Você alterou esta conexão e não salvou.",
	"conn.discard.confirm": "Descartar alterações",
	"share.label": "Compartilhar",
	"share.button": "Compartilhar {{name}}",
	"share.intro": "As pessoas que você adicionar podem usar esta conexão nos próprios chats e agentes. Elas veem o nome e o estado, nunca o token nem as configurações. As mensagens para o bot continuam chegando ao seu agente.",
	"share.roleUse": "Pode usar",
	"share.roleUseHelp": "Pode usá-la nos próprios chats e agentes. Não pode ver o token, alterá-la nem compartilhá-la.",
	"shared.title": "Compartilhadas com você",
	"shared.text": "Outras pessoas deixam você usar estas conexões nos seus chats e agentes. Só o dono pode alterá-las.",
	"shared.on": "Ouvindo",
	"shared.off": "Desligada",
	"shared.by": "Compartilhada por {{name}}",
	loginNeedsHost: "Esta versão do LocalAI não consegue fazer login a partir desta página. Atualize o LocalAI para conectar aqui."
};

//#endregion
//#region addons/internal/connector-ui/src/i18n/index.js
function registerConnectorLocales() {
	registerLocales({ connector: connectorLocales });
}
function registerAddonLocales(ns, byLanguage) {
	registerLocales({ [ns]: byLanguage });
}
var connectorLocales;
var init_i18n = __esmMin((() => {
	init_i18n$1();
	connectorLocales = {
		en: connector_en_default,
		it: connector_it_default,
		es: connector_es_default,
		de: connector_de_default,
		fr: connector_fr_default,
		"zh-CN": connector_zh_CN_default,
		id: connector_id_default,
		ko: connector_ko_default,
		tr: connector_tr_default,
		"pt-BR": connector_pt_BR_default
	};
}));

//#endregion
//#region addons/internal/connector-ui/src/ConnectorPage.jsx
function sdkOrNull() {
	try {
		return getSdk();
	} catch {
		return null;
	}
}
function Senders({ id, onAllowed, t }) {
	const [list, setList] = useState$1(null);
	const [error, setError] = useState$1("");
	const load = useCallback(() => {
		connectorsApi.senders(id).then((r) => setList(r.senders || [])).catch((e) => setError(e?.message || ""));
	}, [id]);
	useEffect$1(() => {
		load();
	}, [load]);
	if (error) return /* @__PURE__ */ jsx(Notice, {
		tone: "error",
		role: "alert",
		children: error
	});
	if (list === null) return null;
	if (list.length === 0) return /* @__PURE__ */ jsx("p", {
		className: "cn-muted",
		children: t("noSenders")
	});
	return /* @__PURE__ */ jsx("ul", {
		className: "cn-runs",
		"aria-label": t("senders"),
		"data-testid": "sender-log",
		children: list.map((s) => /* @__PURE__ */ jsxs("li", { children: [
			/* @__PURE__ */ jsx("span", {
				className: `cn-status cn-status--${s.allowed ? "done" : "skipped"}`,
				children: s.allowed ? t("accepted") : t("ignored")
			}),
			/* @__PURE__ */ jsx("span", { children: senderLine(s, answerT(t)) }),
			s.chat && /* @__PURE__ */ jsx("span", {
				className: "cn-muted",
				children: answerT(t)("sender.chat", { chat: chatText(s.chat, s.chat_name) })
			}),
			!s.allowed && s.reason && /* @__PURE__ */ jsx("span", {
				className: "cn-muted",
				"data-testid": "sender-reason",
				"data-code": s.reason,
				children: answerT(t)(`sender.reason.${s.reason}`, { defaultValue: s.reason })
			}),
			!s.allowed && /* @__PURE__ */ jsx("button", {
				type: "button",
				className: "dk-btn dk-btn--secondary dk-btn--sm",
				onClick: async () => {
					setError("");
					try {
						await connectorsApi.allow(id, s.id);
						load();
						onAllowed();
					} catch (e) {
						setError(e?.message || "");
					}
				},
				children: t("allowButton")
			})
		] }, s.id))
	});
}
function SingleToken({ form, setForm, t }) {
	return /* @__PURE__ */ jsx(Field, {
		label: t("token"),
		hint: t("tokenHelp"),
		children: (p) => /* @__PURE__ */ jsx(TextInput, {
			...p,
			mono: true,
			type: "password",
			autoComplete: "off",
			value: form.token || "",
			required: !form.id,
			placeholder: form.id ? t("tokenSaved") : "",
			onChange: (e) => setForm({
				...form,
				token: e.target.value
			})
		})
	});
}
function SameBotNotice({ c, s, busy, onOff, onOpen }) {
	const other = duplicateOther(c);
	if (!other) return null;
	return /* @__PURE__ */ jsxs(Notice, {
		tone: "warn",
		role: "status",
		testId: "duplicate-warning",
		children: [/* @__PURE__ */ jsx("p", {
			className: "cn-notice__text",
			children: s("dup.text", { name: other.name })
		}), /* @__PURE__ */ jsxs("span", {
			className: "cn-row__actions",
			children: [/* @__PURE__ */ jsx("button", {
				type: "button",
				className: "dk-btn dk-btn--secondary dk-btn--sm",
				disabled: busy,
				onClick: onOff,
				children: s("dup.turnOff")
			}), /* @__PURE__ */ jsx("button", {
				type: "button",
				className: "cn-link cn-link--text",
				"data-testid": "duplicate-open",
				onClick: () => onOpen(other.id),
				children: s("dup.openOther", { name: other.name })
			})]
		})]
	});
}
function SaveNotice({ notice, s }) {
	const { created, parts, dropped } = notice;
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(Notice, {
		tone: "ok",
		role: "status",
		testId: "connector-saved",
		children: created ? s("saved.created") : parts.length === 0 ? s("saved.nothing") : s("saved.changed", { what: parts.map((p) => s(`saved.part.${p}`)).join(", ") })
	}), dropped.length > 0 && /* @__PURE__ */ jsxs(Notice, {
		tone: "warn",
		role: "status",
		testId: "connector-acts-dropped",
		children: [/* @__PURE__ */ jsx("p", {
			className: "cn-notice__text",
			children: s("saved.dropped.title")
		}), /* @__PURE__ */ jsx("ul", { children: dropped.map((d) => /* @__PURE__ */ jsx("li", {
			"data-testid": "connector-acts-dropped-item",
			children: s("saved.dropped.item", {
				name: d.name,
				acts: d.acts.map((n) => s(`approval.actShort.${n}`)).join(", ")
			})
		}, d.id)) })]
	})] });
}
function SharedConnections({ rows, s }) {
	const Badge = sdkOrNull()?.ui?.SharedByBadge;
	return /* @__PURE__ */ jsxs("section", {
		className: "cn-shared",
		"aria-labelledby": "cn-shared-title",
		"data-testid": "connector-shared",
		children: [
			/* @__PURE__ */ jsx("h2", {
				className: "cn-section__title",
				id: "cn-shared-title",
				children: s("shared.title")
			}),
			/* @__PURE__ */ jsx("p", {
				className: "cn-muted",
				children: s("shared.text")
			}),
			/* @__PURE__ */ jsx("ul", {
				className: "cn-conns",
				children: rows.map((c) => /* @__PURE__ */ jsx("li", {
					className: "cn-conn",
					"data-testid": "connector-shared-row",
					"data-state": c.enabled ? "running" : "off",
					children: /* @__PURE__ */ jsxs("div", {
						className: "cn-conn__body",
						children: [/* @__PURE__ */ jsx(Tile, { c }), /* @__PURE__ */ jsxs("span", {
							className: "cn-conn__text",
							children: [
								/* @__PURE__ */ jsx("span", {
									className: "cn-conn__name",
									children: c.name
								}),
								/* @__PURE__ */ jsx("span", {
									className: "cn-conn__facts",
									children: c.enabled ? s("shared.on") : s("shared.off")
								}),
								Badge ? /* @__PURE__ */ jsx(Badge, {
									entry: {
										role: c.role,
										owner: c.owner,
										everyone: false
									},
									roleLabel: s("share.roleUse")
								}) : /* @__PURE__ */ jsx("span", {
									className: "cn-muted",
									children: s("shared.by", { name: c.owner || "" })
								})
							]
						})]
					})
				}, c.id))
			})
		]
	});
}
function ShareConnection({ share, s, onChanged, close }) {
	const Dialog = sdkOrNull()?.ui?.ConnectionShareDialog;
	if (!Dialog) return null;
	return /* @__PURE__ */ jsx(Dialog, {
		binding: share.binding,
		name: share.name,
		roleLabel: s("share.roleUse"),
		roleHelp: s("share.roleUseHelp"),
		intro: s("share.intro"),
		onChanged,
		onLost: () => {
			close();
			onChanged();
		},
		close,
		testId: "connector-share-dialog"
	});
}
/**
* @param {object} props
* @param {string} props.kind          the kind of the bindings, such as telegram
* @param {string} props.ns            the i18n namespace of the add-on
* @param {string} props.testId        the test id of the page
* @param {Function} [props.TokenFields] the fields of the token ({ form, setForm, t })
* @param {Function} [props.tokenOf]   the secret that the fields make, '' when not typed
* @param {Array} [props.lists]        the allowlists: { key, hint, help, testId, match }
* @param {Function} [props.Help]      a block under the intro ({ t })
* @param {string} [props.notifyMode]  the inputMode of the notification field
* @param {Function} [props.isChannelEntry] whether an allowlist entry names a channel or group: (entry) => boolean.
*                                     The kind knows its IDs: the page puts such an entry in the table of channels.
* @param {boolean} [props.mixedList]  a kind that cannot tell a person from a channel by its ID keeps one list of people
*                                     and channels, with the level of a channel on every entry
* @param {boolean} [props.messaging]  false for a kind that carries no messages: the page then hides the sender,
*                                     reply, file and notification settings and the switch of the binding
* @param {Function} [props.ExtraFields] more fields of the add-on's own ({ form, setForm, t })
* @param {Function} [props.extraBody] the request fields they make: (form) => object
* @param {Function} [props.extraForm] their values from a saved binding: (binding) => object
* @param {Function} [props.extraValid] whether they allow saving: (form) => boolean
* @param {Function} [props.needsSaveStep] whether Save must first run the add-on's own step: (form) => boolean
* @param {Function} [props.SaveStep]  that step, drawn over the sheet ({ form, t, onProceed, onCancel }). onProceed(patch)
*                                     adds the fields of the patch to the form and saves it; onCancel saves nothing
* @param {Function} [props.testExtra] more checks after the Test button: async (binding, t) => string
* @param {Function} [props.RowInfo]   a line under a binding in the list ({ c, t })
* @param {boolean} [props.canAdd]     false for a kind whose connections are made elsewhere: the page then edits
*                                     the saved ones and has no New button
* @param {boolean} [props.login]      a kind whose add-on logs in with OAuth: the page draws the host's login
*                                     (sdk.ui.ConnectionLogin) in place of the New button and its token sheet.
*                                     The add-on's text has `connect` (the button) and `defaultName`
*/
function ConnectorPage({ kind, ns, testId, TokenFields = SingleToken, tokenOf = (f) => f.token || "", lists = ONE_LIST, Help, notifyMode = "text", messaging: messagingProp = true, isChannelEntry: channelPredicate, mixedList = false, ExtraFields, extraBody, extraForm, extraValid, needsSaveStep, SaveStep, testExtra, RowInfo, canAdd = true, login = false }) {
	const { t, i18n } = useTranslation([ns, "connector"]);
	const uiLanguage = i18n?.resolvedLanguage || i18n?.language || "";
	setApiLanguage(uiLanguage);
	const [items, setItems] = useState$1([]);
	const [shared, setShared] = useState$1([]);
	const [canShare, setCanShare] = useState$1(false);
	const [share, setShare] = useState$1(null);
	const [agents, setAgents] = useState$1([]);
	const [agentsReady, setAgentsReady] = useState$1(false);
	const [off, setOff] = useState$1("");
	const [error, setError] = useState$1("");
	const [note, setNote] = useState$1("");
	const [saveNotice, setSaveNotice] = useState$1(null);
	const [form, setForm] = useState$1(null);
	const [fixedAgent, setFixedAgent] = useState$1(false);
	const [focusToken, setFocusToken] = useState$1(0);
	const [deepPermissions, setDeepPermissions] = useState$1(false);
	const [presetChoice, setPresetChoice] = useState$1(null);
	const [formError, setFormError] = useState$1("");
	const [askDiscard, setAskDiscard] = useState$1(false);
	const [confirmed, setConfirmed] = useState$1(false);
	const [busy, setBusy] = useState$1(false);
	const [testStep, setTestStep] = useState$1(false);
	const [testFail, setTestFail] = useState$1(null);
	const [toDelete, setToDelete] = useState$1(null);
	const [dupAsk, setDupAsk] = useState$1(null);
	const [saveStepOpen, setSaveStepOpen] = useState$1(false);
	const [detailId, setDetailId] = useState$1("");
	const [rowBusy, setRowBusy] = useState$1({});
	const [testing, setTesting] = useState$1({});
	const [kindInfo, setKindInfo] = useState$1(null);
	const [kindsReady, setKindsReady] = useState$1(false);
	const [capabilities, setCapabilities] = useState$1([]);
	const [accessVersion, setAccessVersion] = useState$1(0);
	const [directory, setDirectory] = useState$1(() => /* @__PURE__ */ new Map());
	const [senderLog, setSenderLog] = useState$1([]);
	const [checks, setChecks] = useState$1(() => readChecks());
	const [pairedList, setPairedList] = useState$1(null);
	const startPrint = useRef("");
	const formRef = useRef(null);
	formRef.current = form;
	const openerRef = useRef(null);
	const kindFiles = kindInfo?.files || null;
	const agentOptional = Boolean(kindInfo?.agent_optional);
	const toolOnly = Boolean(kindInfo?.tool_only);
	const messaging = messagingProp && !toolOnly;
	const plan = loginPlan({
		login,
		canAdd,
		sdk: sdkOrNull(),
		kindInfo,
		kindsReady
	});
	const sheetAdd = plan.sheetAdd;
	const s = answerT(t);
	const isChannelEntry = channelPredicate || ((x) => lists.length > 1 && listEntries([x], lists, lists.length - 1).length === 1);
	const pairedChanged = useCallback((list) => {
		if (Array.isArray(list)) setPairedList(list);
		setAccessVersion((v) => v + 1);
	}, []);
	const isAdmin = useIsAdmin(useAuth);
	const Login = login ? sdkOrNull()?.ui?.ConnectionLogin : null;
	const fail = useCallback((e) => {
		if (e?.status === 409 && e.body?.error?.type === "connectors_off") {
			setOff(e.body.error.message);
			return;
		}
		setError(e?.message || "");
	}, []);
	const load = useCallback(async () => {
		try {
			const res = await connectorsApi.list();
			const list = (res.connectors || []).filter((c) => c.kind === kind);
			setItems(list);
			setShared(sharedOfKind(res, kind));
			setCanShare(shareAvailable(sdkOrNull(), res));
			setOff("");
			return list;
		} catch (e) {
			fail(e);
			return null;
		}
	}, [fail, kind]);
	useEffect$1(() => {
		load();
	}, [load]);
	const shareOf = canShare ? (c) => {
		setError("");
		setShare({
			binding: c.id,
			name: c.name
		});
	} : void 0;
	useEffect$1(() => {
		connectorsApi.kinds().then((r) => {
			setKindInfo((r.kinds || []).find((k) => k.kind === kind) || null);
			setCapabilities(r.capabilities || []);
		}).catch(() => {}).finally(() => setKindsReady(true));
	}, [kind, uiLanguage]);
	const languageSeen = useRef(uiLanguage);
	useEffect$1(() => {
		if (languageSeen.current === uiLanguage) return;
		languageSeen.current = uiLanguage;
		setAccessVersion((v) => v + 1);
	}, [uiLanguage]);
	useEffect$1(() => {
		agentsApi.list().then((r) => setAgents(r.agents || [])).catch(() => {}).finally(() => setAgentsReady(true));
	}, []);
	const agentOf = (id) => agents.find((a) => a.id === id);
	const agentName = (id) => agentOf(id)?.name || id;
	const extra = (f) => ({
		...messaging ? {} : {
			enabled: false,
			accept_any: false
		},
		...extraBody ? extraBody(f) : {}
	});
	const savedFormOf = (c) => ({
		...connectorForm(c),
		...extraForm ? extraForm(c) : {}
	});
	const printOf = (f) => JSON.stringify(connectorPayload(f, kind, tokenOf(f).trim(), extra(f)));
	const withAgent = (f, agentId) => {
		if (toolOnly) return f;
		const standard = presetChoice ? presetChoice === "standard" : presetOf(f, capabilities, agentOf(f.agent_id)) === "standard";
		const next = {
			...f,
			agent_id: agentId
		};
		return standard && capabilities.length > 0 ? applyPreset(next, "standard", capabilities, agentOf(agentId)) : next;
	};
	const openForm = (f, opts = {}) => {
		openerRef.current = opts.opener || document.activeElement;
		setForm(f);
		startPrint.current = printOf(f);
		setConfirmed(Boolean(f.accept_any));
		setNote("");
		setError("");
		setFormError("");
		setTestFail(null);
		setTestStep(false);
		setSaveNotice(null);
		setPairedList(null);
		setDupAsk(null);
		setSaveStepOpen(false);
		setAskDiscard(false);
		setFixedAgent(Boolean(opts.fixedAgent));
		setPresetChoice(opts.preset || null);
		setDeepPermissions(Boolean(opts.permissions));
		setFocusToken(opts.focusToken ? Date.now() : 0);
	};
	const openNew = (agentId = "") => {
		const picked = agentId && !toolOnly ? agents.find((a) => a.id === agentId && a.model) : null;
		const held = agentHeld(picked || (!toolOnly && agents.length === 1 ? agents[0] : null));
		const f = {
			...emptyConnector(seedCapabilities(capabilities, {
				toolOnly,
				agentOptional,
				agentPicked: Boolean(picked)
			}), held),
			...extraForm ? extraForm({}) : {}
		};
		openForm(picked ? {
			...f,
			agent_id: picked.id
		} : f, { fixedAgent: Boolean(picked) });
	};
	const openEdit = (c, opts) => openForm(savedFormOf(c), opts);
	const editFromRow = (c, trigger) => openEdit(c, { opener: trigger instanceof HTMLElement ? trigger : null });
	const openById = (id) => {
		const c = items.find((x) => x.id === id);
		if (c) openEdit(c);
	};
	const linked = useRef(false);
	useEffect$1(() => {
		if (linked.current || !kindsReady) return;
		const q = new URLSearchParams(window.location.search);
		if (sheetAdd && q.get("new") === "1") {
			if (!agentsReady) return;
			linked.current = true;
			openNew(q.get("agent") || "");
			return;
		}
		const id = q.get("binding");
		if (!id) {
			linked.current = true;
			return;
		}
		const c = items.find((x) => x.id === id);
		if (!c) return;
		linked.current = true;
		openEdit(c, {
			permissions: true,
			preset: capabilities.length > 0 && messaging ? "custom" : null
		});
	}, [
		items,
		kindsReady,
		agentsReady
	]);
	const openId = form?.id || "";
	useEffect$1(() => {
		if (!openId || !messaging) {
			setDirectory(/* @__PURE__ */ new Map());
			setSenderLog([]);
			return;
		}
		let live = true;
		connectorsApi.senders(openId).then((r) => {
			if (live) {
				setDirectory(peopleFrom(r?.senders));
				setSenderLog(r?.senders || []);
			}
		}).catch(() => {
			if (live) {
				setDirectory(/* @__PURE__ */ new Map());
				setSenderLog([]);
			}
		});
		return () => {
			live = false;
		};
	}, [
		openId,
		messaging,
		accessVersion
	]);
	useEffect$1(() => {
		if (dupAsk) document.querySelector("[data-testid=\"duplicate-confirm\"]")?.scrollIntoView?.({ block: "nearest" });
	}, [dupAsk]);
	const remember = (id, record) => {
		setChecks((m) => {
			const next = {
				...m,
				[id]: record
			};
			writeChecks(next);
			return next;
		});
	};
	const check = async (c) => {
		try {
			let text = t("testOk", { bot: (await connectorsApi.test(c.id)).bot_username });
			if (testExtra) text += ` ${await testExtra(c, t)}`;
			remember(c.id, checkRecord({
				ok: true,
				text
			}));
			return text;
		} catch (e) {
			remember(c.id, checkRecord({
				ok: false,
				reason: e?.message || ""
			}));
			throw e;
		}
	};
	const runTest = async (c) => {
		setError("");
		setTesting((m) => ({
			...m,
			[c.id]: true
		}));
		try {
			setNote(await check(c));
		} catch (e) {
			fail(e);
		} finally {
			setTesting((m) => ({
				...m,
				[c.id]: false
			}));
		}
	};
	const testInSheet = async (c, fresh = null) => {
		setTestStep(true);
		setTesting((m) => ({
			...m,
			[c.id]: true
		}));
		try {
			const text = await check(c);
			setTestFail(null);
			setNote(text);
			setForm(null);
		} catch (err) {
			const reason = err?.message || "";
			if (formRef.current) {
				const next = fresh ? savedFormOf(fresh) : {
					...formRef.current,
					id: c.id
				};
				startPrint.current = printOf(next);
				setForm(next);
				setTestFail({ reason });
			} else setError(t("checkFailed", { reason }));
		} finally {
			setTesting((m) => ({
				...m,
				[c.id]: false
			}));
			setTestStep(false);
		}
	};
	const testAgain = async () => {
		const c = items.find((x) => x.id === form?.id);
		if (!c) return;
		setBusy(true);
		try {
			await testInSheet(c);
		} finally {
			setBusy(false);
		}
	};
	const save = (e) => {
		e.preventDefault();
		if (needsSaveStep?.(form)) {
			setSaveStepOpen(true);
			return;
		}
		return doSave(false);
	};
	const proceedSaveStep = (patch) => {
		setSaveStepOpen(false);
		const next = {
			...form,
			...patch
		};
		setForm(next);
		return doSave(false, next);
	};
	const doSave = async (confirmDuplicate, f = form) => {
		setBusy(true);
		setFormError("");
		setTestFail(null);
		setNote("");
		setError("");
		setSaveNotice(null);
		setDupAsk(null);
		try {
			const body = connectorPayload(f, kind, tokenOf(f).trim(), {
				...extra(f),
				...confirmDuplicate ? { confirm_duplicate: DUPLICATE_CONFIRMATION } : {}
			});
			const before = f.id ? savedForm : null;
			const removed = removedActs(before, f);
			const saved = f.id ? await connectorsApi.update(f.id, body) : await connectorsApi.create(body);
			const wasNew = !f.id;
			const snapshot = f;
			const list = await load();
			const dropped = snapshot.id && removed.length > 0 ? droppedActs((await triggersApi.list().catch(() => null))?.triggers, snapshot.id, removed) : [];
			setSaveNotice({
				created: wasNew,
				parts: changedParts(snapshot, before),
				dropped
			});
			if (saved?.id) await testInSheet(saved, list?.find((x) => x.id === saved.id) || null);
			else setForm(null);
		} catch (err) {
			if (isDuplicateRefusal(err)) setDupAsk({ other: duplicateRefusalName(err) });
			else setFormError(err?.message || "");
			if (err?.status === 409 && err.body?.error?.type === "connectors_off") {
				setForm(null);
				fail(err);
			}
		} finally {
			setBusy(false);
		}
	};
	const act = async (fn) => {
		setError("");
		try {
			await fn();
			await load();
		} catch (e) {
			fail(e);
		}
	};
	const toggle = async (c, on) => {
		setRowBusy((m) => ({
			...m,
			[c.id]: true
		}));
		setItems((list) => list.map((x) => x.id === c.id ? {
			...x,
			enabled: on
		} : x));
		await act(() => on ? connectorsApi.enable(c.id) : connectorsApi.disable(c.id));
		setRowBusy((m) => ({
			...m,
			[c.id]: false
		}));
	};
	const fixRow = (c, what) => {
		if (what === "token") openEdit(c, { focusToken: true });
		else if (what === "duplicate") act(() => connectorsApi.disable(c.id));
	};
	const wasOpen = useRef(false);
	useEffect$1(() => {
		if (wasOpen.current && !form) {
			const el = openerRef.current;
			if (el && el.isConnected) requestAnimationFrame(() => el.focus?.());
		}
		wasOpen.current = Boolean(form);
	}, [form]);
	const savedItem = form?.id ? items.find((x) => x.id === form.id) : null;
	const savedForm = savedItem ? savedFormOf(savedItem) : null;
	const changed = form ? printOf(form) !== startPrint.current : false;
	const closeSheet = () => {
		if (changed) setAskDiscard(true);
		else setForm(null);
	};
	const preview = useAccessPreview({
		form,
		kind,
		enabled: Boolean(form) && messaging && capabilities.length > 0,
		version: accessVersion
	});
	const tokenTyped = form ? Boolean(tokenOf(form).trim()) : false;
	const dirty = form ? !savedForm || tokenTyped || JSON.stringify(connectorPayload(form, kind, "", extra(form))) !== JSON.stringify(connectorPayload(savedForm, kind, "", extra(savedForm))) : false;
	const people = form ? lists.length > 1 ? listEntries(form.allow, lists, 0).length : (form.allow || []).length : 0;
	const fixCtx = {
		agentId: form?.agent_id || "",
		isAdmin,
		lists,
		form: form || {},
		people
	};
	const tokenCheck = form?.id && checks[form.id] ? {
		ok: checks[form.id].ok,
		bot: checks[form.id].text,
		reason: checks[form.id].reason
	} : null;
	const readyInput = form && {
		form,
		saved: savedForm,
		kindInfo,
		capabilities,
		agents,
		lists,
		tokenTyped,
		token: tokenCheck,
		preview,
		paired: pairedList || form.paired || [],
		agentOptional,
		toolOnly,
		messaging,
		isChannel: isChannelEntry
	};
	const preset = form ? presetChoice || presetOf(form, capabilities, agentOf(form.agent_id)) : "answer";
	if (off) return /* @__PURE__ */ jsxs("div", {
		className: "cn-page",
		"data-testid": testId,
		children: [/* @__PURE__ */ jsx("h1", {
			className: "cn-title",
			children: t("title")
		}), /* @__PURE__ */ jsx(Notice, {
			tone: "info",
			role: "note",
			children: off
		})]
	});
	const kindTitle = kindInfo?.title || kind;
	const whoText = (c) => c.accept_any ? t("modes.anyone") : (c.allow || []).length === 0 ? t("modes.nobody") : t("modes.listed", { count: c.allow.length });
	const usedByText = (c) => c.used_by > 0 ? s("usedBy.count", { count: c.used_by }) : s("usedBy.none");
	const agentText = (c) => toolOnly ? typeof c.used_by === "number" ? usedByText(c) : "" : c.credentials_only ? s("credentialsOnly") : t("agentOf", { name: agentName(c.agent_id) });
	const factsOf = (c) => [
		kindTitle,
		agentText(c),
		...messaging && !c.credentials_only ? [t("accepts", { who: whoText(c) })] : []
	].filter(Boolean).join(" · ");
	const reasonOf = (a) => {
		if (!a) return "";
		if (a.cause === "inactive") return t("inactive", { reason: a.reason });
		if (a.cause === "noToken") return s("conn.reason.noToken");
		if (a.cause === "duplicate") return s("conn.reason.duplicate", { name: a.reason });
		return s("conn.reason.testFailed", { reason: a.reason });
	};
	const fixLabel = (what) => what === "token" ? s("conn.fix.token") : s("dup.turnOff");
	const viewOf = (c) => {
		const { state, attention } = connectionState(c, checks[c.id], { messaging });
		const kindOfFix = fixOf(attention);
		return {
			state,
			attention,
			fix: kindOfFix ? {
				kind: kindOfFix,
				label: fixLabel(kindOfFix)
			} : null
		};
	};
	const detail = items.find((x) => x.id === detailId) || null;
	const paneFacts = (c) => [
		[s("conn.kv.service"), kindTitle],
		...toolOnly ? typeof c.used_by === "number" ? [[s("conn.kv.agents"), /* @__PURE__ */ jsx("span", {
			"data-testid": "connector-used-by",
			children: usedByText(c)
		}, "u")]] : [] : [[t("agent"), c.credentials_only ? s("credentialsOnly") : agentName(c.agent_id)]],
		...messaging && !c.credentials_only ? [[s("conn.kv.accepts"), whoText(c)], [s("conn.kv.replies"), /* @__PURE__ */ jsx("span", {
			"data-testid": "connector-answer-summary",
			children: answerSummary(c, t)
		}, "r")]] : [],
		[s("conn.kv.token"), c.has_token ? s("conn.kv.saved") : s("conn.kv.notSaved")]
	];
	const dupNode = dupAsk && /* @__PURE__ */ jsxs(Notice, {
		tone: "warn",
		role: "alert",
		testId: "duplicate-confirm",
		children: [
			/* @__PURE__ */ jsx("p", {
				className: "cn-notice__text",
				children: s("dup.text", { name: dupAsk.other })
			}),
			/* @__PURE__ */ jsx("p", {
				className: "cn-notice__text",
				children: s("dup.confirmHelp")
			}),
			/* @__PURE__ */ jsxs("span", {
				className: "cn-row__actions",
				children: [/* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--primary dk-btn--sm",
					"data-testid": "duplicate-save-anyway",
					disabled: busy,
					onClick: () => doSave(true),
					children: s("dup.saveAnyway")
				}), /* @__PURE__ */ jsx("button", {
					type: "button",
					className: "dk-btn dk-btn--secondary dk-btn--sm",
					onClick: () => setDupAsk(null),
					children: s("dup.goBack")
				})]
			})
		]
	});
	const sheetProps = form && {
		t,
		s,
		form,
		setForm,
		messaging,
		capabilities,
		kindInfo,
		kindFiles,
		agents,
		agentOptional,
		toolOnly,
		TokenFields,
		ExtraFields,
		savedItem,
		busy,
		error: formError,
		fixedAgent,
		testStep,
		testFail,
		onTestAgain: testAgain,
		onSubmit: save,
		onClose: closeSheet,
		canSubmit: canSave(form, confirmed, tokenTyped, kindFiles, agentOptional) && !(extraValid && !extraValid(form)),
		agentName,
		toolOnly,
		agentHref: savedItem && !toolOnly ? `${basePath}/app/agents/${encodeURIComponent(savedItem.agent_id)}` : "",
		dirty,
		sameBot: messaging && form.id && savedItem ? /* @__PURE__ */ jsx(SameBotNotice, {
			c: savedItem,
			s,
			busy,
			onOff: () => {
				setForm(null);
				act(() => connectorsApi.disable(form.id));
			},
			onOpen: openById
		}) : null,
		fixCtx,
		readyInput,
		withAgent,
		preset,
		setPreset: setPresetChoice,
		confirmed,
		setConfirmed,
		isChannelEntry,
		mixedList,
		pairedChanged,
		pairedList,
		senderLog,
		lists,
		preview,
		accessVersion,
		notifyMode,
		onAllowed: (sender) => {
			setForm((f) => f && !(f.allow || []).includes(sender) ? {
				...f,
				allow: [...f.allow || [], sender]
			} : f);
			setAccessVersion((v) => v + 1);
			load();
		},
		dupAsk: dupNode,
		focusToken,
		scrollToPermissions: deepPermissions,
		openCheck: deepPermissions
	};
	return /* @__PURE__ */ jsx(HintLabels.Provider, {
		value: {
			more: s("more"),
			less: s("less"),
			optional: s("optional")
		},
		children: /* @__PURE__ */ jsx(PeopleContext.Provider, {
			value: directory,
			children: /* @__PURE__ */ jsxs("div", {
				className: "cn-page",
				"data-testid": testId,
				children: [
					/* @__PURE__ */ jsxs("header", {
						className: "cn-head",
						children: [/* @__PURE__ */ jsx("h1", {
							className: "cn-title",
							children: t("title")
						}), sheetAdd && /* @__PURE__ */ jsxs("button", {
							type: "button",
							className: "dk-btn dk-btn--primary",
							"data-testid": "connector-new",
							disabled: !kindsReady,
							onClick: () => openNew(),
							children: [
								/* @__PURE__ */ jsx(Icon, { name: "plus" }),
								" ",
								t("new")
							]
						})]
					}),
					/* @__PURE__ */ jsx("p", {
						className: "cn-muted",
						children: t("intro")
					}),
					Help && /* @__PURE__ */ jsx(Help, { t }),
					plan.show === "host" && /* @__PURE__ */ jsx(Login, {
						kind: kindInfo,
						bindings: items,
						onChanged: load,
						connectLabel: t("connect"),
						defaultName: t("defaultName")
					}),
					plan.show === "oldHost" && /* @__PURE__ */ jsx("p", {
						className: "cn-muted",
						"data-testid": "login-needs-host",
						children: t("connector:loginNeedsHost")
					}),
					error && /* @__PURE__ */ jsxs(Notice, {
						tone: "error",
						role: "alert",
						children: [/* @__PURE__ */ jsx("span", { children: error }), /* @__PURE__ */ jsx("button", {
							type: "button",
							className: "cn-link",
							"aria-label": answerT(t)("dismiss"),
							onClick: () => setError(""),
							children: "×"
						})]
					}),
					saveNotice && /* @__PURE__ */ jsx(SaveNotice, {
						notice: saveNotice,
						s
					}),
					note && /* @__PURE__ */ jsx(Notice, {
						tone: "ok",
						role: "status",
						children: note
					}),
					/* @__PURE__ */ jsxs(PaneLayout, {
						className: "cn-layout",
						children: [/* @__PURE__ */ jsxs("div", {
							className: "cn-listcol",
							children: [/* @__PURE__ */ jsx("ul", {
								className: "cn-conns",
								"aria-label": t("title"),
								children: items.map((c) => {
									const v = viewOf(c);
									return /* @__PURE__ */ jsx(ConnectionRow, {
										c,
										state: v.state,
										attention: v.attention,
										fix: v.fix,
										facts: factsOf(c),
										line: v.attention ? {
											text: reasonOf(v.attention),
											testId: v.attention.cause === "inactive" ? "connector-inactive" : "connector-attention"
										} : null,
										selected: c.id === detailId,
										testing: Boolean(testing[c.id]),
										busy: Boolean(rowBusy[c.id]),
										messaging,
										t,
										s,
										onOpen: setDetailId,
										onToggle: toggle,
										onTest: runTest,
										onFix: fixRow,
										onEdit: editFromRow,
										onDelete: setToDelete,
										onShare: shareOf
									}, c.id);
								})
							}), items.length === 0 && !form && /* @__PURE__ */ jsx("p", {
								className: "cn-muted",
								children: t("empty")
							})]
						}), detail && (() => {
							const v = viewOf(detail);
							return /* @__PURE__ */ jsx(ConnectionPane, {
								c: detail,
								state: v.state,
								attention: v.attention,
								fix: v.fix,
								check: checks[detail.id],
								testing: Boolean(testing[detail.id]),
								busy: Boolean(rowBusy[detail.id]),
								messaging,
								facts: paneFacts(detail),
								RowInfo,
								t,
								s,
								Senders: /* @__PURE__ */ jsx(Senders, {
									id: detail.id,
									onAllowed: load,
									t
								}),
								onClose: () => setDetailId(""),
								onToggle: toggle,
								onTest: runTest,
								onFix: fixRow,
								onEdit: (x) => openEdit(x),
								onDelete: setToDelete,
								onShare: shareOf
							}, detail.id);
						})()]
					}),
					canShare && shared.length > 0 && /* @__PURE__ */ jsx(SharedConnections, {
						rows: shared,
						s
					}),
					share && canShare && /* @__PURE__ */ jsx(ShareConnection, {
						share,
						s,
						onChanged: load,
						close: () => setShare(null)
					}),
					form && /* @__PURE__ */ jsx(ConnectionSheet, { p: sheetProps }),
					form && saveStepOpen && SaveStep && /* @__PURE__ */ jsx(SaveStep, {
						form,
						t,
						onProceed: proceedSaveStep,
						onCancel: () => setSaveStepOpen(false)
					}),
					/* @__PURE__ */ jsx(ConfirmDialog_default, {
						open: askDiscard,
						title: s("conn.discard.title"),
						message: s("conn.discard.message"),
						confirmLabel: s("conn.discard.confirm"),
						danger: true,
						onConfirm: () => {
							setAskDiscard(false);
							setForm(null);
						},
						onCancel: () => setAskDiscard(false)
					}),
					/* @__PURE__ */ jsx(ConfirmDialog_default, {
						open: Boolean(toDelete),
						title: t("confirmDelete.title", { name: toDelete?.name || "" }),
						message: t("confirmDelete.message"),
						confirmLabel: t("confirmDelete.confirm"),
						danger: true,
						onConfirm: () => {
							const c = toDelete;
							setToDelete(null);
							if (detailId === c.id) setDetailId("");
							setChecks((m) => {
								const next = dropCheck(m, c.id);
								writeChecks(next);
								return next;
							});
							act(() => connectorsApi.remove(c.id));
						},
						onCancel: () => setToDelete(null)
					})
				]
			})
		})
	});
}
var ONE_LIST;
var init_ConnectorPage = __esmMin((() => {
	init_react();
	init_react_i18next();
	init_ConfirmDialog();
	init_Icon();
	init_AnswerFields();
	init_accessHooks();
	init_AuthContext();
	init_controls();
	init_SidePane();
	init_ConnectionRow();
	init_ConnectionPane();
	init_ConnectionSheet();
	init_connection();
	init_api();
	init_share();
	init_runtime();
	init_access();
	init_basePath();
	init_connector();
	init_login();
	init_i18n();
	init_people();
	init_Person();
	init_jsx_runtime();
	registerConnectorLocales();
	ONE_LIST = [{
		key: "allow",
		hint: "allowHint",
		testId: "connector-allow"
	}];
}));

//#endregion
//#region addons/internal/connector-ui/src/addonparts.jsx
function WriteModeField({ ns, form, setForm, t, modes, modeOf }) {
	const mode = modeOf(form.write_mode);
	return /* @__PURE__ */ jsxs("div", {
		"data-testid": `${ns}-write-mode`,
		className: "cn-modeblock",
		children: [/* @__PURE__ */ jsx(Field, {
			label: t("writeMode.label"),
			hint: t("writeMode.hint"),
			children: () => /* @__PURE__ */ jsx(RadioCards, {
				name: "write-mode",
				legend: t("writeMode.label"),
				value: mode,
				onChange: (m) => setForm({
					...form,
					write_mode: m
				}),
				options: modes.map((m) => ({
					value: m,
					label: /* @__PURE__ */ jsxs("span", {
						className: "cn-modecard",
						children: [/* @__PURE__ */ jsx("span", {
							className: "cn-modecard__title",
							children: t(`writeMode.${m}`)
						}), /* @__PURE__ */ jsx("span", {
							className: "cn-modecard__line",
							children: t(`writeMode.line.${m}`)
						})]
					})
				}))
			})
		}), /* @__PURE__ */ jsx(Notice, {
			tone: mode === "off" ? "info" : "warn",
			role: "note",
			testId: `${ns}-write-note`,
			className: "cn-note",
			children: t(`writeMode.note.${mode}`)
		})]
	});
}
function WriteModeChip({ ns, mode, t }) {
	return /* @__PURE__ */ jsx("span", {
		className: `cn-chip cn-chip--${mode}`,
		"data-testid": `${ns}-row-write`,
		children: t(`writeMode.row.${mode}`)
	});
}
var init_addonparts = __esmMin((() => {
	init_controls();
	init_jsx_runtime();
}));

//#endregion
//#region addons/google-team/ui/src/words.en.json
var words_en_default = {
	title: "Google team",
	intro: "Connect a Google account for your team's calendar and tasks. Share the connection only with named LocalAI users you trust.",
	limits: "After connecting, edit and save the connection to enable the team space and select a write mode. Manage team members in chat.",
	edit: "Edit Google team connection",
	name: "Name",
	agent: "Agent",
	agentNone: "Choose an agent",
	agentCredentialsOnly: "No agent (credentials only)",
	agentOptionalHint: "Optional. This connection does not listen for messages.",
	credentialsOnly: "Credentials only",
	agentNoModel: "{{name}} (needs a model)",
	test: "Test",
	testOk: "Connected as {{bot}}.",
	checkFailed: "Saved. The check failed: {{reason}}",
	save: "Save",
	cancel: "Cancel",
	editButton: "Edit",
	"delete": "Delete",
	empty: "No Google team connections yet. Select Connect with Google to add one.",
	connect: "Connect with Google",
	defaultName: "Google team",
	agentOf: "Agent: {{name}}",
	inactive: "Not running: {{reason}}.",
	confirmDelete: {
		"title": "Delete {{name}}?",
		"message": "The team can no longer use this connection. LocalAI revokes the login.",
		"confirm": "Delete"
	},
	writeMode: {
		"label": "What agents may change",
		"hint": "Calendar events, task lists, tasks and team members.",
		"off": "Read only",
		"propose": "Asks you first",
		"auto": "Allow all",
		"line": {
			"off": "No changes.",
			"propose": "Changes wait for approval.",
			"auto": "Your chats may change data without asking."
		},
		"note": {
			"off": "Agents can only read.",
			"propose": "Review each change before it is applied.",
			"auto": "Your chats can change the team account without asking."
		},
		"row": {
			"off": "Read only",
			"propose": "Asks you first",
			"auto": "Allow all"
		}
	}
};

//#endregion
//#region addons/google-team/ui/src/page.jsx
var page_exports = /* @__PURE__ */ __exportAll({ createTeam: () => createTeam });
function Fields({ form, setForm, t }) {
	return /* @__PURE__ */ jsx(WriteModeField, {
		ns: "google-team",
		form,
		setForm,
		t,
		modes,
		modeOf
	});
}
function RowInfo({ c, t }) {
	return /* @__PURE__ */ jsx(WriteModeChip, {
		ns: "google-team",
		mode: modeOf(c.write_mode),
		t
	});
}
function Help({ t }) {
	return /* @__PURE__ */ jsx("p", {
		className: "cn-muted",
		children: t("limits")
	});
}
function createTeam() {
	function Component({ page, path, search }) {
		if (page !== "apps") return null;
		return /* @__PURE__ */ jsx(RouteProvider, {
			value: {
				page,
				path: path || "",
				search: search || ""
			},
			children: /* @__PURE__ */ jsx(ConnectorPage, {
				kind: "google-team",
				ns: "googleTeam",
				testId: "google-team-page",
				TokenFields: NoToken,
				tokenOf: () => "",
				messaging: false,
				login: true,
				ExtraFields: Fields,
				extraBody,
				extraForm,
				extraValid: () => true,
				Help,
				RowInfo
			})
		});
	}
	return {
		Component,
		components: {},
		chatActions: [],
		dispose() {}
	};
}
var modes, modeOf, extraForm, extraBody, NoToken;
var init_page = __esmMin((() => {
	init_react_router_dom();
	init_ConnectorPage();
	init_addonparts();
	init_i18n();
	init_jsx_runtime();
	registerAddonLocales("googleTeam", { en: words_en_default });
	modes = [
		"off",
		"propose",
		"auto"
	];
	modeOf = (mode) => modes.includes(mode) ? mode : "off";
	extraForm = (c) => ({ write_mode: modeOf(c.write_mode) });
	extraBody = (form) => ({
		resources: ["team"],
		write_mode: modeOf(form.write_mode)
	});
	NoToken = () => null;
}));

//#endregion
//#region addons/google-team/ui/src/index.jsx
init_runtime();
async function createAddon(sdk) {
	requireHost(sdk, ["ui.ConfirmDialog"]);
	setSdk(sdk);
	const { createTeam } = await Promise.resolve().then(() => (init_page(), page_exports));
	return createTeam();
}

//#endregion
export { createAddon };